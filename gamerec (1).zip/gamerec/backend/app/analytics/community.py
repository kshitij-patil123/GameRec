"""Community Intelligence Score: a PROJECT-DEFINED metric, not an objective measure of game quality.

Each component is scaled to [0, 1]; the score is their weighted mean (weights configurable, renormalized
over the components actually available for a game):
  sentiment    shrunk mean sentiment, mapped from [-1, 1] to [0, 1]
  consistency  1 - std of message sentiment (do people agree?)
  volume       min-max of log(1 + total messages)   (how much the game is discussed)
  trend        trend score from analytics.trends
  aspect       shrunk mean aspect sentiment, mapped to [0, 1]
  engagement   engagement score from analytics.trends
confidence = n / (n + k) says how much data stands behind the score; low-confidence scores should be
shown with a caveat, and the shrinkage already pulls small-sample games toward the global average.
"""
import pandas as pd

DEFAULT_WEIGHTS = {"sentiment": 0.35, "consistency": 0.10, "volume": 0.15,
                   "trend": 0.20, "aspect": 0.15, "engagement": 0.05}


def shrink(total: pd.Series, n: pd.Series, prior: float, k: float) -> pd.Series:
    """Bayesian-style shrinkage of a mean toward `prior`: (sum + k*prior) / (n + k)."""
    return (total + k * prior) / (n + k)


def compute_community_scores(components: pd.DataFrame, weights: dict | None = None) -> pd.Series:
    """components: columns subset of DEFAULT_WEIGHTS keys, values in [0,1] (NaN = unavailable)."""
    w = {**DEFAULT_WEIGHTS, **(weights or {})}
    cols = [c for c in w if c in components.columns]
    if not cols:
        return pd.Series(dtype=float)
    wv = pd.Series({c: w[c] for c in cols})
    avail = components[cols].notna()
    weighted = components[cols].fillna(0).mul(wv, axis=1).sum(axis=1)
    denom = avail.mul(wv, axis=1).sum(axis=1)
    return (weighted / denom.where(denom > 0)).clip(0, 1)
