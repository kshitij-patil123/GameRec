"""Keyword extraction with TF-IDF, n-grams and frequency analysis.

  top_keywords          corpus-wide important terms (mean TF-IDF)
  distinctive_keywords  terms characteristic of one group (a game or a genre): each group's
                        messages are merged into one document, so TF-IDF rewards terms that are
                        frequent in the group but rare elsewhere
  emerging_keywords     terms whose usage rate rose in the recent window vs a baseline window
"""
import re

import numpy as np
import pandas as pd
from sklearn.feature_extraction.text import CountVectorizer, TfidfVectorizer

from app.nlp.preprocessing import TOPIC_STOPWORDS, _lemmatize_fn


def name_stopwords(game_names: list[str]) -> set[str]:
    """Game-name tokens would dominate game-specific keywords; drop them."""
    lem = _lemmatize_fn()
    tokens = {t for n in game_names for t in re.findall(r"[a-z0-9]+", n.lower())}
    return tokens | {lem(t) for t in tokens}  # text_clean is lemmatized, so match both forms


def _stop(extra: set[str] | None) -> list[str]:
    return sorted(set(TOPIC_STOPWORDS) | (extra or set()))


def top_keywords(texts: list[str], n: int = 20, extra_stop: set[str] | None = None,
                 ngram_range: tuple[int, int] = (1, 2), min_df: int = 3) -> list[tuple[str, float]]:
    texts = [t for t in texts if t]
    if not texts:
        return []
    vec = TfidfVectorizer(ngram_range=ngram_range, min_df=min(min_df, len(texts)), sublinear_tf=True,
                          stop_words=_stop(extra_stop))
    try:
        X = vec.fit_transform(texts)
    except ValueError:  # empty vocabulary
        return []
    scores = np.asarray(X.mean(axis=0)).ravel()
    terms = vec.get_feature_names_out()
    return [(terms[i], float(scores[i])) for i in scores.argsort()[::-1][:n]]


def distinctive_keywords(texts: list[str], groups: list, n: int = 10, extra_stop: set[str] | None = None,
                         max_df: float = 0.6, ngram_range: tuple[int, int] = (1, 2)) -> dict:
    """{group: [(term, score), ...]} distinctive terms per group."""
    df = pd.DataFrame({"t": texts, "g": groups}).dropna()
    df = df[df["t"].str.len() > 0]
    merged = df.groupby("g")["t"].apply(" ".join)
    if len(merged) < 2:
        return {g: top_keywords(list(df[df["g"] == g]["t"]), n, extra_stop) for g in merged.index}
    vec = TfidfVectorizer(ngram_range=ngram_range, max_df=max_df, sublinear_tf=True, stop_words=_stop(extra_stop))
    X = vec.fit_transform(merged.values)
    terms = vec.get_feature_names_out()
    out = {}
    for i, g in enumerate(merged.index):
        row = X[i].toarray().ravel()
        out[g] = [(terms[j], float(row[j])) for j in row.argsort()[::-1][:n] if row[j] > 0]
    return out


def emerging_keywords(df: pd.DataFrame, text_col: str = "text_clean", time_col: str = "created_at",
                      recent_days: int = 30, baseline_days: int = 60, n: int = 15, min_recent: int = 5,
                      smoothing: float = 0.01, extra_stop: set[str] | None = None,
                      as_of: pd.Timestamp | None = None) -> list[dict]:
    """Terms whose share of messages grew most: (recent rate + s) / (baseline rate + s).

    Rates are per-message fractions (not raw counts) so window size differences and overall
    volume do not matter. `as_of` defaults to the newest message so old datasets still work.
    """
    if df.empty:
        return []
    as_of = pd.Timestamp(as_of) if as_of is not None else df[time_col].max()
    recent = df[df[time_col] > as_of - pd.Timedelta(days=recent_days)]
    base = df[(df[time_col] <= as_of - pd.Timedelta(days=recent_days)) &
              (df[time_col] > as_of - pd.Timedelta(days=recent_days + baseline_days))]
    if recent.empty or base.empty:
        return []
    vec = CountVectorizer(binary=True, ngram_range=(1, 2), min_df=2, stop_words=_stop(extra_stop))
    try:
        vec.fit(df[text_col])
    except ValueError:
        return []
    terms = vec.get_feature_names_out()
    rc = np.asarray(vec.transform(recent[text_col]).sum(axis=0)).ravel()
    bc = np.asarray(vec.transform(base[text_col]).sum(axis=0)).ravel()
    rr, br = rc / len(recent), bc / len(base)
    growth = (rr + smoothing) / (br + smoothing)
    order = growth.argsort()[::-1]
    return [{"term": terms[i], "growth": float(growth[i]), "recent_count": int(rc[i]),
             "baseline_count": int(bc[i])} for i in order if rc[i] >= min_recent][:n]
