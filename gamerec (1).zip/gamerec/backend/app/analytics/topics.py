"""Topic discovery with NMF on TF-IDF (topics are LEARNED from the data, not hardcoded).

Labels are a readability step only: a topic is named after the seed theme its top words overlap
most with; otherwise it keeps a "words" label. Seeds never decide which topics exist.
"""
from dataclasses import dataclass

import numpy as np
import pandas as pd
from scipy import sparse
from sklearn.decomposition import NMF
from sklearn.feature_extraction.text import TfidfVectorizer

from app.nlp.preprocessing import TOPIC_STOPWORDS

LABEL_SEEDS = {
    "Story & Characters": {"story", "plot", "character", "narrative", "ending", "writing", "lore"},
    "Graphics & Art": {"graphic", "visual", "art", "animation", "look", "texture"},
    "Combat": {"combat", "fight", "weapon", "boss", "melee", "attack"},
    "Difficulty": {"difficulty", "hard", "challenging", "easy", "curve", "difficult"},
    "Multiplayer": {"multiplayer", "coop", "online", "matchmaking", "server", "pvp", "team"},
    "Performance & Bugs": {"performance", "fps", "lag", "crash", "bug", "glitch", "stutter", "fix", "broken"},
    "Music & Sound": {"music", "soundtrack", "audio", "sound", "ost"},
    "Price & Value": {"price", "cost", "expensive", "worth", "dlc", "value"},
    "Exploration & World": {"exploration", "explore", "world", "map", "open"},
    "Updates & Patches": {"update", "patch", "season", "release"},
}


@dataclass
class TopicModelResult:
    vectorizer: TfidfVectorizer
    model: NMF
    topics: list[dict]          # {id, label, keywords: [..]}
    doc_topic: np.ndarray       # rows sum to 1
    coherence: float


def label_topic(keywords: list[str], weights: list[float] | None = None) -> str | None:
    """Name a topic by the seed theme carrying the most keyword weight (None if no seed matches)."""
    weights = weights or [1.0] * len(keywords)
    best, best_score = None, 0.0
    for label, seeds in LABEL_SEEDS.items():
        score = sum(w for kw, w in zip(keywords, weights) if seeds & set(kw.split()))
        if score > best_score:
            best, best_score = label, score
    return best


def umass_coherence(X_binary: sparse.csr_matrix, top_idx: list[list[int]]) -> float:
    """Mean UMass coherence over topics (higher / closer to 0 = more coherent)."""
    Xc = X_binary.tocsc()
    doc_freq = np.asarray(Xc.sum(axis=0)).ravel()
    scores = []
    for idx in top_idx:
        s = 0.0
        for i in range(1, len(idx)):
            for j in range(i):
                co = Xc[:, idx[i]].multiply(Xc[:, idx[j]]).sum()
                s += np.log((co + 1) / max(doc_freq[idx[j]], 1))
        scores.append(s)
    return float(np.mean(scores)) if scores else float("nan")


def fit_topics(texts: list[str], k: int = 8, n_top: int = 10, min_df: int = 3, max_df: float = 0.5,
               extra_stop: set[str] | None = None, seed: int = 42) -> TopicModelResult:
    if len(texts) < max(k, 2):
        raise ValueError(f"Need at least {k} documents to fit {k} topics, got {len(texts)}")
    vec = TfidfVectorizer(ngram_range=(1, 2), min_df=min_df, max_df=max_df, sublinear_tf=True,
                          stop_words=sorted(set(TOPIC_STOPWORDS) | (extra_stop or set())))
    X = vec.fit_transform(texts)
    model = NMF(n_components=k, init="nndsvd", random_state=seed, max_iter=400)
    W = model.fit_transform(X)
    W = W / (W.sum(axis=1, keepdims=True) + 1e-12)
    terms = vec.get_feature_names_out()
    top_idx = [list(c.argsort()[::-1][:n_top]) for c in model.components_]
    topics = []
    for tid, idx in enumerate(top_idx):
        kws = [terms[i] for i in idx]
        weights = [float(model.components_[tid][i]) for i in idx]
        topics.append({"id": tid, "label": label_topic(kws, weights) or f"Topic {tid}: {', '.join(kws[:3])}",
                       "keywords": kws})
    coh = umass_coherence((X > 0).astype(int), top_idx)
    return TopicModelResult(vec, model, topics, W, coh)


def select_k(texts: list[str], candidates: tuple[int, ...] = (4, 6, 8, 10, 12), **kw) -> tuple[int, dict]:
    """Pick k with the best UMass coherence. Coherence is a heuristic; sanity-check topics by reading them."""
    scores = {k: fit_topics(texts, k=k, **kw).coherence for k in candidates if k <= len(texts)}
    return max(scores, key=scores.get), scores


def dominant_topics(doc_topic: np.ndarray) -> pd.DataFrame:
    return pd.DataFrame({"topic_id": doc_topic.argmax(axis=1), "weight": doc_topic.max(axis=1)})
