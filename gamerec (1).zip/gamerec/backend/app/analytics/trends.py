"""Trend analysis: windowed, normalized, and growth-aware (raw counts alone favor old games).

Trend Score = w_vol * volume_score + w_growth * growth_score + w_eng * engagement_score   (each in [0,1])
  volume_score     min-max of log(1 + recent message count) across games
  growth_score     g / (1 + g) where g = (recent + a) / (expected_from_baseline + a)
                   0.5 = flat, >0.5 growing; the pseudo-count `a` stops tiny counts producing huge ratios;
                   the baseline is rescaled to the recent window's length, so windows may differ in size
  engagement_score min-max of mean engagement (reactions etc.) per recent message
Default windows: recent = last 28 days, baseline = the 56 days before that, relative to the newest message.
"""
import numpy as np
import pandas as pd

TREND_WEIGHTS = {"volume": 0.4, "growth": 0.4, "engagement": 0.2}
COLUMNS = ["recent_count", "baseline_count", "total_count", "growth_ratio", "volume_score",
           "growth_score", "engagement_score", "trend_score", "status"]


def minmax(s: pd.Series) -> pd.Series:
    """Scale to [0, 1]; a constant series carries no signal, so it maps to 0.5."""
    lo, hi = float(s.min()), float(s.max())
    if hi - lo < 1e-12:
        return pd.Series(0.5, index=s.index)
    return (s - lo) / (hi - lo)


def compute_trend_scores(msgs: pd.DataFrame, as_of: pd.Timestamp | None = None, recent_days: int = 28,
                         baseline_days: int = 56, weights: dict | None = None, pseudo: float = 3.0,
                         rising: float = 1.25, declining: float = 0.8, min_total: int = 10) -> pd.DataFrame:
    """msgs needs game_id, created_at, engagement. Returns one row per game (index game_id)."""
    if msgs.empty:
        return pd.DataFrame(columns=COLUMNS).rename_axis("game_id")
    w = {**TREND_WEIGHTS, **(weights or {})}
    wsum = sum(w.values())
    msgs = msgs.assign(created_at=pd.to_datetime(msgs["created_at"]), engagement=msgs["engagement"].fillna(0))
    as_of = pd.Timestamp(as_of) if as_of is not None else msgs["created_at"].max()
    msgs = msgs[msgs["created_at"] <= as_of]
    r_start = as_of - pd.Timedelta(days=recent_days)
    b_start = r_start - pd.Timedelta(days=baseline_days)
    recent = msgs[msgs["created_at"] > r_start]
    base = msgs[(msgs["created_at"] > b_start) & (msgs["created_at"] <= r_start)]

    games = pd.Index(sorted(msgs["game_id"].unique()), name="game_id")
    rc = recent.groupby("game_id").size().reindex(games, fill_value=0)
    bc = base.groupby("game_id").size().reindex(games, fill_value=0)
    total = msgs.groupby("game_id").size().reindex(games, fill_value=0)

    expected = bc * recent_days / baseline_days
    growth = (rc + pseudo) / (expected + pseudo)
    growth_score = growth / (1 + growth)
    volume_score = minmax(np.log1p(rc))
    eng = recent.groupby("game_id")["engagement"].mean().reindex(games).fillna(0.0)
    eng_score = minmax(eng)
    score = (w["volume"] * volume_score + w["growth"] * growth_score + w["engagement"] * eng_score) / wsum

    status = pd.Series("stable", index=games)
    status[growth >= rising] = "rising"
    status[growth <= declining] = "declining"
    status[total < min_total] = "insufficient data"
    return pd.DataFrame({"recent_count": rc, "baseline_count": bc, "total_count": total,
                         "growth_ratio": growth, "volume_score": volume_score, "growth_score": growth_score,
                         "engagement_score": eng_score, "trend_score": score, "status": status})


def volume_timeline(msgs: pd.DataFrame, freq: str = "W", game_id: int | None = None) -> pd.DataFrame:
    """Messages per period (optionally for one game): columns period, n_messages."""
    df = msgs if game_id is None else msgs[msgs["game_id"] == game_id]
    if df.empty:
        return pd.DataFrame(columns=["period", "n_messages"])
    periods = pd.to_datetime(df["created_at"]).dt.to_period(freq).dt.start_time
    return periods.value_counts().sort_index().rename_axis("period").reset_index(name="n_messages")


def mean_timeline(df: pd.DataFrame, value_col: str, freq: str = "W") -> pd.DataFrame:
    """Mean of value_col per period (e.g. sentiment over time): columns period, mean, n."""
    if df.empty:
        return pd.DataFrame(columns=["period", "mean", "n"])
    period = pd.to_datetime(df["created_at"]).dt.to_period(freq).dt.start_time
    g = df.groupby(period)[value_col].agg(["mean", "count"]).rename(columns={"count": "n"})
    return g.rename_axis("period").reset_index()
