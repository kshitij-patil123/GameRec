from fastapi import APIRouter, Depends, HTTPException, Query, Request
from sqlalchemy.orm import Session

from app.api.deps import require_data, cached, get_db
from app.models import Game
from app.services import query_service as q

router = APIRouter(prefix="/analytics", tags=["analytics"], dependencies=[Depends(require_data)])


@router.get("/overview")
def overview(db: Session = Depends(get_db)):
    """Everything the home dashboard needs in one call (recommendations are fetched separately)."""
    sent = q.sentiment_overview(db)
    return {"meta": q.data_meta(db), "trending_games": q.trending_games(db, 5), "trending_topics": q.trending_topics(db, 5),
            "sentiment_distribution_pct": sent["distribution_pct"], "genres": q.activity_overview(db)["genre_popularity"][:8]}


@router.get("/sentiment")
def sentiment(db: Session = Depends(get_db)):
    return q.sentiment_overview(db)


@router.get("/topics")
def topics(db: Session = Depends(get_db)):
    return q.topics_overview(db)


@router.get("/aspects")
def aspects(game_id: int | None = Query(None, gt=0), db: Session = Depends(get_db)):
    if game_id is not None and db.get(Game, game_id) is None:
        raise HTTPException(404, f"Game {game_id} not found")
    return q.aspects_overview(db, game_id)


@router.get("/keywords")
def keywords(request: Request, db: Session = Depends(get_db)):
    return cached(request, "keywords", lambda: q.keywords_overview(db))


@router.get("/activity")
def activity(db: Session = Depends(get_db)):
    return q.activity_overview(db)
