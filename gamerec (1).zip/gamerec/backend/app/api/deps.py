import hmac
import logging
import threading
from typing import Callable

from fastapi import Depends, Header, HTTPException, Request
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.core.config import get_settings
from app.core.db import get_db
from app.models import Game
from app.services.recommendation_service import Bundle, build_bundle

log = logging.getLogger(__name__)
_lock = threading.Lock()
__all__ = ["get_db", "get_bundle", "cached", "reset_state", "require_admin", "require_data"]


def get_bundle(request: Request, db: Session = Depends(get_db)) -> Bundle:
    """The fitted recommender, built lazily on first use and cached on the app."""
    bundle = getattr(request.app.state, "bundle", None)
    if bundle is None:
        with _lock:
            bundle = getattr(request.app.state, "bundle", None)
            if bundle is None:
                try:
                    bundle = build_bundle(db)
                except ValueError as exc:
                    raise HTTPException(503, "No games loaded yet. Run scripts/run_pipeline.py first.") from exc
                request.app.state.bundle = bundle
    return bundle


def cached(request: Request, key: str, fn: Callable):
    """Cache for expensive, data-derived analytics; cleared by reset_state() after a pipeline refresh."""
    cache = request.app.state.__dict__.setdefault("cache", {})
    if key not in cache:
        cache[key] = fn()
    return cache[key]


def reset_state(app) -> None:
    app.state.bundle = None
    app.state.cache = {}


def require_admin(x_admin_token: str | None = Header(default=None)) -> None:
    token = get_settings().admin_token
    if not token:
        raise HTTPException(403, "Admin endpoints are disabled (set ADMIN_TOKEN)")
    if not x_admin_token or not hmac.compare_digest(x_admin_token, token):
        raise HTTPException(403, "Invalid admin token")


def require_data(db: Session = Depends(get_db)) -> None:
    """503 with instructions (instead of an empty or broken page) until the pipeline has loaded games."""
    if db.scalar(select(func.count()).select_from(Game)) == 0:
        raise HTTPException(503, "No games loaded yet. Run scripts/run_pipeline.py demo, then restart the API.")
