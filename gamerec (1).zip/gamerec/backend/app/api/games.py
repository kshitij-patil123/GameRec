from typing import Literal

from fastapi import APIRouter, Depends, HTTPException, Query, Request
from sqlalchemy.orm import Session

from app.api.deps import cached, get_bundle, get_db
from app.models import Game
from app.recommender.content import UnknownGameError
from app.schemas.api import GameList, GameSummary
from app.services import query_service as q
from app.services.recommendation_service import Bundle

router = APIRouter(prefix="/games", tags=["games"])


def _game_or_404(db: Session, game_id: int) -> Game:
    game = db.get(Game, game_id)
    if game is None:
        raise HTTPException(404, f"Game {game_id} not found")
    return game


@router.get("/search")
def search(q_: str = Query(alias="q", min_length=1, max_length=100), limit: int = Query(8, ge=1, le=25),
           db: Session = Depends(get_db)):
    """Lightweight name search for autocomplete (names starting with the query rank first)."""
    items, _ = q.list_games(db, q_, None, None, None, "name", "asc", 100, 0)
    items.sort(key=lambda g: (not g["name"].lower().startswith(q_.lower()), g["name"]))
    return [{"id": g["id"], "name": g["name"], "genres": g["genres"]} for g in items[:limit]]


@router.get("/filters")
def filters(db: Session = Depends(get_db)):
    return q.filter_options(db)


@router.get("", response_model=GameList)
def list_games(q_: str | None = Query(None, alias="q", max_length=100), genre: str | None = Query(None, max_length=60),
               platform: str | None = Query(None, max_length=40), min_rating: float | None = Query(None, ge=0, le=5),
               sort: Literal["name", "rating", "release_date", "community_score", "trend_score"] = "name",
               order: Literal["asc", "desc"] = "asc", limit: int = Query(24, ge=1, le=100),
               offset: int = Query(0, ge=0), db: Session = Depends(get_db)):
    items, total = q.list_games(db, q_, genre, platform, min_rating, sort, order, limit, offset)
    return {"items": items, "total": total, "limit": limit, "offset": offset}


@router.get("/{game_id}", response_model=GameSummary)
def game_detail(game_id: int, db: Session = Depends(get_db)):
    return q.summaries(db, [_game_or_404(db, game_id)])[0]


@router.get("/{game_id}/similar")
def similar(game_id: int, limit: int = Query(6, ge=1, le=20), db: Session = Depends(get_db),
            bundle: Bundle = Depends(get_bundle)):
    _game_or_404(db, game_id)
    content = bundle.hybrid.content
    try:
        pairs = content.similar_games(game_id, limit)
    except UnknownGameError:
        raise HTTPException(404, f"Game {game_id} is not in the recommender yet; refresh it") from None
    games = {g.id: g for g in db.query(Game).filter(Game.id.in_([g for g, _ in pairs])).all()}
    summaries = {s["id"]: s for s in q.summaries(db, list(games.values()))}
    return [{"game": summaries[g], "similarity": round(s, 4), "shared": content.shared_features(game_id, [g])}
            for g, s in pairs if g in summaries]


@router.get("/{game_id}/community-analysis")
def community_analysis(game_id: int, request: Request, db: Session = Depends(get_db)):
    game = _game_or_404(db, game_id)
    kw = cached(request, "game_keywords", lambda: q.per_game_keywords(db))
    return q.community_analysis(db, game, kw.get(game_id, []))
