import json

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.api.deps import get_bundle, get_db
from app.models import Game
from app.recommender.hybrid import validate_weights
from app.schemas.api import RecommendationItem, RecommendationResponse
from app.services import query_service as q
from app.services.recommendation_service import Bundle, explain_for_user, load_profile, recommend_for_user

router = APIRouter(prefix="/recommendations", tags=["recommendations"])


def _parse_weights(raw: str | None) -> dict | None:
    if raw is None:
        return None
    try:
        weights = json.loads(raw)
        if not isinstance(weights, dict):
            raise ValueError("weights must be a JSON object")
        validate_weights(weights)
        return {k: float(v) for k, v in weights.items()}
    except (ValueError, TypeError) as exc:
        raise HTTPException(422, f"Invalid weights: {exc}") from None


def _items(db: Session, recs, first_rank: int = 1) -> list[dict]:
    games = {g.id: g for g in db.scalars(select(Game).where(Game.id.in_([r.game_id for r in recs])))}
    summaries = {s["id"]: s for s in q.summaries(db, list(games.values()))}
    return [{"rank": i, "game": summaries[r.game_id], "score": round(r.score, 4), "match_percent": r.match_percent,
             "components": {k: round(v, 4) for k, v in r.components.items()},
             "contributions": {k: round(v, 4) for k, v in r.contributions.items()},
             "reasons": r.reasons, "strategy": r.strategy} for i, r in enumerate(recs, first_rank)]


@router.get("/{user_id}", response_model=RecommendationResponse)
def recommendations(user_id: int, n: int = Query(10, ge=1, le=50), weights: str | None = Query(
        None, description='JSON, e.g. {"content": 0.5, "trend": 0}. Omitted components keep their defaults.'),
        save: bool = Query(False, description="Append this list to the user's recommendation history"),
        db: Session = Depends(get_db), bundle: Bundle = Depends(get_bundle)):
    w = _parse_weights(weights)
    try:
        profile = load_profile(db, bundle, user_id)
    except LookupError as exc:
        raise HTTPException(404, str(exc)) from None
    recs = recommend_for_user(db, bundle, user_id, n=n, weights=w, store=save)
    effective = validate_weights({**bundle.hybrid.weights, **(w or {})})
    return {"user_id": user_id, "strategy": recs[0].strategy if recs else "none", "n_ratings": profile.n_ratings,
            "weights": effective, "is_demo": q.data_meta(db)["is_demo"], "items": _items(db, recs)}


@router.get("/{user_id}/explain/{game_id}", response_model=RecommendationItem)
def explain(user_id: int, game_id: int, weights: str | None = Query(None), db: Session = Depends(get_db),
            bundle: Bundle = Depends(get_bundle)):
    if db.get(Game, game_id) is None:
        raise HTTPException(404, f"Game {game_id} not found")
    try:
        result = explain_for_user(db, bundle, user_id, game_id, _parse_weights(weights))
    except LookupError as exc:
        raise HTTPException(404, str(exc)) from None
    if result is None:
        raise HTTPException(409, "The user has already rated or favorited this game, so it is not a candidate")
    rec, rank, total = result
    item = _items(db, [rec], first_rank=rank)[0]
    return {**item, "reasons": rec.reasons}
