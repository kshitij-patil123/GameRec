from fastapi import APIRouter, Depends, Request
from sqlalchemy.orm import Session

from app.api.deps import get_db, require_admin, reset_state
from app.services import query_service as q

router = APIRouter()


@router.get("/health", tags=["system"])
def health():
    return {"status": "ok"}


@router.get("/meta", tags=["system"])
def meta(db: Session = Depends(get_db)):
    """Which data is loaded and which pipeline steps have run. The UI shows the demo banner from here."""
    return q.data_meta(db)


@router.post("/system/refresh", tags=["system"], dependencies=[Depends(require_admin)])
def refresh(request: Request):
    """Drop the cached recommender/analytics so they are rebuilt from the database on next use."""
    reset_state(request.app)
    return {"status": "refreshed"}
