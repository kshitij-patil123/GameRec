from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session

from app.api.deps import require_data, get_db
from app.services import query_service as q

router = APIRouter(prefix="/trending", tags=["trending"], dependencies=[Depends(require_data)])


@router.get("/games")
def trending_games(limit: int = Query(10, ge=1, le=50), db: Session = Depends(get_db)):
    return q.trending_games(db, limit)


@router.get("/topics")
def trending_topics(limit: int = Query(8, ge=1, le=50), db: Session = Depends(get_db)):
    return q.trending_topics(db, limit)
