from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.api.deps import get_bundle, get_db
from app.schemas.api import PreferencesIn, RatingIn, UserCreate, UserOut
from app.services import user_service as svc
from app.services.recommendation_service import Bundle

router = APIRouter(prefix="/users", tags=["users"])


def _guard(fn, *args, **kwargs):
    try:
        return fn(*args, **kwargs)
    except svc.NotFound as exc:
        raise HTTPException(404, str(exc)) from None
    except svc.Invalid as exc:
        raise HTTPException(422, str(exc)) from None


@router.get("", response_model=list[UserOut])
def list_users(db: Session = Depends(get_db)):
    return svc.list_users(db)


@router.post("", response_model=UserOut, status_code=201)
def create_user(body: UserCreate, db: Session = Depends(get_db)):
    user = svc.create_user(db, body.display_name)
    return {"id": user.id, "display_name": user.display_name, "n_ratings": 0}


@router.post("/{user_id}/ratings", status_code=201)
def add_rating(user_id: int, body: RatingIn, db: Session = Depends(get_db)):
    row = _guard(svc.upsert_rating, db, user_id, body.game_id, body.rating, body.interaction)
    return {"user_id": user_id, "game_id": row.game_id, "rating": row.rating, "interaction": row.interaction}


@router.post("/{user_id}/preferences")
def set_preferences(user_id: int, body: PreferencesIn, db: Session = Depends(get_db)):
    _guard(svc.set_preferences, db, user_id, body.genres, body.tags, body.favorite_game_ids, body.aspects)
    return {"status": "saved"}


@router.get("/{user_id}/profile")
def profile(user_id: int, db: Session = Depends(get_db), bundle: Bundle = Depends(get_bundle)):
    return _guard(svc.profile_view, db, bundle, user_id)
