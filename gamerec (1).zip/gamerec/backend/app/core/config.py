"""Central configuration, loaded from environment / .env (no secrets in code)."""
from functools import lru_cache
from pathlib import Path

from pydantic import field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict

ROOT = Path(__file__).resolve().parents[3]


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=ROOT / ".env", extra="ignore")

    data_source: str = "demo"  # demo | public | discord_export
    database_url: str = "sqlite:///./gamerec_dev.db"
    cors_origins: str = "http://localhost:5173"
    user_hash_salt: str = "dev-only-salt"
    random_seed: int = 42
    admin_token: str = ""  # empty = admin endpoints disabled

    @field_validator("database_url")
    @classmethod
    def anchor_relative_sqlite_path(cls, url: str) -> str:
        """sqlite:///./gamerec.db is resolved against the project root, so the pipeline script and the API
        open the SAME file no matter which directory they are started from."""
        prefix = "sqlite:///"
        if url.startswith(prefix):
            path = url[len(prefix):]
            if path and ":memory:" not in path and not Path(path).is_absolute():
                return prefix + str((ROOT / path).resolve())
        return url

    @property
    def cors_list(self) -> list[str]:
        return [o.strip() for o in self.cors_origins.split(",") if o.strip()]


@lru_cache
def get_settings() -> Settings:
    return Settings()
