"""Offline evaluation: baselines, ablations, validation-tuned weights, cold-start, bootstrap statistics.

Protocol (see docs/evaluation.md):
  * per-user chronological split: train / validation / test (60/20/20 by default)
  * relevant = held-out game rated >= 4; candidates = every game the user has not rated yet
    (unrated games count as non-relevant, the usual implicit-feedback assumption)
  * CF is refit on TRAIN only for tuning, and on TRAIN+VALIDATION for the final test
  * hybrid weights are tuned on VALIDATION only; the test split is touched once per model
  * no model sees test ratings; community data (messages) is independent of ratings, so there is no leakage
    through it
"""
from dataclasses import dataclass, field
from typing import Callable

import numpy as np
import pandas as pd

from app.evaluation.metrics import bootstrap_ci, paired_diff_ci, user_metrics
from app.evaluation.splits import UserSplit, chronological_split
from app.recommender.collaborative import ItemItemCF
from app.recommender.hybrid import COMPONENTS, DEFAULT_WEIGHTS, HybridRecommender
from app.recommender.profile import UserProfile, build_profile


def only(**w: float) -> dict[str, float]:
    return {c: float(w.get(c, 0.0)) for c in COMPONENTS}


def default_without(*names: str) -> dict[str, float]:
    return {c: (0.0 if c in names else v) for c, v in DEFAULT_WEIGHTS.items()}


MODEL_WEIGHTS = {
    "content_only": only(content=1),
    "cf_only": only(collaborative=1),
    "content_cf": only(content=DEFAULT_WEIGHTS["content"], collaborative=DEFAULT_WEIGHTS["collaborative"]),
    "hybrid_no_community": default_without("community", "trend", "aspect"),
    "hybrid_default": dict(DEFAULT_WEIGHTS),
}
COLD_MODEL_WEIGHTS = {
    "content_only": only(content=1),
    "community_trend_only": only(community=DEFAULT_WEIGHTS["community"], trend=DEFAULT_WEIGHTS["trend"]),
    "hybrid_no_community": default_without("community", "trend", "aspect"),
    "hybrid_default": dict(DEFAULT_WEIGHTS),
}
COMPARISONS = [("hybrid_default", "content_only"), ("hybrid_default", "cf_only"), ("hybrid_default", "content_cf"),
               ("hybrid_default", "hybrid_no_community"), ("hybrid_tuned", "hybrid_default")]


@dataclass
class EvalContext:
    content: object
    game_info: pd.DataFrame
    aspect_scores: pd.DataFrame
    attention: pd.DataFrame
    game_meta: pd.DataFrame

    @property
    def all_games(self) -> list[int]:
        return sorted(int(g) for g in self.game_info.index)

    def hybrid(self, collab: ItemItemCF) -> HybridRecommender:
        return HybridRecommender(self.content, collab, self.game_info,
                                 self.aspect_scores if not self.aspect_scores.empty else None)

    def profile(self, user_id: int, history: dict[int, float]) -> UserProfile:
        return build_profile(user_id, [(g, r, None) for g, r in history.items()], game_meta=self.game_meta,
                             attention=self.attention, aspect_sentiment=self.aspect_scores)


def context_from_bundle(bundle) -> EvalContext:
    h = bundle.hybrid
    return EvalContext(h.content, h.game_info, h.aspect_scores, bundle.attention, bundle.game_meta)


@dataclass
class Case:
    user_id: int
    history: dict[int, float]
    candidates: list[int]
    relevant: set[int]
    raw: pd.DataFrame | None = field(default=None, repr=False)


class Popularity:
    """Rank by number of ratings (ties: mean rating). `exclude` removes one user's own ratings (leave-one-out)."""

    def __init__(self, ratings: pd.DataFrame) -> None:
        g = ratings.groupby("game_id")["rating"].agg(["count", "sum"])
        self.count, self.total = g["count"].to_dict(), g["sum"].to_dict()

    def rank(self, candidates: list[int], exclude: dict[int, float] | None = None) -> list[int]:
        exclude = exclude or {}

        def key(gid):
            c, s = self.count.get(gid, 0), self.total.get(gid, 0.0)
            if gid in exclude:
                c, s = c - 1, s - exclude[gid]
            return (c, s / c if c > 0 else 0.0)

        return sorted(candidates, key=key, reverse=True)


def make_cases(splits: list[UserSplit], phase: str, all_games: list[int], threshold: float, min_history: int = 3,
               given: int = 2) -> tuple[list[Case], dict]:
    cases, skipped = [], {"no_relevant": 0, "short_history": 0}
    universe = set(all_games)
    for s in splits:
        if phase == "val":
            history, target, future = s.train, s.val, set(s.test)
        elif phase == "test":
            history, target, future = {**s.train, **s.val}, s.test, set()
        elif phase == "cold":
            everything = {**s.train, **s.val, **s.test}
            history = dict(list(s.train.items())[:given])
            target, future = {g: r for g, r in everything.items() if g not in history}, set()
        else:
            raise ValueError(phase)
        relevant = {g for g, r in target.items() if r >= threshold}
        if phase != "cold" and len(history) < min_history:
            skipped["short_history"] += 1
        elif not relevant:
            skipped["no_relevant"] += 1
        else:
            cands = sorted(universe - set(history) - future)
            cases.append(Case(s.user_id, history, cands, relevant))
    return cases, skipped


def _rank_weights(hybrid: HybridRecommender, ctx: EvalContext, case: Case, weights: dict) -> list[int]:
    if case.raw is None:
        case.raw = hybrid.raw_components(ctx.profile(case.user_id, case.history), case.candidates)
    final, _, _ = hybrid.final_scores(case.raw, weights)
    ranked = [int(g) for g in final.index]
    return ranked + [g for g in case.candidates if g not in set(ranked)]  # unscorable items go last


def _evaluate(cases: list[Case], rankers: dict[str, Callable[[Case], list[int]]], ks: list[int]) -> dict:
    out: dict[str, dict[str, list[float]]] = {name: {} for name in rankers}
    for case in cases:
        for name, rank in rankers.items():
            for metric, value in user_metrics(rank(case), case.relevant, ks).items():
                out[name].setdefault(metric, []).append(value)
    return {n: {m: np.array(v) for m, v in d.items()} for n, d in out.items()}


def _summarize(per_user: dict, n_boot: int, seed: int) -> dict:
    return {name: {m: dict(zip(("mean", "low", "high"), bootstrap_ci(v, n_boot, seed=seed))) for m, v in d.items()}
            for name, d in per_user.items()}


def _paired(per_user: dict, comparisons, ks, n_boot, seed) -> dict:
    out = {}
    for a, b in comparisons:
        if a in per_user and b in per_user:
            out[f"{a} vs {b}"] = {m: paired_diff_ci(per_user[a][m], per_user[b][m], n_boot, seed=seed)
                                  for m in per_user[a]}
    return out


def tune_weights(hybrid, ctx: EvalContext, val_cases: list[Case], trials: int, k: int, seed: int) -> dict:
    """Random search over weight vectors; objective = mean validation NDCG@k. Raw components are computed once
    per user; each trial only re-combines them."""
    rng = np.random.default_rng(seed)
    candidates = [("default", dict(DEFAULT_WEIGHTS))] + [(f"only_{c}", only(**{c: 1})) for c in COMPONENTS]
    candidates += [(f"random_{i}", dict(zip(COMPONENTS, map(float, rng.dirichlet(np.ones(len(COMPONENTS)))))))
                   for i in range(trials)]
    scores = {}
    for name, w in candidates:
        res = _evaluate(val_cases, {"m": lambda c, w=w: _rank_weights(hybrid, ctx, c, w)}, [k])
        scores[name] = float(np.nanmean(res["m"][f"ndcg@{k}"]))
    best = max(scores, key=lambda n: (scores[n], n == "default"))   # ties keep the default weights
    weights = dict(candidates)[best]
    total = sum(weights.values())
    return {"metric": f"ndcg@{k}", "trials": len(candidates), "default_val": scores["default"],
            "best_val": scores[best], "best_name": best,
            "best_weights": {c: v / total for c, v in weights.items()}, "tuned_differs": best != "default"}


def run_evaluation(ctx: EvalContext, ratings: pd.DataFrame, ks=(5, 10), threshold: float = 4.0,
                   tune_trials: int = 60, seed: int = 42, min_ratings: int = 5, cold_given: int = 2,
                   n_boot: int = 2000, train_frac: float = 0.6, val_frac: float = 0.2) -> dict:
    """ratings: user_id, game_id, rating, created_at. Returns a JSON-serializable results dict."""
    if cold_given >= 3:
        raise ValueError("cold_given must be < 3 (CF switches on at 3 ratings and would need a leak-free refit)")
    ks = list(ks)
    ratings = ratings.dropna(subset=["rating"])
    splits = chronological_split(ratings, train_frac, val_frac, min_ratings)
    eligible = {s.user_id for s in splits}
    all_games = ctx.all_games

    def frame(rows):
        return pd.DataFrame(rows, columns=["user_id", "game_id", "rating"])

    base_train = ratings[~ratings["user_id"].isin(eligible)][["user_id", "game_id", "rating"]]
    train_rows = [(s.user_id, g, r) for s in splits for g, r in s.train.items()]
    val_rows = [(s.user_id, g, r) for s in splits for g, r in s.val.items()]
    train_df = pd.concat([base_train, frame(train_rows)], ignore_index=True)
    trainval_df = pd.concat([train_df, frame(val_rows)], ignore_index=True)

    # ---- validation: tune weights (CF fit on train only) ----
    val_cases, _ = make_cases(splits, "val", all_games, threshold)
    h_val = ctx.hybrid(ItemItemCF().fit(train_df))
    tuning = tune_weights(h_val, ctx, val_cases, tune_trials, ks[0], seed) if val_cases else None
    tuned = tuning["best_weights"] if tuning else dict(DEFAULT_WEIGHTS)

    # ---- test: all models, CF fit on train+validation ----
    test_cases, skipped = make_cases(splits, "test", all_games, threshold)
    h_test = ctx.hybrid(ItemItemCF().fit(trainval_df))
    pop = Popularity(trainval_df)
    rankers = {
        "random": lambda c: [int(g) for g in np.random.default_rng(seed + c.user_id).permutation(c.candidates)],
        "popularity": lambda c: pop.rank(c.candidates),
        **{n: (lambda c, w=w: _rank_weights(h_test, ctx, c, w)) for n, w in MODEL_WEIGHTS.items()},
        "hybrid_tuned": lambda c: _rank_weights(h_test, ctx, c, tuned),
    }
    per_user = _evaluate(test_cases, rankers, ks)

    # ---- cold start: given the first N ratings, rank the rest ----
    cold_cases, cold_skipped = make_cases(splits, "cold", all_games, threshold, given=cold_given)
    full_pop = Popularity(ratings[["user_id", "game_id", "rating"]])
    own = {s.user_id: {**s.train, **s.val, **s.test} for s in splits}
    h_cold = ctx.hybrid(ItemItemCF())
    cold_rankers = {
        "random": rankers["random"],
        "popularity": lambda c: full_pop.rank(c.candidates, exclude=own[c.user_id]),
        **{n: (lambda c, w=w: _rank_weights(h_cold, ctx, c, w)) for n, w in COLD_MODEL_WEIGHTS.items()},
    }
    cold_per_user = _evaluate(cold_cases, cold_rankers, ks)

    pool = float(np.mean([len(c.candidates) for c in test_cases])) if test_cases else 0.0
    n_users, warnings = len(test_cases), []
    if n_users < 30:
        warnings.append(f"Only {n_users} test users: confidence intervals are wide; differences are rarely reliable.")
    if pool < 2 * max(ks):
        warnings.append(f"Candidate pool averages {pool:.0f} games, under 2x K={max(ks)}: top-K metrics are compressed "
                        "and easy to win by chance. Use a catalog much larger than K for real results.")
    return {
        "config": {"ks": ks, "relevant_threshold": threshold, "tune_trials": tune_trials, "seed": seed,
                   "split": [train_frac, val_frac, round(1 - train_frac - val_frac, 2)], "min_ratings": min_ratings,
                   "cold_given": cold_given, "bootstrap_resamples": n_boot},
        "data": {"n_games": len(all_games), "n_users_total": int(ratings["user_id"].nunique()),
                 "n_ratings": int(len(ratings)), "n_eval_users": n_users, "skipped": skipped,
                 "mean_candidate_pool": pool},
        "tuning": tuning,
        "test": {"summary": _summarize(per_user, n_boot, seed),
                 "paired": _paired(per_user, COMPARISONS, ks, n_boot, seed)},
        "cold_start": {"n_users": len(cold_cases), "skipped": cold_skipped,
                       "summary": _summarize(cold_per_user, n_boot, seed),
                       "paired": _paired(cold_per_user, [("hybrid_default", "hybrid_no_community"),
                                                         ("hybrid_default", "content_only"),
                                                         ("hybrid_default", "popularity")], ks, n_boot, seed)},
        "warnings": warnings,
    }
