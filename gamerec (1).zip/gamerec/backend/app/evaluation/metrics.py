"""Top-K ranking metrics with binary relevance, plus bootstrap confidence intervals.

All metrics take `ranked` (item ids, best first) and `relevant` (set of item ids the user truly liked).
Users with no relevant items are skipped by the caller (recall/NDCG are undefined for them).
"""
import math

import numpy as np


def hits_at_k(ranked: list[int], relevant: set[int], k: int) -> int:
    return sum(1 for item in ranked[:k] if item in relevant)


def precision_at_k(ranked, relevant, k: int) -> float:
    """hits / K (K, not the list length, so short lists are not rewarded)."""
    return hits_at_k(ranked, relevant, k) / k


def recall_at_k(ranked, relevant, k: int) -> float:
    return hits_at_k(ranked, relevant, k) / len(relevant) if relevant else float("nan")


def f1_at_k(ranked, relevant, k: int) -> float:
    p, r = precision_at_k(ranked, relevant, k), recall_at_k(ranked, relevant, k)
    return 0.0 if p + r == 0 else 2 * p * r / (p + r)


def hit_rate_at_k(ranked, relevant, k: int) -> float:
    return 1.0 if hits_at_k(ranked, relevant, k) > 0 else 0.0


def ndcg_at_k(ranked, relevant, k: int) -> float:
    """Binary-gain NDCG: DCG = sum 1/log2(rank+1) over hits; ideal puts min(K, |relevant|) hits first."""
    if not relevant:
        return float("nan")
    dcg = sum(1 / math.log2(i + 2) for i, item in enumerate(ranked[:k]) if item in relevant)
    ideal = sum(1 / math.log2(i + 2) for i in range(min(k, len(relevant))))
    return dcg / ideal


METRICS = {"precision": precision_at_k, "recall": recall_at_k, "f1": f1_at_k,
           "ndcg": ndcg_at_k, "hit_rate": hit_rate_at_k}


def user_metrics(ranked: list[int], relevant: set[int], ks: list[int]) -> dict[str, float]:
    return {f"{name}@{k}": fn(ranked, relevant, k) for k in ks for name, fn in METRICS.items()}


def bootstrap_ci(values, n_boot: int = 2000, alpha: float = 0.05, seed: int = 42) -> tuple[float, float, float]:
    """(mean, low, high): percentile bootstrap over users."""
    v = np.asarray(values, dtype=float)
    if len(v) == 0:
        return float("nan"), float("nan"), float("nan")
    rng = np.random.default_rng(seed)
    means = v[rng.integers(0, len(v), size=(n_boot, len(v)))].mean(axis=1)
    return float(v.mean()), float(np.quantile(means, alpha / 2)), float(np.quantile(means, 1 - alpha / 2))


def paired_diff_ci(a, b, n_boot: int = 2000, alpha: float = 0.05, seed: int = 42) -> dict:
    """Mean of (a - b) over the SAME users with a bootstrap CI; `significant` = CI excludes zero."""
    d = np.asarray(a, dtype=float) - np.asarray(b, dtype=float)
    mean, lo, hi = bootstrap_ci(d, n_boot, alpha, seed)
    return {"mean_diff": mean, "low": lo, "high": hi, "significant": bool(lo > 0 or hi < 0)}
