"""Render evaluation results as Markdown. Synthetic data always gets a prominent warning banner."""
SYNTHETIC_BANNER = (
    "> **SYNTHETIC DEMO DATA: code verification only, NOT research results.** The demo ratings were generated "
    "from user genre affinity alone, independent of community messages, so this run cannot show whether "
    "community analysis helps. Run on real data (see docs/evaluation.md) for results you can report."
)
LABELS = {
    "random": "Random", "popularity": "Popularity (rating count)", "content_only": "A. Content-only",
    "cf_only": "B. Collaborative-only", "content_cf": "C. Content + Collaborative",
    "hybrid_no_community": "Hybrid without community (content+CF+preference)",
    "hybrid_default": "D. Full hybrid (default weights)", "hybrid_tuned": "D*. Full hybrid (weights tuned on validation)",
    "community_trend_only": "Community + trend only",
}


def _cell(d: dict) -> str:
    return f"{d['mean']:.3f} [{d['low']:.3f}, {d['high']:.3f}]"


def _table(summary: dict, k: int) -> list[str]:
    cols = [("precision", "Precision"), ("recall", "Recall"), ("f1", "F1"), ("ndcg", "NDCG"), ("hit_rate", "Hit rate")]
    lines = ["| Model | " + " | ".join(f"{n}@{k}" for _, n in cols) + " |", "|---|" + "---|" * len(cols)]
    for model, metrics in summary.items():
        lines.append(f"| {LABELS.get(model, model)} | " + " | ".join(_cell(metrics[f'{m}@{k}']) for m, _ in cols) + " |")
    return lines


def _paired(paired: dict, k: int) -> list[str]:
    lines = ["| Comparison (A vs B) | dNDCG@%d [95%% CI] | dRecall@%d [95%% CI] | Reliable? (judged on NDCG) |" % (k, k), "|---|---|---|---|"]
    for name, metrics in paired.items():
        n, r = metrics[f"ndcg@{k}"], metrics[f"recall@{k}"]
        a, b = name.split(" vs ")
        sig = "yes" if n["significant"] else "no (CI includes 0)"
        lines.append(f"| {LABELS.get(a, a)} vs {LABELS.get(b, b)} | {n['mean_diff']:+.3f} [{n['low']:+.3f}, {n['high']:+.3f}] "
                     f"| {r['mean_diff']:+.3f} [{r['low']:+.3f}, {r['high']:+.3f}] | {sig} |")
    return lines


def render_markdown(res: dict, synthetic: bool) -> str:
    c, d = res["config"], res["data"]
    out = ["# GameRec evaluation results", ""]
    if synthetic:
        out += [SYNTHETIC_BANNER, ""]
    out += [
        f"Data: {d['n_games']} games, {d['n_users_total']} users, {d['n_ratings']} ratings. "
        f"Evaluated users: {d['n_eval_users']} (skipped: {d['skipped']}). Mean candidate pool: {d['mean_candidate_pool']:.0f} games.",
        f"Protocol: per-user chronological split {c['split']}, relevant = rating >= {c['relevant_threshold']}, "
        f"95% bootstrap CIs over users ({c['bootstrap_resamples']} resamples), seed {c['seed']}.", ""]
    for w in res["warnings"]:
        out.append(f"- WARNING: {w}")
    t = res["tuning"]
    if t:
        out += ["", "## Weight tuning (validation split only)", "",
                f"Objective {t['metric']}, {t['trials']} candidate vectors. Default weights scored {t['default_val']:.3f} "
                f"on validation; best ({t['best_name']}) scored {t['best_val']:.3f}. Tuned weights: "
                + ", ".join(f"{k} {v:.2f}" for k, v in t["best_weights"].items()) + ". "
                "A validation gain can be noise; only the test table below counts."]
    for k in c["ks"]:
        out += ["", f"## Test results, K = {k}", "", *_table(res["test"]["summary"], k), "",
                f"### Paired differences, K = {k}", "", *_paired(res["test"]["paired"], k)]
    cs = res["cold_start"]
    out += ["", f"## Cold-start users (given first {c['cold_given']} ratings, {cs['n_users']} users)", ""]
    for k in c["ks"]:
        out += [f"### K = {k}", "", *_table(cs["summary"], k), "", *_paired(cs["paired"], k), ""]
    out += ["## Interpretation rules", "",
            "- A difference counts only if its paired CI excludes 0. Overlapping per-model CIs alone are not a test.",
            "- Compare against Random and Popularity; a model that does not beat them is not recommending anything useful.",
            "- Per-user chronological split, not a global time cutoff: CF can use other users' later ratings.",
            "- Unrated games count as non-relevant, which understates precision for every model equally."]
    return "\n".join(out) + "\n"
