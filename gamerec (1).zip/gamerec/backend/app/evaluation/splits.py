"""Chronological per-user train / validation / test split.

Each user's ratings are ordered by time; the earliest `train_frac` go to train, the next `val_frac` to
validation, the rest to test. This mimics real use (predict what a user will like NEXT) and avoids leaking
the future into the past. Users with fewer than `min_ratings` ratings are dropped.
A game is RELEVANT for a user if its held-out rating >= `relevant_threshold`.
"""
from dataclasses import dataclass

import pandas as pd


@dataclass
class UserSplit:
    user_id: int
    train: dict[int, float]
    val: dict[int, float]
    test: dict[int, float]


def chronological_split(ratings: pd.DataFrame, train_frac: float = 0.6, val_frac: float = 0.2,
                        min_ratings: int = 5) -> list[UserSplit]:
    """ratings: user_id, game_id, rating, created_at (rows without a rating are ignored)."""
    if not 0 < train_frac < 1 or not 0 <= val_frac < 1 or train_frac + val_frac >= 1:
        raise ValueError("Need 0 < train_frac, 0 <= val_frac and train_frac + val_frac < 1")
    df = ratings.dropna(subset=["rating"]).sort_values(["user_id", "created_at", "game_id"])
    out = []
    for uid, g in df.groupby("user_id"):
        if len(g) < min_ratings:
            continue
        n = len(g)
        n_train = max(2, round(n * train_frac))
        n_val = round(n * val_frac)
        n_train = min(n_train, n - 1 - n_val) if n - 1 - n_val >= 1 else n_train
        pairs = list(zip(g["game_id"].astype(int), g["rating"].astype(float)))
        out.append(UserSplit(int(uid), dict(pairs[:n_train]), dict(pairs[n_train:n_train + n_val]),
                             dict(pairs[n_train + n_val:])))
    return [s for s in out if s.test]
