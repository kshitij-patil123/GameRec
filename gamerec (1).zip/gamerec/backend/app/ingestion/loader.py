"""Load a DataSource into the database. Idempotent: reset=True wipes and reloads."""
import logging
import re

import pandas as pd
from sqlalchemy import delete, select
from sqlalchemy.orm import Session

from app.ingestion.sources import DataSource, hash_id
from app.models import (Game, GameGenre, GameTag, Genre, Message, Rating, Tag, User)

log = logging.getLogger(__name__)


def _split(value) -> list[str]:
    if value is None or pd.isna(value):
        return []
    return [p.strip() for p in str(value).split("|") if p.strip()]


def _none(v):
    return None if v is None or (not isinstance(v, str) and pd.isna(v)) else v


def _get_or_create(db: Session, model, cache: dict, name: str):
    obj = cache.get(name)
    if obj is None:
        obj = model(name=name)
        db.add(obj)
        cache[name] = obj
    return obj


def link_games_by_name(messages: pd.DataFrame, games: pd.DataFrame) -> pd.DataFrame:
    """For messages with no game_id, link by exact (case-insensitive) game-name mention."""
    names = {row.game_name: int(row.game_id) for row in games.itertuples()}
    patterns = {n: re.compile(rf"\b{re.escape(n)}\b", re.I) for n in names}

    def find(row):
        if pd.notna(row["game_id"]):
            return row["game_id"]
        hits = [gid for n, gid in names.items() if patterns[n].search(str(row["text"]))]
        return hits[0] if len(hits) == 1 else pd.NA  # ambiguous or none -> unlinked

    messages = messages.copy()
    messages["game_id"] = messages.apply(find, axis=1)
    return messages


def load_source(db: Session, source: DataSource, reset: bool = True) -> dict[str, int]:
    games, messages, ratings = source.games(), source.messages(), source.ratings()
    if reset:
        for model in (Rating, Message, GameTag, GameGenre, Game, Genre, Tag, User):
            db.execute(delete(model))
        db.flush()

    genre_cache = {g.name: g for g in db.scalars(select(Genre))}
    tag_cache = {t.name: t for t in db.scalars(select(Tag))}
    game_ids: dict[int, int] = {}  # source game_id -> db id

    for row in games.itertuples(index=False):
        game = Game(
            name=row.game_name, description=_none(row.description), platform=_none(row.platform),
            developer=_none(row.developer), publisher=_none(row.publisher),
            release_date=pd.to_datetime(_none(row.release_date), errors="coerce").to_pydatetime()
            if _none(row.release_date) is not None else None,
            rating=_none(row.rating),
        )
        game.genres = [_get_or_create(db, Genre, genre_cache, g) for g in _split(row.genre)]
        game.tags = [_get_or_create(db, Tag, tag_cache, t) for t in _split(row.tags)]
        db.add(game)
        db.flush()
        game_ids[int(row.game_id)] = game.id

    messages = link_games_by_name(messages, games)
    seen: set[str] = set()
    n_msgs = 0
    for row in messages.itertuples(index=False):
        ts = pd.to_datetime(row.timestamp, errors="coerce")
        text = _none(row.text)
        if pd.isna(ts) or text is None or str(row.message_id) in seen:
            continue  # invalid rows are skipped here; empties are handled in NLP preprocessing
        seen.add(str(row.message_id))
        gid = game_ids.get(int(row.game_id)) if pd.notna(row.game_id) else None
        author = _none(row.user_id)
        db.add(Message(
            external_id=str(row.message_id), source_type=source.source_type, game_id=gid,
            author_hash=None if author is None else (author if source.name == "discord_export" else hash_id(str(author))),
            text=str(text), created_at=ts.to_pydatetime(),
            engagement=int(row.engagement) if pd.notna(row.engagement) else 0,
        ))
        n_msgs += 1

    users: dict[str, User] = {}
    n_ratings = 0
    for row in ratings.itertuples(index=False):
        gid = game_ids.get(int(row.game_id))
        if gid is None:
            continue
        ext = str(row.user_id)
        user = users.get(ext)
        if user is None:
            user = User(external_id=ext, display_name=ext)
            db.add(user)
            db.flush()
            users[ext] = user
        db.add(Rating(
            user_id=user.id, game_id=gid,
            rating=None if pd.isna(row.rating) else float(row.rating),
            interaction=_none(row.interaction) or "rated",
            created_at=pd.to_datetime(row.timestamp).to_pydatetime() if pd.notna(row.timestamp) else pd.Timestamp.utcnow().to_pydatetime(),
        ))
        n_ratings += 1

    db.commit()
    counts = {"games": len(game_ids), "messages": n_msgs, "users": len(users), "ratings": n_ratings}
    log.info("Loaded %s data: %s", source.name, counts)
    return counts
