"""Interchangeable data sources. Every source returns the SAME three standard tables,
so the rest of the system never depends on where data came from.

Standard schema (see docs/data_dictionary.md):
  games:    game_id, game_name, description, genre, tags, platform, developer, publisher,
            release_date, rating                (genre/tags are '|' separated)
  messages: message_id, game_id (nullable), user_id, text, timestamp, engagement
  ratings:  user_id, game_id, rating, interaction, timestamp
"""
import hashlib
import json
from abc import ABC, abstractmethod
from pathlib import Path

import pandas as pd

from app.core.config import ROOT, get_settings

REQUIRED = {
    "games": ["game_id", "game_name"],
    "messages": ["message_id", "text", "timestamp"],
    "ratings": ["user_id", "game_id"],
}
OPTIONAL = {
    "games": ["description", "genre", "tags", "platform", "developer", "publisher", "release_date", "rating"],
    "messages": ["game_id", "user_id", "engagement"],
    "ratings": ["rating", "interaction", "timestamp"],
}


class SchemaError(ValueError):
    pass


def validate(table: str, df: pd.DataFrame) -> pd.DataFrame:
    """Check required columns, add missing optional ones as NaN, keep only standard columns."""
    missing = [c for c in REQUIRED[table] if c not in df.columns]
    if missing:
        raise SchemaError(f"{table}: missing required columns {missing}")
    for col in OPTIONAL[table]:
        if col not in df.columns:
            df[col] = pd.NA
    return df[REQUIRED[table] + OPTIONAL[table]].copy()


def hash_id(raw: str) -> str:
    """Pseudonymize user/author IDs so raw Discord IDs are never stored."""
    salted = f"{get_settings().user_hash_salt}:{raw}".encode()
    return hashlib.sha256(salted).hexdigest()[:32]


class DataSource(ABC):
    name: str
    source_type: str  # live | public | synthetic  (stored on every message row)
    is_demo: bool = False

    @abstractmethod
    def games(self) -> pd.DataFrame: ...
    @abstractmethod
    def messages(self) -> pd.DataFrame: ...
    @abstractmethod
    def ratings(self) -> pd.DataFrame: ...


class CsvSource(DataSource):
    """Reads games.csv / messages.csv / ratings.csv already in the standard schema."""

    def __init__(self, folder: Path, name: str, source_type: str, is_demo: bool = False):
        self.folder, self.name, self.source_type, self.is_demo = folder, name, source_type, is_demo

    def _read(self, table: str) -> pd.DataFrame:
        path = self.folder / f"{table}.csv"
        if not path.exists():
            raise FileNotFoundError(f"{path} not found")
        return validate(table, pd.read_csv(path))

    def games(self): return self._read("games")
    def messages(self): return self._read("messages")
    def ratings(self): return self._read("ratings")


class DiscordExportSource(CsvSource):
    """Messages from a legitimate Discord export (your own test server / permitted bot).

    Expects data/raw/discord_export.json: a list of
      {"id", "author_id", "content", "timestamp", "reactions"?, "game_id"?}
    Games and ratings still come from CSVs in data/raw. Author IDs are hashed on load.
    """

    def __init__(self, folder: Path):
        super().__init__(folder, name="discord_export", source_type="live")

    def messages(self) -> pd.DataFrame:
        path = self.folder / "discord_export.json"
        if not path.exists():
            raise FileNotFoundError(f"{path} not found (see docs/data_dictionary.md)")
        raw = pd.DataFrame(json.loads(path.read_text(encoding="utf-8")))
        df = pd.DataFrame({
            "message_id": raw["id"].astype(str),
            "game_id": raw.get("game_id"),
            "user_id": raw["author_id"].astype(str).map(hash_id),
            "text": raw["content"],
            "timestamp": raw["timestamp"],
            "engagement": raw.get("reactions", 0),
        })
        return validate("messages", df)


def get_source(kind: str | None = None) -> DataSource:
    kind = kind or get_settings().data_source
    if kind == "demo":
        return CsvSource(ROOT / "data" / "sample", "demo", "synthetic", is_demo=True)
    if kind == "public":
        return CsvSource(ROOT / "data" / "raw", "public", "public")
    if kind == "discord_export":
        return DiscordExportSource(ROOT / "data" / "raw")
    raise ValueError(f"Unknown DATA_SOURCE '{kind}' (use demo | public | discord_export)")
