import logging
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from app.api import analytics, games, recommendations, system, trending, users
from app.api.deps import reset_state
from app.core.config import get_settings
from app.core.db import Base, engine as default_engine
import app.models  # noqa: F401  (registers the tables)

logging.basicConfig(level=logging.INFO)
log = logging.getLogger("gamerec")


def ensure_schema(engine) -> bool:
    """Create missing tables (idempotent). Returns False, and logs, if the database cannot be reached."""
    try:
        Base.metadata.create_all(engine)
        return True
    except Exception:  # noqa: BLE001
        log.exception("Could not create/check database tables; check DATABASE_URL")
        return False


@asynccontextmanager
async def lifespan(app: FastAPI):
    ensure_schema(default_engine)   # an unloaded database then answers with empty counts / 503, not a 500
    yield


def create_app() -> FastAPI:
    settings = get_settings()
    app = FastAPI(title="GameRec API", version="0.2.0", lifespan=lifespan,
                  description="Community-aware, explainable game recommendations. Demo data is labeled via /meta.")
    app.add_middleware(CORSMiddleware, allow_origins=settings.cors_list, allow_methods=["GET", "POST"],
                       allow_headers=["Content-Type", "X-Admin-Token"])
    reset_state(app)
    for module in (system, games, trending, analytics, users, recommendations):
        app.include_router(module.router)

    @app.exception_handler(RequestValidationError)
    async def validation_error(_: Request, exc: RequestValidationError):
        errors = [{"field": ".".join(str(p) for p in e["loc"] if p != "body"), "message": e["msg"]} for e in exc.errors()]
        return JSONResponse(status_code=422, content={"detail": "Validation failed", "errors": errors})

    @app.exception_handler(Exception)
    async def unhandled(request: Request, exc: Exception):
        log.exception("Unhandled error on %s %s", request.method, request.url.path)
        return JSONResponse(status_code=500, content={"detail": "Internal server error"})

    return app


app = create_app()
