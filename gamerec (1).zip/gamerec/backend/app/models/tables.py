"""Normalized schema. Later phases add aspect_sentiments and score tables."""
from datetime import datetime

from sqlalchemy import (CheckConstraint, DateTime, Float, ForeignKey, Index, Integer,
                        String, Text, UniqueConstraint)
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.core.db import Base


class Game(Base):
    __tablename__ = "games"
    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(200), unique=True, index=True)
    description: Mapped[str | None] = mapped_column(Text)
    platform: Mapped[str | None] = mapped_column(String(100))
    developer: Mapped[str | None] = mapped_column(String(150))
    publisher: Mapped[str | None] = mapped_column(String(150))
    release_date: Mapped[datetime | None] = mapped_column(DateTime)
    rating: Mapped[float | None] = mapped_column(Float)
    genres: Mapped[list["Genre"]] = relationship(secondary="game_genres", back_populates="games")
    tags: Mapped[list["Tag"]] = relationship(secondary="game_tags", back_populates="games")


class Genre(Base):
    __tablename__ = "genres"
    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(80), unique=True)
    games: Mapped[list[Game]] = relationship(secondary="game_genres", back_populates="genres")


class Tag(Base):
    __tablename__ = "tags"
    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(80), unique=True)
    games: Mapped[list[Game]] = relationship(secondary="game_tags", back_populates="tags")


class GameGenre(Base):
    __tablename__ = "game_genres"
    game_id: Mapped[int] = mapped_column(ForeignKey("games.id", ondelete="CASCADE"), primary_key=True)
    genre_id: Mapped[int] = mapped_column(ForeignKey("genres.id", ondelete="CASCADE"), primary_key=True)


class GameTag(Base):
    __tablename__ = "game_tags"
    game_id: Mapped[int] = mapped_column(ForeignKey("games.id", ondelete="CASCADE"), primary_key=True)
    tag_id: Mapped[int] = mapped_column(ForeignKey("tags.id", ondelete="CASCADE"), primary_key=True)


class User(Base):
    __tablename__ = "users"
    id: Mapped[int] = mapped_column(primary_key=True)
    external_id: Mapped[str] = mapped_column(String(64), unique=True, index=True)
    display_name: Mapped[str | None] = mapped_column(String(100))
    password_hash: Mapped[str | None] = mapped_column(String(255))  # only if auth is added
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)


class Message(Base):
    """A community message or review. source_type keeps real vs synthetic data separate."""
    __tablename__ = "messages"
    id: Mapped[int] = mapped_column(primary_key=True)
    external_id: Mapped[str] = mapped_column(String(64))
    source_type: Mapped[str] = mapped_column(String(20))  # live | public | synthetic
    game_id: Mapped[int | None] = mapped_column(ForeignKey("games.id", ondelete="SET NULL"))
    author_hash: Mapped[str | None] = mapped_column(String(64))
    text: Mapped[str] = mapped_column(Text)
    created_at: Mapped[datetime] = mapped_column(DateTime)
    engagement: Mapped[int] = mapped_column(Integer, default=0)
    __table_args__ = (
        UniqueConstraint("source_type", "external_id"),
        CheckConstraint("source_type IN ('live','public','synthetic')", name="ck_msg_source"),
        Index("ix_messages_game_time", "game_id", "created_at"),
    )


class SentimentResult(Base):
    __tablename__ = "sentiment_results"
    id: Mapped[int] = mapped_column(primary_key=True)
    message_id: Mapped[int] = mapped_column(ForeignKey("messages.id", ondelete="CASCADE"))
    model_name: Mapped[str] = mapped_column(String(50))
    label: Mapped[str] = mapped_column(String(10))
    score: Mapped[float] = mapped_column(Float)  # -1..1
    __table_args__ = (
        UniqueConstraint("message_id", "model_name"),
        CheckConstraint("label IN ('positive','neutral','negative')", name="ck_sent_label"),
    )


class Topic(Base):
    __tablename__ = "topics"
    id: Mapped[int] = mapped_column(primary_key=True)
    label: Mapped[str | None] = mapped_column(String(80))
    keywords: Mapped[str] = mapped_column(Text)  # comma-separated top terms


class GameTopic(Base):
    __tablename__ = "game_topics"
    game_id: Mapped[int] = mapped_column(ForeignKey("games.id", ondelete="CASCADE"), primary_key=True)
    topic_id: Mapped[int] = mapped_column(ForeignKey("topics.id", ondelete="CASCADE"), primary_key=True)
    weight: Mapped[float] = mapped_column(Float)


class Rating(Base):
    __tablename__ = "ratings"
    id: Mapped[int] = mapped_column(primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"))
    game_id: Mapped[int] = mapped_column(ForeignKey("games.id", ondelete="CASCADE"))
    rating: Mapped[float | None] = mapped_column(Float)
    interaction: Mapped[str] = mapped_column(String(20), default="rated")  # rated|liked|disliked|played
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    __table_args__ = (
        UniqueConstraint("user_id", "game_id"),
        CheckConstraint("rating IS NULL OR (rating >= 1 AND rating <= 5)", name="ck_rating_range"),
        Index("ix_ratings_game", "game_id"),
    )


class Recommendation(Base):
    __tablename__ = "recommendations"
    id: Mapped[int] = mapped_column(primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"))
    game_id: Mapped[int] = mapped_column(ForeignKey("games.id", ondelete="CASCADE"))
    score: Mapped[float] = mapped_column(Float)
    explanation: Mapped[str | None] = mapped_column(Text)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)


class MessageTopic(Base):
    """Dominant discovered topic per message (enables topic frequency / trends in SQL)."""
    __tablename__ = "message_topics"
    message_id: Mapped[int] = mapped_column(ForeignKey("messages.id", ondelete="CASCADE"), primary_key=True)
    topic_id: Mapped[int] = mapped_column(ForeignKey("topics.id", ondelete="CASCADE"), index=True)
    weight: Mapped[float] = mapped_column(Float)


class AspectSentiment(Base):
    """Sentiment toward one aspect in one message (clause-level scoring)."""
    __tablename__ = "aspect_sentiments"
    id: Mapped[int] = mapped_column(primary_key=True)
    message_id: Mapped[int] = mapped_column(ForeignKey("messages.id", ondelete="CASCADE"))
    game_id: Mapped[int] = mapped_column(ForeignKey("games.id", ondelete="CASCADE"))
    aspect: Mapped[str] = mapped_column(String(40))
    label: Mapped[str] = mapped_column(String(10))
    score: Mapped[float] = mapped_column(Float)
    model_name: Mapped[str] = mapped_column(String(50))
    __table_args__ = (
        CheckConstraint("label IN ('positive','neutral','negative')", name="ck_aspect_label"),
        Index("ix_aspect_game_aspect", "game_id", "aspect"),
    )


class GameScore(Base):
    """Latest trend + community-intelligence scores per game (recomputed by scripts/run_trends.py)."""
    __tablename__ = "game_scores"
    game_id: Mapped[int] = mapped_column(ForeignKey("games.id", ondelete="CASCADE"), primary_key=True)
    as_of: Mapped[datetime] = mapped_column(DateTime)
    n_messages: Mapped[int] = mapped_column(Integer)
    recent_count: Mapped[int] = mapped_column(Integer)
    growth_ratio: Mapped[float] = mapped_column(Float)
    status: Mapped[str] = mapped_column(String(20))  # rising | stable | declining | insufficient data
    trend_score: Mapped[float] = mapped_column(Float)
    sentiment_component: Mapped[float | None] = mapped_column(Float)
    consistency_component: Mapped[float | None] = mapped_column(Float)
    volume_component: Mapped[float | None] = mapped_column(Float)
    aspect_component: Mapped[float | None] = mapped_column(Float)
    engagement_component: Mapped[float | None] = mapped_column(Float)
    community_score: Mapped[float | None] = mapped_column(Float)
    confidence: Mapped[float] = mapped_column(Float)  # n / (n + k): how much data backs the score


class UserPreference(Base):
    """Stated preferences. kind: genre | tag | aspect (value 0-1) | favorite_game (key = game id)."""
    __tablename__ = "user_preferences"
    id: Mapped[int] = mapped_column(primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"))
    kind: Mapped[str] = mapped_column(String(20))
    key: Mapped[str] = mapped_column(String(100))
    value: Mapped[float] = mapped_column(Float, default=1.0)
    __table_args__ = (
        UniqueConstraint("user_id", "kind", "key"),
        CheckConstraint("kind IN ('genre','tag','aspect','favorite_game')", name="ck_pref_kind"),
        CheckConstraint("value >= 0 AND value <= 1", name="ck_pref_value"),
    )
