"""Aspect-based sentiment analysis (rule-based aspect detection + clause-level sentiment).

Method
  1. Split a message into clauses at sentence punctuation and contrast words (but/however/...).
  2. Detect aspects in each clause with an aspect lexicon (categories are a design choice, as is
     standard in ABSA; the lexicon can be extended from discovered topic keywords).
  3. Score each clause with a sentiment model; every aspect in the clause gets that score.
  "story is great but performance is terrible" -> story: positive, performance: negative.

Limitations: several aspects in one clause share a score; sarcasm and implicit aspects are missed.
A fine-tuned ABSA transformer is the natural upgrade (see docs).
"""
import re

from app.nlp.sentiment import SentimentModel, vader_label

ASPECT_LEXICON: dict[str, list[str]] = {
    "story": ["story", "plot", "narrative", "characters", "character", "writing", "lore", "ending", "storyline"],
    "graphics": ["graphics", "visuals", "art style", "art", "animation", "textures", "visual", "artstyle"],
    "combat": ["combat", "fighting", "weapons", "boss", "bosses", "melee", "gunplay", "battles"],
    "difficulty": ["difficulty", "difficulty curve", "challenging", "too hard", "too easy", "difficult"],
    "performance": ["performance", "fps", "lag", "framerate", "frame rate", "optimization", "optimisation",
                    "stutter", "stuttering", "crashes", "crash"],
    "multiplayer": ["multiplayer", "co-op", "coop", "online", "matchmaking", "servers", "pvp", "netcode"],
    "music": ["music", "soundtrack", "audio", "sound design", "ost", "sound"],
    "price": ["price", "cost", "expensive", "worth", "value", "dlc", "microtransactions", "pricing"],
    "bugs": ["bug", "bugs", "glitch", "glitches", "buggy", "broken", "patch"],
    "exploration": ["exploration", "explore", "open world", "map", "world design", "exploring"],
}
ASPECTS = list(ASPECT_LEXICON)

# Terms that carry sentiment themselves ("expensive", "buggy", "lag") stay visible to the sentiment
# model. All other aspect terms are masked as "it" first: lexicon-based scorers such as VADER treat
# words like "combat" or "fighting" as negative, which would bias every game's combat score.
SENTIMENT_BEARING = {"expensive", "buggy", "broken", "challenging", "difficult", "too hard", "too easy", "lag",
                     "stutter", "stuttering", "crash", "crashes", "bug", "bugs", "glitch", "glitches", "worth"}

_CLAUSE_SPLIT = re.compile(r"[.!?;\n]+|\b(?:but|however|although|though|yet)\b", re.I)
_PATTERNS = {
    a: re.compile(r"\b(?:" + "|".join(re.escape(t) for t in sorted(terms, key=len, reverse=True)) + r")\b", re.I)
    for a, terms in ASPECT_LEXICON.items()
}


_MASK = re.compile(r"\b(?:" + "|".join(re.escape(t) for t in sorted(
    {t for terms in ASPECT_LEXICON.values() for t in terms} - SENTIMENT_BEARING, key=len, reverse=True)) + r")\b", re.I)


def mask_aspect_terms(clause: str) -> str:
    return _MASK.sub("it", clause)


def split_clauses(text: str) -> list[str]:
    return [c.strip() for c in _CLAUSE_SPLIT.split(text or "") if c and c.strip()]


def find_aspects(clause: str) -> list[str]:
    return [a for a, pat in _PATTERNS.items() if pat.search(clause)]


def extract_mentions(text: str) -> list[tuple[str, str]]:
    """[(aspect, clause)] for every aspect found in the message."""
    return [(a, c) for c in split_clauses(text) for a in find_aspects(c)]


def score_aspects(texts: list[str], model: SentimentModel) -> list[list[tuple[str, str, float]]]:
    """For each text: [(aspect, label, score)]. One batched model call for all clauses."""
    mentions = [extract_mentions(t) for t in texts]
    clauses = [mask_aspect_terms(c) for m in mentions for _, c in m]
    preds = model.predict(clauses, clauses) if clauses else []
    out, k = [], 0
    for m in mentions:
        row = []
        for aspect, _ in m:
            _, score = preds[k]
            row.append((aspect, vader_label(score) if model.name == "vader" else preds[k][0], score))
            k += 1
        out.append(row)
    return out
