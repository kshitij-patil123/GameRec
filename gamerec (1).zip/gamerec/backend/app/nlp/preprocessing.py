"""Text preprocessing.

Two views of every message are kept on purpose:
  * text_original -> lightly normalized only (URLs/mentions replaced, whitespace fixed).
    Case, punctuation, emoji and negations are preserved for VADER and transformers,
    which rely on them ("AMAZING!!!", "not good", ":)").
  * text_clean    -> aggressively normalized tokens for classical NLP (TF-IDF, LDA/NMF,
    keywords), where noise words only dilute the vocabulary.
Stopword removal keeps negations ("not", "no", "never"), because dropping them flips meaning.
"""
import logging
import re
from functools import lru_cache

import pandas as pd
from sklearn.feature_extraction.text import ENGLISH_STOP_WORDS

log = logging.getLogger(__name__)

URL_RE = re.compile(r"https?://\S+|www\.\S+")
MENTION_RE = re.compile(r"<@[!&]?\d+>|@\w+")
CUSTOM_EMOJI_RE = re.compile(r"<a?:\w+:\d+>")
NON_TOKEN_RE = re.compile(r"[^a-z0-9\s]")
WS_RE = re.compile(r"\s+")
# common emoji/emoticon ranges + variation selectors
EMOJI_RE = re.compile("[\U0001F300-\U0001FAFF\U00002600-\U000027BF\U0000FE0F\U0000200D]")

NEGATIONS = {"no", "not", "nor", "never", "none", "nothing", "neither", "cannot", "cant", "wont", "dont"}
STOPWORDS = frozenset(ENGLISH_STOP_WORDS) - NEGATIONS - {"very", "too", "well", "good", "best", "better"}

# Opinion/filler words describe HOW people feel (handled by sentiment), not WHAT they discuss,
# so keyword and topic models drop them, and negations too. Sentiment models keep both.
OPINION_WORDS = frozenset({
    "great", "good", "bad", "amazing", "awesome", "love", "loving", "like", "really", "just", "honestly",
    "honest", "right", "well", "recommend", "nothing", "special", "okay", "fine", "guess", "terrible",
    "awful", "best", "better", "worst", "disappointing", "tonight", "tried", "anyone", "curious",
    "thought", "need", "serious", "mess", "ruin", "fix", "blow", "blew", "away", "dev", "devs", "100",
    "think", "thing", "game", "play", "playing", "lol", "tbh", "not", "no", "never", "cant", "cannot",
})
TOPIC_STOPWORDS = frozenset(STOPWORDS | NEGATIONS | OPINION_WORDS)

SLANG = {"tbh": "to be honest", "imo": "in my opinion", "idk": "i do not know", "ez": "easy",
         "gg": "good game", "op": "overpowered", "wtf": "what the hell", "lol": "", "lmao": "",
         "u": "you", "ur": "your", "rn": "right now", "smh": "", "fps": "fps", "ngl": "not gonna lie"}
EMOJI_WORDS = {"🔥": "great", "👍": "good", "❤️": "love", "❤": "love", "😍": "love",
               "😡": "angry", "👎": "bad", "🤮": "terrible", "💀": "", "😂": ""}


def normalize_light(text: object) -> str:
    """View for VADER/transformers: replace noise, keep everything that carries sentiment."""
    if text is None or (not isinstance(text, str) and pd.isna(text)):
        return ""
    s = URL_RE.sub(" ", str(text))
    s = CUSTOM_EMOJI_RE.sub(" ", s)
    s = MENTION_RE.sub("@user", s)
    return WS_RE.sub(" ", s).strip()


@lru_cache(maxsize=1)
def _lemmatize_fn():
    """WordNet lemmatizer; downloads the corpus once, falls back to identity if unavailable."""
    try:
        import nltk
        from nltk.stem import WordNetLemmatizer
        lem = WordNetLemmatizer()
        try:
            lem.lemmatize("tests")
        except LookupError:
            nltk.download("wordnet", quiet=True)
            lem.lemmatize("tests")
        return lambda w: lem.lemmatize(lem.lemmatize(w, "v"), "n")
    except Exception as exc:  # noqa: BLE001
        log.warning("WordNet unavailable (%s); lemmatization disabled", exc)
        return lambda w: w


def normalize_classical(text: object, handle_emoji: bool = True, normalize_slang: bool = True,
                        lemmatize: bool = True, remove_stopwords: bool = True) -> str:
    """Cleaned token string for TF-IDF / topic models / keyword extraction."""
    s = normalize_light(text)
    if not s:
        return ""
    if handle_emoji:
        for emo, word in EMOJI_WORDS.items():
            s = s.replace(emo, f" {word} ")
    s = EMOJI_RE.sub(" ", s).lower().replace("@user", " ")
    s = re.sub(r"n't\b", " not", s)          # don't -> do not, keeps the negation
    s = s.replace("'", "")
    s = NON_TOKEN_RE.sub(" ", s)
    tokens = []
    for tok in s.split():
        if normalize_slang and tok in SLANG:
            tokens.extend(SLANG[tok].split())
        else:
            tokens.append(tok)
    if remove_stopwords:
        tokens = [t for t in tokens if t not in STOPWORDS]
    if lemmatize:
        lem = _lemmatize_fn()
        tokens = [lem(t) for t in tokens]
    return " ".join(t for t in tokens if len(t) > 1 or t.isdigit())


def preprocess_frame(df: pd.DataFrame, text_col: str = "text", group_col: str | None = None) -> pd.DataFrame:
    """Add text_original, text_clean, is_valid, is_duplicate columns (rows are never dropped).

    is_valid:     cleaned text has at least one token (empty/emoji-only/punctuation-only -> False)
    is_duplicate: same cleaned text already seen (within group_col if given), e.g. spam/copy-paste
    Callers filter on these flags, so nothing is lost silently.
    """
    out = df.copy()
    out["text_original"] = out[text_col].map(normalize_light)
    out["text_clean"] = out[text_col].map(normalize_classical)
    out["is_valid"] = out["text_clean"].str.len() > 0
    keys = [out[group_col], out["text_clean"]] if group_col else [out["text_clean"]]
    out["is_duplicate"] = pd.concat(keys, axis=1).duplicated() & out["is_valid"]
    return out
