"""Sentiment models behind one interface: predict(originals, cleaned) -> [(label, score)].

score is in [-1, 1]. Models:
  VaderModel        lexicon baseline, needs no training, uses the ORIGINAL-style text
  TfidfLogRegModel  classical supervised baseline, uses the CLEANED text, needs labels
  TransformerModel  stronger pretrained model (optional deps), uses the ORIGINAL-style text
"""
from abc import ABC, abstractmethod

import numpy as np

LABELS = ["negative", "neutral", "positive"]


class SentimentModel(ABC):
    name: str

    @abstractmethod
    def predict(self, originals: list[str], cleaned: list[str]) -> list[tuple[str, float]]: ...


def vader_label(compound: float, threshold: float = 0.05) -> str:
    """Standard VADER convention: >= 0.05 positive, <= -0.05 negative, else neutral."""
    if compound >= threshold:
        return "positive"
    if compound <= -threshold:
        return "negative"
    return "neutral"


class VaderModel(SentimentModel):
    name = "vader"

    def __init__(self) -> None:
        from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer
        self._analyzer = SentimentIntensityAnalyzer()

    def predict(self, originals, cleaned=None):
        out = []
        for text in originals:
            compound = self._analyzer.polarity_scores(text)["compound"]
            out.append((vader_label(compound), float(compound)))
        return out


class TfidfLogRegModel(SentimentModel):
    name = "tfidf_logreg"

    def __init__(self, random_state: int = 42) -> None:
        from sklearn.feature_extraction.text import TfidfVectorizer
        from sklearn.linear_model import LogisticRegression
        from sklearn.pipeline import Pipeline
        self._pipe = Pipeline([
            ("tfidf", TfidfVectorizer(ngram_range=(1, 2), min_df=2, sublinear_tf=True)),
            ("clf", LogisticRegression(max_iter=1000, class_weight="balanced", random_state=random_state)),
        ])

    def fit(self, cleaned: list[str], labels: list[str]) -> "TfidfLogRegModel":
        self._pipe.fit(cleaned, labels)
        return self

    def predict(self, originals, cleaned):
        proba = self._pipe.predict_proba(cleaned)
        classes = list(self._pipe.classes_)
        pos = proba[:, classes.index("positive")] if "positive" in classes else 0.0
        neg = proba[:, classes.index("negative")] if "negative" in classes else 0.0
        labels = np.array(classes)[proba.argmax(axis=1)]
        return [(str(l), float(s)) for l, s in zip(labels, pos - neg)]


class TransformerModel(SentimentModel):
    """Pretrained 3-class model. Default: cardiffnlp/twitter-roberta-base-sentiment-latest
    (trained on social-media text, outputs negative/neutral/positive). Needs
    `pip install -r requirements-transformer.txt` and internet access to download weights."""
    name = "transformer"

    def __init__(self, model_id: str = "cardiffnlp/twitter-roberta-base-sentiment-latest",
                 batch_size: int = 32) -> None:
        from transformers import pipeline  # lazy: keeps the base install light
        self._pipe = pipeline("text-classification", model=model_id, top_k=None,
                              truncation=True, max_length=128)
        self._batch = batch_size

    def predict(self, originals, cleaned=None):
        out = []
        for scores in self._pipe(list(originals), batch_size=self._batch):
            by_label = {s["label"].lower(): s["score"] for s in scores}
            label = max(by_label, key=by_label.get)
            out.append((label, float(by_label.get("positive", 0) - by_label.get("negative", 0))))
        return out


def get_model(name: str) -> SentimentModel:
    if name == "vader":
        return VaderModel()
    if name == "transformer":
        return TransformerModel()
    raise ValueError(f"'{name}' cannot be built without training data; use TfidfLogRegModel().fit(...)")
