"""Item-item collaborative filtering on mean-centered ratings.

fit():     users x items matrix -> centered by each user's mean -> cosine between item columns
           (missing entries count as 0), then shrunk by co-rating count: sim * n / (n + lambda), so two items
           rated together by only one user do not look perfectly similar.
predict(): for a user's ratings r, predicted rating of item i =
               mean_u + sum_j sim(i,j) * (r_j - mean_u) / sum_j |sim(i,j)|    over the k most similar rated items
           (mean_u = the user's mean shrunk toward the global mean, so a single rating still carries signal)
           It takes the ratings as an argument, so users who just rated something in the UI (or were not in the
           training data at all) get predictions without refitting.
Cold start: no ratings -> no prediction (the hybrid engine drops this component). New items with no ratings
have no similarity and get NaN. The dense item x item matrix is fine for thousands of items; use sparse
neighbor lists beyond that.
"""
import numpy as np
import pandas as pd
from scipy import sparse

INTERACTION_RATINGS = {"liked": 4.5, "disliked": 1.5, "played": 3.5}


def implicit_rating(rating: float | None, interaction: str | None = None) -> float | None:
    """Explicit rating if present, otherwise a rating implied by the interaction type, else None."""
    if rating is not None and not pd.isna(rating):
        return float(rating)
    return INTERACTION_RATINGS.get(interaction or "")


class ItemItemCF:
    def __init__(self, k_neighbors: int = 20, shrinkage: float = 3.0, mean_shrinkage: float = 2.0) -> None:
        self.k, self.shrinkage, self.mean_shrinkage = k_neighbors, shrinkage, mean_shrinkage
        self.global_mean = 3.0
        self.items: list[int] = []
        self.index: dict[int, int] = {}
        self.sim = np.zeros((0, 0))

    def fit(self, ratings: pd.DataFrame) -> "ItemItemCF":
        """ratings: user_id, game_id, rating (rows without a rating are ignored)."""
        df = ratings.dropna(subset=["rating"]).drop_duplicates(["user_id", "game_id"], keep="last")
        self.global_mean = float(df["rating"].mean()) if not df.empty else 3.0
        self.items = sorted(int(g) for g in df["game_id"].unique())
        self.index = {g: i for i, g in enumerate(self.items)}
        if df.empty:
            self.sim = np.zeros((0, 0))
            return self
        users = {u: i for i, u in enumerate(df["user_id"].unique())}
        rows, cols = df["user_id"].map(users).to_numpy(), df["game_id"].map(self.index).to_numpy()
        centered = (df["rating"] - df.groupby("user_id")["rating"].transform("mean")).to_numpy()
        shape = (len(users), len(self.items))
        Xc = sparse.csr_matrix((centered, (rows, cols)), shape=shape)
        B = sparse.csr_matrix((np.ones(len(df)), (rows, cols)), shape=shape)
        num = (Xc.T @ Xc).toarray()
        norms = np.sqrt(np.diag(num))
        denom = np.outer(norms, norms)
        sim = np.divide(num, denom, out=np.zeros_like(num), where=denom > 1e-12)
        co = (B.T @ B).toarray()
        sim *= co / (co + self.shrinkage)
        np.fill_diagonal(sim, 0.0)
        self.sim = sim
        return self

    def predict(self, user_ratings: dict[int, float]) -> pd.Series:
        """Predicted 1-5 rating per item (NaN where no similar rated item exists). Rated items are excluded."""
        known = {self.index[g]: r for g, r in user_ratings.items() if g in self.index}
        if not known or self.sim.size == 0:
            return pd.Series(dtype=float)
        # The user's mean is shrunk toward the global mean: with plain mean-centering, a user with one rating
        # (or all equal ratings) would have zero deviation and the signal would vanish.
        vals = list(user_ratings.values())
        mean_u = (sum(vals) + self.mean_shrinkage * self.global_mean) / (len(vals) + self.mean_shrinkage)
        rated = np.array(list(known))
        centered = np.array([known[i] - mean_u for i in rated])
        out: dict[int, float] = {}
        for i, game_id in enumerate(self.items):
            if i in known:
                continue
            s = self.sim[i, rated]
            c = centered
            if self.k and len(s) > self.k:
                top = np.argsort(-np.abs(s))[: self.k]
                s, c = s[top], c[top]
            den = np.abs(s).sum()
            out[game_id] = float(np.clip(mean_u + (s @ c) / den, 1, 5)) if den > 1e-9 else np.nan
        return pd.Series(out, dtype=float)

    def similar_items(self, game_id: int, n: int = 10) -> list[tuple[int, float]]:
        if game_id not in self.index:
            return []
        s = self.sim[self.index[game_id]]
        return [(self.items[j], float(s[j])) for j in np.argsort(-s)[:n] if s[j] > 0]
