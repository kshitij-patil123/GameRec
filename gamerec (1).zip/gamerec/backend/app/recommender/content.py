"""Content-based recommender: TF-IDF blocks + cosine similarity.

A game is the concatenation of four TF-IDF blocks (genres, tags, description, community keywords), each
L2-normalized and scaled by sqrt(weight). The dot product of two games is therefore the weighted mean of
their per-block cosine similarities (weights sum to 1), which keeps scores interpretable.

Scores are raw cosines; the hybrid engine (Phase 10) min-max normalizes them with the other components.
Cold start:
  * new user -> recommend_for_preferences(genres, tags, favorite games)
  * new game -> vector_for_metadata(...) builds a vector from metadata alone; a game missing a block simply
    has zeros there (lower similarity, never a crash)
"""
from dataclasses import dataclass

import numpy as np
import pandas as pd
from scipy import sparse
from sklearn.feature_extraction.text import TfidfVectorizer

DEFAULT_BLOCK_WEIGHTS = {"genres": 0.30, "tags": 0.30, "description": 0.25, "keywords": 0.15}
INTERACTION_WEIGHTS = {"liked": 1.5, "disliked": -1.5, "played": 0.25}


class UnknownGameError(KeyError):
    pass


def _identity(x):
    return x


def _tokens(values) -> list[str]:
    return [str(v).strip().lower().replace(" ", "_") for v in (values or []) if str(v).strip()]


def rating_to_weight(rating: float | None, interaction: str | None = None) -> float:
    """Preference weight for building a user profile. Ratings are centered at 3 (neutral), so a 1-star
    game pushes the profile AWAY from similar games. Without a rating, fall back to the interaction type."""
    if rating is not None and not pd.isna(rating):
        return float(rating) - 3.0
    return INTERACTION_WEIGHTS.get(interaction or "", 0.0)


@dataclass
class _Block:
    name: str
    vectorizer: TfidfVectorizer | None
    matrix: sparse.csr_matrix


class ContentRecommender:
    def __init__(self, block_weights: dict | None = None) -> None:
        w = {**DEFAULT_BLOCK_WEIGHTS, **(block_weights or {})}
        total = sum(w.values())
        self.weights = {k: v / total for k, v in w.items()}

    # ---------- fitting ----------
    def fit(self, games: pd.DataFrame) -> "ContentRecommender":
        """games: game_id, genres (list), tags (list), description (str), keywords (str, optional)."""
        self.games = games.reset_index(drop=True)
        self.ids = self.games["game_id"].tolist()
        self.index = {gid: i for i, gid in enumerate(self.ids)}
        docs = {
            "genres": [_tokens(x) for x in self.games["genres"]],
            "tags": [_tokens(x) for x in self.games["tags"]],
            "description": self.games["description"].fillna("").astype(str).tolist(),
            "keywords": (self.games["keywords"] if "keywords" in self.games else pd.Series([""] * len(self.games)))
            .fillna("").astype(str).tolist(),
        }
        self._blocks: dict[str, _Block] = {}
        for name, d in docs.items():
            vec = self._make_vectorizer(name)
            try:
                mat = vec.fit_transform(d)
            except ValueError:  # empty vocabulary: this block carries no information
                vec, mat = None, sparse.csr_matrix((len(d), 0))
            self._blocks[name] = _Block(name, vec, mat)
        self.matrix = self._combine({n: b.matrix for n, b in self._blocks.items()})
        return self

    @staticmethod
    def _make_vectorizer(name: str) -> TfidfVectorizer:
        if name in ("genres", "tags"):
            return TfidfVectorizer(analyzer=_identity, sublinear_tf=True)
        if name == "description":
            return TfidfVectorizer(stop_words="english", ngram_range=(1, 2), sublinear_tf=True)
        return TfidfVectorizer(sublinear_tf=True)

    def _combine(self, mats: dict[str, sparse.spmatrix]) -> sparse.csr_matrix:
        parts = [mats[n] * np.sqrt(self.weights[n]) for n in self._blocks if mats[n].shape[1] > 0]
        rows = next(iter(mats.values())).shape[0]
        return sparse.hstack(parts, format="csr") if parts else sparse.csr_matrix((rows, 0))

    # ---------- vectors ----------
    def vector_for_metadata(self, genres=None, tags=None, description: str | None = None,
                            keywords: str | None = None) -> sparse.csr_matrix:
        """Project raw metadata into the fitted space (new game, or a new user's stated preferences)."""
        docs = {"genres": [_tokens(genres)], "tags": [_tokens(tags)],
                "description": [description or ""], "keywords": [keywords or ""]}
        mats = {}
        for name, b in self._blocks.items():
            width = b.matrix.shape[1]
            mats[name] = b.vectorizer.transform(docs[name]) if b.vectorizer is not None else sparse.csr_matrix((1, width))
        return self._combine(mats)

    @staticmethod
    def _cosine(query, matrix: sparse.spmatrix) -> np.ndarray:
        """Cosine of `query` (dense 1-D or sparse row) to every row of `matrix`; zeros if either is empty."""
        q = np.asarray(query.todense()).ravel() if sparse.issparse(query) else np.asarray(query).ravel()
        q_norm = np.linalg.norm(q)
        if q_norm < 1e-12 or matrix.shape[1] == 0:
            return np.zeros(matrix.shape[0])
        row_norms = np.sqrt(np.asarray(matrix.multiply(matrix).sum(axis=1)).ravel())
        sims = np.asarray(matrix @ q).ravel()
        return sims / (q_norm * np.where(row_norms < 1e-12, 1.0, row_norms))

    def _top(self, scores: np.ndarray, n: int, exclude: set[int]) -> list[tuple[int, float]]:
        order = np.argsort(-scores)
        return [(self.ids[i], float(scores[i])) for i in order if self.ids[i] not in exclude][:n]

    def _check(self, game_id: int) -> int:
        if game_id not in self.index:
            raise UnknownGameError(game_id)
        return self.index[game_id]

    # ---------- public API ----------
    def similarity_scores(self, game_id: int) -> dict[int, float]:
        """Cosine similarity of one game to every game (itself excluded)."""
        i = self._check(game_id)
        s = self._cosine(self.matrix[i], self.matrix)
        return {gid: float(s[j]) for j, gid in enumerate(self.ids) if gid != game_id}

    def similar_games(self, game_id: int, n: int = 10) -> list[tuple[int, float]]:
        return sorted(self.similarity_scores(game_id).items(), key=lambda kv: -kv[1])[:n]

    def profile_vector(self, weighted_games: dict[int, float]) -> np.ndarray:
        """Weighted sum of item vectors. Weights from rating_to_weight(); unknown games are ignored."""
        vec = np.zeros(self.matrix.shape[1])
        for gid, w in weighted_games.items():
            if gid in self.index and w != 0:
                vec += w * np.asarray(self.matrix[self.index[gid]].todense()).ravel()
        return vec

    def score_for_profile(self, weighted_games: dict[int, float]) -> dict[int, float]:
        """Cosine of every game to the user's profile vector ({} if the profile carries no signal)."""
        s = self._cosine(self.profile_vector(weighted_games), self.matrix)
        if not np.any(s):
            return {}
        return {gid: float(s[j]) for j, gid in enumerate(self.ids)}

    def recommend(self, weighted_games: dict[int, float], n: int = 10, exclude_seen: bool = True):
        scores = self.score_for_profile(weighted_games)
        if not scores:
            return []
        seen = set(weighted_games) if exclude_seen else set()
        return sorted(((g, s) for g, s in scores.items() if g not in seen), key=lambda kv: -kv[1])[:n]

    def recommend_for_preferences(self, genres=None, tags=None, favorite_game_ids=None, n: int = 10):
        """Cold-start user: stated genres/tags (+ optional favorite games), no rating history needed."""
        query = np.asarray(self.vector_for_metadata(genres=genres, tags=tags).todense()).ravel()
        if np.linalg.norm(query) > 0:
            query = query / np.linalg.norm(query)
        fav = [g for g in (favorite_game_ids or []) if g in self.index]
        if fav:
            fv = sum(np.asarray(self.matrix[self.index[g]].todense()).ravel() for g in fav)
            query = query + fv / max(np.linalg.norm(fv), 1e-12)
        s = self._cosine(query, self.matrix)
        if not np.any(s):
            return []
        return self._top(s, n, set(fav))

    def similar_to_new_game(self, genres=None, tags=None, description=None, n: int = 10):
        """Cold-start game: which existing games are closest to a game with only metadata?"""
        s = self._cosine(self.vector_for_metadata(genres, tags, description), self.matrix)
        return self._top(s, n, set()) if np.any(s) else []

    def shared_features(self, game_id: int, other_ids: list[int]) -> dict[str, list[str]]:
        """Genres/tags `game_id` shares with any of other_ids (used by explanations)."""
        row = self.games.iloc[self._check(game_id)]
        others = [self.games.iloc[self.index[o]] for o in other_ids if o in self.index]
        out = {}
        for col in ("genres", "tags"):
            mine = set(_tokens(row[col]))
            theirs = set().union(*[set(_tokens(o[col])) for o in others]) if others else set()
            out[col] = sorted(mine & theirs)
        return out
