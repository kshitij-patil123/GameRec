"""Explanations built ONLY from statistics that actually support each statement (no filler claims).

Each reason is {"type", "text", "positive"}; caveats (positive=False) keep the explanation honest.
Thresholds are module constants so they can be tuned and tested.
"""
import pandas as pd

from app.recommender.profile import UserProfile

MIN_CONTENT_SIM = 0.20      # raw cosine in this project's feature space
MIN_PRED_RATING = 3.8
MIN_SENTIMENT01 = 0.60
LOW_SENTIMENT01 = 0.45
MIN_CONFIDENCE = 0.5
MIN_ASPECT_PREF = 0.5
GOOD_ASPECT, BAD_ASPECT = 0.2, -0.1
MIN_TREND = 0.6


def _join(items: list[str]) -> str:
    return items[0] if len(items) == 1 else ", ".join(items[:-1]) + " and " + items[-1]


def build_reasons(game_id: int, raw: pd.Series, profile: UserProfile, content, collab, game_info: pd.DataFrame,
                  aspect_scores: pd.DataFrame) -> list[dict]:
    reasons: list[dict] = []
    add = lambda t, text, pos=True: reasons.append({"type": t, "text": text, "positive": pos})  # noqa: E731
    name = lambda gid: str(game_info.at[gid, "name"]) if gid in game_info.index else str(gid)  # noqa: E731
    info = game_info.loc[game_id]

    # 1. content similarity with games the user liked
    liked = {g for g, w in profile.weighted_games.items() if w > 0}
    if liked and game_id in content.index:
        sims = content.similarity_scores(game_id)
        best = sorted(((sims[g], g) for g in liked if g in sims), reverse=True)[:2]
        best = [(s, g) for s, g in best if s >= MIN_CONTENT_SIM]
        if best:
            add("content", f"{round(100 * best[0][0])}% content similarity with {_join([name(g) for _, g in best])}, "
                           f"which you liked")

    # 2. genre / tag match with the profile
    genres = [g for g in info["genres"] if profile.genre_weights.get(g, 0) > 0.3]
    tags = [t for t in info["tags"] if profile.tag_weights.get(t, 0) > 0.3]
    if genres or tags:
        parts = []
        if genres:
            parts.append(f"genres ({_join(genres)})" if len(genres) > 1 else f"{genres[0]} genre")
        if tags:
            parts.append(f"tags ({_join(tags)})" if len(tags) > 1 else f"{tags[0]} tag")
        add("preference", f"Matches your preferred {' and '.join(parts)}")

    # 3. collaborative filtering
    pred = raw.get("collaborative_rating")
    if pred is not None and not pd.isna(pred) and pred >= MIN_PRED_RATING:
        neighbors = [(s, g) for g, s in collab.similar_items(game_id, 25) if profile.ratings.get(g, 0) >= 4]
        if neighbors:
            add("collaborative", f"Players who liked {name(neighbors[0][1])} also liked this "
                                 f"(predicted rating {pred:.1f}/5 for you)")
        else:
            add("collaborative", f"Players with similar tastes are predicted to rate it {pred:.1f}/5 for you")

    # 4. community sentiment (with data-sufficiency honesty)
    s01, conf = info.get("sentiment"), info.get("confidence")
    if pd.notna(s01) and pd.notna(conf):
        pos = info.get("pos_pct")
        pos_txt = f" ({pos:.0f}% positive messages)" if pd.notna(pos) else ""
        if conf < MIN_CONFIDENCE:
            add("community", "Limited community data so far, so community signals carry less weight", False)
        elif s01 >= MIN_SENTIMENT01:
            add("community", f"Strong positive community sentiment{pos_txt}")
        elif s01 <= LOW_SENTIMENT01:
            add("community", f"Community sentiment is mixed to negative overall{pos_txt}", False)

    # 5. aspects the user cares about
    if profile.aspect_prefs and game_id in aspect_scores.index:
        row = aspect_scores.loc[game_id]
        wanted = [(p, a) for a, p in profile.aspect_prefs.items() if p >= MIN_ASPECT_PREF and a in row.index]
        good = [a for p, a in sorted(wanted, reverse=True) if row[a] >= GOOD_ASPECT][:3]
        bad = [a for p, a in sorted(wanted, reverse=True) if row[a] <= BAD_ASPECT][:2]
        if good:
            add("aspect", f"Community sentiment is high for what you care about: {_join([a.title() for a in good])}")
        if bad:
            add("aspect", f"Caveat: the community is negative about {_join([a.title() for a in bad])}", False)

    # 6. trend
    if info.get("status") == "rising" and info.get("trend", 0) >= MIN_TREND:
        add("trend", "Currently trending: discussion about it is rising")
    elif info.get("status") == "declining":
        add("trend", "Caveat: discussion activity is declining", False)

    if not any(r["positive"] for r in reasons):
        add("overall", "Ranks well overall across the available signals (no single strong reason stood out)")
    return reasons
