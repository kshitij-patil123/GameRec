"""Interpretable weighted hybrid recommender.

Components per candidate game (all computed from the user's profile):
  content        cosine to the user's content profile (and/or stated genres/tags)
  collaborative  item-item CF predicted rating (needs >= min_ratings_for_cf ratings)
  preference     genre/tag match with the user's genre_weights/tag_weights
  community      shrunk community sentiment (game_scores.sentiment_component)
  trend          trend score
  aspect         sum_a pref_a * aspect_sentiment01[game, a] / sum_a pref_a

Each component is min-max normalized across the candidate set, then
  final = sum_c w_c * norm_c / sum_c w_c      over components that are available and have w_c > 0.
Unavailable components (no ratings -> no CF; no aspect data -> no aspect match) are dropped and the remaining
weights renormalized, which is also the cold-start behavior: with no user signal at all, only community and
trend remain, i.e. popular/trending games. Games missing a component (for example no community data yet)
get the neutral value 0.5 for it.
Weights are configurable per call: set a weight to 0 to run an ablation (content-only, etc.).
"""
from dataclasses import dataclass, field

import numpy as np
import pandas as pd

from app.analytics.trends import minmax
from app.recommender.explain import build_reasons
from app.recommender.profile import COLD_START_MIN_RATINGS, UserProfile

DEFAULT_WEIGHTS = {"content": 0.30, "collaborative": 0.25, "preference": 0.15,
                   "community": 0.15, "trend": 0.10, "aspect": 0.05}
COMPONENTS = list(DEFAULT_WEIGHTS)


@dataclass
class Recommendation:
    game_id: int
    name: str
    score: float                      # 0-1 final hybrid score
    match_percent: int
    components: dict[str, float]      # normalized 0-1 per available component
    contributions: dict[str, float]   # weight_share * component (sums to score), for charts
    reasons: list[dict] = field(default_factory=list)
    strategy: str = "hybrid"


def validate_weights(weights: dict | None) -> dict[str, float]:
    w = {**DEFAULT_WEIGHTS, **(weights or {})}
    unknown = set(w) - set(COMPONENTS)
    if unknown:
        raise ValueError(f"Unknown weight(s): {sorted(unknown)}")
    if any(v < 0 for v in w.values()) or sum(w.values()) <= 0:
        raise ValueError("Weights must be non-negative and not all zero")
    return w


class HybridRecommender:
    def __init__(self, content, collab, game_info: pd.DataFrame, aspect_scores: pd.DataFrame | None = None,
                 weights: dict | None = None, min_ratings_for_cf: int = COLD_START_MIN_RATINGS) -> None:
        """game_info: index game_id; columns name, genres, tags, sentiment (0-1), trend (0-1), status,
        confidence, pos_pct (optional). aspect_scores: game x aspect in [-1, 1]."""
        self.content, self.collab, self.game_info = content, collab, game_info
        self.aspect_scores = aspect_scores if aspect_scores is not None else pd.DataFrame()
        self.weights = validate_weights(weights)
        self.min_ratings_for_cf = min_ratings_for_cf

    # ---------- component scores ----------
    def _content_scores(self, p: UserProfile, ids: pd.Index) -> pd.Series:
        parts = []
        if any(w != 0 for w in p.weighted_games.values()):
            s = self.content.score_for_profile(p.weighted_games)
            if s:
                parts.append(pd.Series(s))
        if p.stated_genres or p.stated_tags:
            r = self.content.recommend_for_preferences(p.stated_genres, p.stated_tags, None, n=len(self.content.ids))
            if r:
                parts.append(pd.Series(dict(r)))
        if not parts:
            return pd.Series(np.nan, index=ids)
        return pd.concat([minmax(s.reindex(ids).fillna(0)) for s in parts], axis=1).mean(axis=1)

    def _preference_scores(self, p: UserProfile, ids: pd.Index) -> pd.Series:
        if not (p.genre_weights or p.tag_weights):
            return pd.Series(np.nan, index=ids)
        def score(gid):
            g, t = self.game_info.at[gid, "genres"], self.game_info.at[gid, "tags"]
            gs = np.mean([p.genre_weights.get(x, 0.0) for x in g]) if g else 0.0
            ts = np.mean([p.tag_weights.get(x, 0.0) for x in t]) if t else 0.0
            return 0.6 * gs + 0.4 * ts
        return pd.Series({gid: score(gid) for gid in ids})

    def _aspect_scores(self, p: UserProfile, ids: pd.Index) -> pd.Series:
        prefs = {a: v for a, v in p.aspect_prefs.items() if a in self.aspect_scores.columns and v > 0}
        if not prefs or self.aspect_scores.empty:
            return pd.Series(np.nan, index=ids)
        s01 = (self.aspect_scores[list(prefs)].reindex(ids) + 1) / 2
        w = pd.Series(prefs)
        return (s01 * w).sum(axis=1) / w.sum()

    def raw_components(self, p: UserProfile, candidates: list[int]) -> pd.DataFrame:
        ids = pd.Index(candidates)
        raw = pd.DataFrame(index=ids, columns=COMPONENTS, dtype=float)
        raw["content"] = self._content_scores(p, ids)
        raw["collaborative_rating"] = np.nan
        if p.n_ratings >= self.min_ratings_for_cf:
            pred = self.collab.predict(p.ratings).reindex(ids)
            if pred.notna().any():
                raw["collaborative_rating"] = pred
                raw["collaborative"] = pred.fillna(np.mean(list(p.ratings.values())))  # no evidence -> user's mean
        raw["preference"] = self._preference_scores(p, ids)
        raw["community"] = self.game_info["sentiment"].reindex(ids)
        raw["trend"] = self.game_info["trend"].reindex(ids)
        raw["aspect"] = self._aspect_scores(p, ids)
        return raw

    # ---------- ranking ----------
    def final_scores(self, raw: pd.DataFrame, weights: dict | None = None):
        """Combine raw component scores into final scores (sorted desc).

        Returns (final, norm, contrib), where norm/contrib only have the active components. Split out from
        recommend() so the evaluation harness can compute raw components once and re-score many weight vectors.
        """
        w = validate_weights({**self.weights, **(weights or {})})
        active = [c for c in COMPONENTS if w[c] > 0 and raw[c].notna().any()]
        if not active:
            empty = pd.DataFrame(index=raw.index)
            return pd.Series(dtype=float), empty, empty
        norm = pd.DataFrame({c: minmax(raw[c].astype(float)) if raw[c].notna().all()
                             else minmax(raw[c]).fillna(0.5) for c in active}, index=raw.index)
        share = pd.Series({c: w[c] for c in active}) / sum(w[c] for c in active)
        contrib = norm.mul(share, axis=1)
        final = contrib.sum(axis=1).clip(0, 1).sort_values(ascending=False, kind="stable")  # clip: float rounding
        return final, norm, contrib

    def recommend(self, profile: UserProfile, n: int = 10, weights: dict | None = None,
                  explain: bool = True) -> list[Recommendation]:
        candidates = [g for g in self.game_info.index if g not in profile.seen]
        if not candidates:
            return []
        raw = self.raw_components(profile, candidates)
        final, norm, contrib = self.final_scores(raw, weights)
        if final.empty:
            return self._catalog_fallback(candidates, n)
        if not profile.has_signal:
            strategy = "popular_trending"
        elif profile.n_ratings < self.min_ratings_for_cf:
            strategy = "cold_start_preferences"
        else:
            strategy = "hybrid"
        out = []
        for gid in final.index[:n]:
            reasons = (build_reasons(gid, raw.loc[gid], profile, self.content, self.collab, self.game_info,
                                     self.aspect_scores) if explain else [])
            out.append(Recommendation(
                game_id=int(gid), name=str(self.game_info.at[gid, "name"]), score=float(final[gid]),
                match_percent=int(round(100 * final[gid])), components=norm.loc[gid].to_dict(),
                contributions=contrib.loc[gid].to_dict(), reasons=reasons, strategy=strategy))
        return out

    def _catalog_fallback(self, candidates: list[int], n: int) -> list[Recommendation]:
        """No component is usable (no ratings, no stated preferences, no community data yet): list games by
        catalog rating (unknown ratings last, then by id) and say so, instead of returning nothing."""
        rating = (self.game_info["catalog_rating"].reindex(candidates) if "catalog_rating" in self.game_info
                  else pd.Series(np.nan, index=candidates))
        score = minmax(rating).fillna(0.0) if rating.notna().any() else pd.Series(0.0, index=candidates)
        order = sorted(candidates, key=lambda g: (-float(score[g]), g))[:n]
        reason = [{"type": "overall", "positive": True,
                   "text": "No personal or community signals are available yet, so games are listed by catalog rating"}]
        return [Recommendation(game_id=int(g), name=str(self.game_info.at[g, "name"]), score=float(score[g]),
                               match_percent=int(round(100 * score[g])), components={}, contributions={},
                               reasons=list(reason), strategy="catalog_fallback") for g in order]

    def explain_one(self, profile: UserProfile, game_id: int, weights: dict | None = None):
        """(Recommendation with reasons, rank, n_candidates) for one game, or None if the user has seen it
        or it does not exist. Ranks everything without reasons first; only this game gets explained."""
        ranked = self.recommend(profile, n=len(self.game_info), weights=weights, explain=False)
        for rank, rec in enumerate(ranked, 1):
            if rec.game_id == game_id:
                raw = self.raw_components(profile, [game_id]).loc[game_id]
                rec.reasons = build_reasons(game_id, raw, profile, self.content, self.collab, self.game_info,
                                            self.aspect_scores)
                return rec, rank, len(ranked)
        return None
