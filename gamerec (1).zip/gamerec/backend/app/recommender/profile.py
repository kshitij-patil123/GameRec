"""User preference profile: what the user likes, as vectors the recommenders can use.

Sources: star ratings / interactions, stated genres and tags, favorite games, optional aspect sliders.
  weighted_games  game -> preference weight (rating - 3; favorites count as a 5-star)
  genre/tag_weights in [-1, 1]: positive for liked genres, negative for genres of poorly rated games
  aspect_prefs    in [0, 1]: how much the user cares about each aspect. Inferred from liked games as
                  sum(weight * attention * max(aspect sentiment, 0)): attention is the share of that game's
                  community talk about the aspect, and only PRAISED aspects count, so a liked game with lots
                  of complaints about bugs does not make "bugs" a user priority. If the user sets ANY aspect
                  slider (Low/Medium/High = 0.2/0.5/0.9), the stated aspects are authoritative and inference
                  is not used, so inferred priorities cannot outrank what the user said.
"""
from dataclasses import dataclass, field

import pandas as pd

from app.recommender.collaborative import implicit_rating
from app.recommender.content import rating_to_weight

STATED_GENRE_WEIGHT = 2.0   # as if the user had rated a game of that genre 5 stars
STATED_TAG_WEIGHT = 1.0
FAVORITE_WEIGHT = 2.0
COLD_START_MIN_RATINGS = 3
ASPECT_LEVELS = {"low": 0.2, "medium": 0.5, "high": 0.9}


@dataclass
class UserProfile:
    user_id: int | None = None
    ratings: dict[int, float] = field(default_factory=dict)           # game -> (implied) 1-5 rating, for CF
    weighted_games: dict[int, float] = field(default_factory=dict)    # game -> preference weight, for content
    favorite_ids: list[int] = field(default_factory=list)
    stated_genres: list[str] = field(default_factory=list)
    stated_tags: list[str] = field(default_factory=list)
    genre_weights: dict[str, float] = field(default_factory=dict)
    tag_weights: dict[str, float] = field(default_factory=dict)
    aspect_prefs: dict[str, float] = field(default_factory=dict)

    @property
    def n_ratings(self) -> int:
        return len(self.ratings)

    @property
    def seen(self) -> set[int]:
        return set(self.ratings) | set(self.weighted_games) | set(self.favorite_ids)

    @property
    def has_signal(self) -> bool:
        return bool(self.ratings or self.favorite_ids or self.stated_genres or self.stated_tags)


def _normalize(weights: dict[str, float]) -> dict[str, float]:
    peak = max((abs(v) for v in weights.values()), default=0.0)
    return {k: v / peak for k, v in weights.items()} if peak > 0 else {}


def build_profile(user_id: int | None, rating_rows, stated_genres=None, stated_tags=None, favorite_ids=None,
                  explicit_aspects: dict[str, float] | None = None, game_meta: pd.DataFrame | None = None,
                  attention: pd.DataFrame | None = None,
                  aspect_sentiment: pd.DataFrame | None = None) -> UserProfile:
    """rating_rows: iterable of (game_id, rating, interaction). game_meta: index game_id, columns genres, tags."""
    p = UserProfile(user_id=user_id, stated_genres=list(stated_genres or []), stated_tags=list(stated_tags or []),
                    favorite_ids=[int(g) for g in (favorite_ids or [])])
    for gid, rating, interaction in rating_rows:
        value = implicit_rating(rating, interaction)
        if value is not None:
            p.ratings[int(gid)] = value
        w = rating_to_weight(rating, interaction)
        if w != 0:
            p.weighted_games[int(gid)] = w
    for gid in p.favorite_ids:
        p.ratings.setdefault(gid, 5.0)
        p.weighted_games[gid] = max(p.weighted_games.get(gid, 0.0), FAVORITE_WEIGHT)

    genres: dict[str, float] = {}
    tags: dict[str, float] = {}
    if game_meta is not None:
        for gid, w in p.weighted_games.items():
            if gid in game_meta.index:
                for g in game_meta.at[gid, "genres"]:
                    genres[g] = genres.get(g, 0.0) + w
                for t in game_meta.at[gid, "tags"]:
                    tags[t] = tags.get(t, 0.0) + w
    for g in p.stated_genres:
        genres[g] = genres.get(g, 0.0) + STATED_GENRE_WEIGHT
    for t in p.stated_tags:
        tags[t] = tags.get(t, 0.0) + STATED_TAG_WEIGHT
    p.genre_weights, p.tag_weights = _normalize(genres), _normalize(tags)

    inferred: dict[str, float] = {}
    if attention is not None and not attention.empty:
        for gid, w in p.weighted_games.items():
            if w > 0 and gid in attention.index:
                for aspect, share in attention.loc[gid].items():
                    praise = 1.0
                    if aspect_sentiment is not None and gid in aspect_sentiment.index and aspect in aspect_sentiment.columns:
                        praise = max(float(aspect_sentiment.at[gid, aspect]), 0.0)
                    inferred[aspect] = inferred.get(aspect, 0.0) + w * share * praise
    p.aspect_prefs = ({a: float(v) for a, v in explicit_aspects.items()} if explicit_aspects
                      else _normalize(inferred))
    return p
