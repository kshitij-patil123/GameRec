"""Request/response models. Requests are strictly validated; extra fields are rejected."""
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

from app.nlp.aspects import ASPECTS

Interaction = Literal["rated", "liked", "disliked", "played"]


class Strict(BaseModel):
    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True)


# ---------- requests ----------
class UserCreate(Strict):
    display_name: str = Field(min_length=1, max_length=100)


class RatingIn(Strict):
    game_id: int = Field(gt=0)
    rating: float | None = Field(default=None, ge=1, le=5)
    interaction: Interaction | None = None

    @model_validator(mode="after")
    def need_rating_or_interaction(self):
        if self.rating is None and (self.interaction in (None, "rated")):
            raise ValueError("Provide a rating (1-5) or an interaction of liked/disliked/played")
        if self.interaction is None:
            self.interaction = "rated"
        return self


class PreferencesIn(Strict):
    """Provided fields REPLACE the stored ones; omitted fields are left unchanged; [] / {} clears."""
    genres: list[str] | None = Field(default=None, max_length=20)
    tags: list[str] | None = Field(default=None, max_length=30)
    favorite_game_ids: list[int] | None = Field(default=None, max_length=20)
    aspects: dict[str, float] | None = None

    @field_validator("aspects")
    @classmethod
    def valid_aspects(cls, v):
        if v is None:
            return v
        bad = [k for k in v if k not in ASPECTS]
        if bad:
            raise ValueError(f"Unknown aspect(s) {bad}; allowed: {ASPECTS}")
        if any(not 0 <= x <= 1 for x in v.values()):
            raise ValueError("Aspect values must be between 0 and 1")
        return v


# ---------- responses ----------
class GameSummary(BaseModel):
    id: int
    name: str
    genres: list[str]
    tags: list[str]
    platforms: list[str]
    developer: str | None = None
    publisher: str | None = None
    release_date: str | None = None
    rating: float | None = None
    description: str | None = None
    community_score: float | None = None
    trend_score: float | None = None
    status: str | None = None
    confidence: float | None = None
    n_messages: int | None = None
    positive_pct: float | None = None
    avg_sentiment: float | None = None


class GameList(BaseModel):
    items: list[GameSummary]
    total: int
    limit: int
    offset: int


class UserOut(BaseModel):
    id: int
    display_name: str | None
    n_ratings: int = 0


class RecommendationItem(BaseModel):
    rank: int
    game: GameSummary
    score: float
    match_percent: int
    components: dict[str, float]
    contributions: dict[str, float]
    reasons: list[dict]
    strategy: str


class RecommendationResponse(BaseModel):
    user_id: int
    strategy: str
    n_ratings: int
    weights: dict[str, float]
    is_demo: bool
    note: str = "match_percent is relative to the other candidate games, not a probability of liking the game."
    items: list[RecommendationItem]
