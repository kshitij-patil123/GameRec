"""Store aspect sentiments and build the per-game aspect profile the recommender consumes."""
import logging

import pandas as pd
from sqlalchemy import delete, select
from sqlalchemy.orm import Session

from app.models import AspectSentiment
from app.nlp.aspects import ASPECTS, score_aspects
from app.nlp.sentiment import SentimentModel
from app.services.corpus import load_corpus

log = logging.getLogger(__name__)

POS_T, NEG_T = 0.2, -0.2     # mean-score thresholds for the game-level aspect label
MIXED_SHARE = 0.3            # both positive and negative mention shares >= this -> Mixed
MIN_MENTIONS = 5


def analyze_aspects(db: Session, model: SentimentModel, reset: bool = True) -> int:
    if reset:
        db.execute(delete(AspectSentiment).where(AspectSentiment.model_name == model.name))
    corpus = load_corpus(db, require_game=True)
    if corpus.empty:
        return 0
    results = score_aspects(corpus["text_original"].tolist(), model)
    rows = [AspectSentiment(message_id=int(mid), game_id=int(gid), aspect=a, label=lab, score=s,
                            model_name=model.name)
            for mid, gid, res in zip(corpus["id"], corpus["game_id"], results) for a, lab, s in res]
    db.add_all(rows)
    db.commit()
    log.info("Stored %d aspect sentiments from %d messages", len(rows), len(corpus))
    return len(rows)


def _load(db: Session, model_name: str) -> pd.DataFrame:
    q = select(AspectSentiment.game_id, AspectSentiment.aspect, AspectSentiment.label,
               AspectSentiment.score).where(AspectSentiment.model_name == model_name)
    return pd.DataFrame(db.execute(q).all(), columns=["game_id", "aspect", "label", "score"])


def game_aspect_stats(db: Session, model_name: str = "vader", min_mentions: int = MIN_MENTIONS) -> list[dict]:
    """Per game+aspect: mentions, mean score, pos/neg share, label (Positive/Negative/Mixed/Neutral
    or 'Insufficient data' below min_mentions)."""
    df = _load(db, model_name)
    stats = []
    for (gid, aspect), g in df.groupby(["game_id", "aspect"]):
        n, mean = len(g), float(g["score"].mean())
        pos, neg = (g["label"] == "positive").mean(), (g["label"] == "negative").mean()
        if n < min_mentions:
            label = "Insufficient data"
        elif mean >= POS_T:
            label = "Positive"
        elif mean <= NEG_T:
            label = "Negative"
        elif pos >= MIXED_SHARE and neg >= MIXED_SHARE:
            label = "Mixed"
        else:
            label = "Neutral"
        stats.append({"game_id": int(gid), "aspect": aspect, "n_mentions": n, "mean_score": round(mean, 3),
                      "positive_share": round(float(pos), 3), "negative_share": round(float(neg), 3),
                      "label": label})
    return stats


def game_aspect_matrix(db: Session, model_name: str = "vader", prior_strength: float = 5.0) -> pd.DataFrame:
    """game_id x aspect matrix of shrunk mean sentiment in [-1, 1].

    Shrinkage pulls games with few mentions toward the aspect's global mean:
      (sum + k * prior) / (n + k), so 2 glowing mentions cannot outrank 200 solid ones.
    Aspects never mentioned for a game get the prior. Used by the recommender's aspect match.
    """
    df = _load(db, model_name)
    if df.empty:
        return pd.DataFrame(columns=ASPECTS)
    prior = df.groupby("aspect")["score"].mean()
    agg = df.groupby(["game_id", "aspect"])["score"].agg(["sum", "count"]).reset_index()
    agg["shrunk"] = (agg["sum"] + prior_strength * agg["aspect"].map(prior)) / (agg["count"] + prior_strength)
    mat = agg.pivot(index="game_id", columns="aspect", values="shrunk").reindex(columns=ASPECTS)
    return mat.fillna(prior.reindex(ASPECTS)).fillna(0.0)


def game_aspect_attention(db: Session, model_name: str = "vader") -> pd.DataFrame:
    """game_id x aspect matrix of mention SHARE (rows sum to 1): how much of a game's aspect talk is
    about each aspect, i.e. what the game is 'about' according to its community."""
    df = _load(db, model_name)
    if df.empty:
        return pd.DataFrame(columns=ASPECTS)
    counts = df.groupby(["game_id", "aspect"]).size().unstack(fill_value=0).reindex(columns=ASPECTS, fill_value=0)
    return counts.div(counts.sum(axis=1), axis=0)
