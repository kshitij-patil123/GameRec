"""Build the content recommender from the database and read a user's rating history."""
import pandas as pd
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.analytics.keywords import distinctive_keywords, name_stopwords
from app.models import Game, Rating
from app.recommender.content import ContentRecommender, rating_to_weight
from app.services.corpus import load_corpus


def games_frame(db: Session, use_keywords: bool = True) -> pd.DataFrame:
    games = list(db.scalars(select(Game)))
    kw: dict[int, str] = {}
    if use_keywords:
        corpus = load_corpus(db, require_game=True)
        if not corpus.empty:
            found = distinctive_keywords(corpus["text_clean"].tolist(), corpus["game_id"].astype(int).tolist(),
                                         n=15, extra_stop=name_stopwords([g.name for g in games]))
            # unigrams only: bigrams would double-count their words in the TF-IDF block
            kw = {gid: " ".join(t for t, _ in terms if " " not in t) for gid, terms in found.items()}
    return pd.DataFrame([{
        "game_id": g.id, "name": g.name, "description": g.description or "",
        "genres": [x.name for x in g.genres], "tags": [x.name for x in g.tags],
        "keywords": kw.get(g.id, ""),
    } for g in games])


def build_content_recommender(db: Session, use_keywords: bool = True,
                              block_weights: dict | None = None) -> ContentRecommender:
    df = games_frame(db, use_keywords)
    if df.empty:
        raise ValueError("No games in the database")
    return ContentRecommender(block_weights).fit(df)


def user_weighted_games(db: Session, user_id: int) -> dict[int, float]:
    """{game_id: preference weight} from the user's ratings/interactions."""
    rows = db.execute(select(Rating.game_id, Rating.rating, Rating.interaction).where(Rating.user_id == user_id)).all()
    return {gid: rating_to_weight(r, i) for gid, r, i in rows}
