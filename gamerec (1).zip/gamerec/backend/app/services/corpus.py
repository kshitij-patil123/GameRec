"""Shared loader: the cleaned corpus that keyword/topic/aspect analysis all work on."""
import pandas as pd
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.models import Message
from app.nlp.preprocessing import preprocess_frame


def load_corpus(db: Session, require_game: bool = False) -> pd.DataFrame:
    """Valid, non-duplicate messages with text_original / text_clean columns.

    Columns: id, game_id, created_at, text, text_original, text_clean, engagement.
    """
    rows = db.execute(select(Message.id, Message.game_id, Message.created_at, Message.text,
                             Message.engagement)).all()
    df = pd.DataFrame(rows, columns=["id", "game_id", "created_at", "text", "engagement"])
    if df.empty:
        return df.assign(text_original="", text_clean="")
    df["created_at"] = pd.to_datetime(df["created_at"])
    df = preprocess_frame(df.assign(_g=df["game_id"].fillna(-1)), group_col="_g")
    df = df[df["is_valid"] & ~df["is_duplicate"]]
    if require_game:
        df = df[df["game_id"].notna()]
    return df.drop(columns=["_g", "is_valid", "is_duplicate"]).reset_index(drop=True)
