"""Read-side queries for the API (kept out of the routers so they stay thin and testable)."""
import pandas as pd
from sqlalchemy import func, literal, select
from sqlalchemy.orm import Session

from app.analytics.keywords import distinctive_keywords, emerging_keywords, name_stopwords, top_keywords
from app.models import (AspectSentiment, Game, GameScore, GameTopic, Genre, Message, Rating,
                        SentimentResult, Tag, Topic)
from app.nlp.aspects import ASPECTS
from app.services.aspect_service import game_aspect_matrix, game_aspect_stats
from app.services.corpus import load_corpus
from app.services.sentiment_service import game_sentiment_stats
from app.services.topic_service import topic_frequency, topic_trends
from app.services.trend_service import genre_popularity, message_volume_timeline, sentiment_timeline

MODEL = "vader"


# ---------- meta ----------
def data_meta(db: Session) -> dict:
    kinds = dict(db.execute(select(Message.source_type, func.count()).group_by(Message.source_type)).all())
    count = lambda m: db.scalar(select(func.count()).select_from(m))  # noqa: E731
    only_synth = set(kinds) <= {"synthetic"}
    return {
        "message_source_types": kinds,
        "is_demo": only_synth,
        "banner": "Demo mode: synthetic sample data, not real community data." if only_synth else None,
        "counts": {"games": count(Game), "messages": count(Message), "ratings": count(Rating)},
        "pipeline": {"sentiment": count(SentimentResult) > 0, "aspects": count(AspectSentiment) > 0,
                     "topics": count(Topic) > 0, "scores": count(GameScore) > 0},
    }


# ---------- games ----------
def _sent_map(db: Session) -> dict[int, dict]:
    return {s["game_id"]: s for s in game_sentiment_stats(db, MODEL)}


def summary(g: Game, sc: GameScore | None, sent: dict | None) -> dict:
    return {
        "id": g.id, "name": g.name, "genres": [x.name for x in g.genres], "tags": [x.name for x in g.tags],
        "platforms": g.platform.split("|") if g.platform else [], "developer": g.developer,
        "publisher": g.publisher, "release_date": g.release_date.date().isoformat() if g.release_date else None,
        "rating": g.rating, "description": g.description,
        "community_score": sc.community_score if sc else None, "trend_score": sc.trend_score if sc else None,
        "status": sc.status if sc else None, "confidence": sc.confidence if sc else None,
        "n_messages": sc.n_messages if sc else None,
        "positive_pct": sent["positive_pct"] if sent else None,
        "avg_sentiment": sent["avg_sentiment"] if sent else None,
    }


def summaries(db: Session, games: list[Game]) -> list[dict]:
    ids = [g.id for g in games]
    scores = {s.game_id: s for s in db.scalars(select(GameScore).where(GameScore.game_id.in_(ids)))} if ids else {}
    sent = _sent_map(db) if ids else {}
    return [summary(g, scores.get(g.id), sent.get(g.id)) for g in games]


SORTS = {"name": Game.name, "rating": Game.rating, "release_date": Game.release_date,
         "community_score": GameScore.community_score, "trend_score": GameScore.trend_score}


def list_games(db: Session, q: str | None, genre: str | None, platform: str | None, min_rating: float | None,
               sort: str, order: str, limit: int, offset: int) -> tuple[list[dict], int]:
    stmt = select(Game).outerjoin(GameScore, GameScore.game_id == Game.id)
    if q:
        stmt = stmt.where(func.lower(Game.name).contains(q.lower(), autoescape=True))
    if genre:
        stmt = stmt.where(Game.genres.any(func.lower(Genre.name) == genre.lower()))
    if platform:
        padded = literal("|").concat(func.coalesce(Game.platform, "")).concat("|")
        stmt = stmt.where(func.lower(padded).contains(f"|{platform.lower()}|", autoescape=True))
    if min_rating is not None:
        stmt = stmt.where(Game.rating >= min_rating)
    total = db.scalar(select(func.count()).select_from(stmt.subquery()))
    col = SORTS[sort]
    col = col.desc().nulls_last() if order == "desc" else col.asc().nulls_last()
    games = list(db.scalars(stmt.order_by(col, Game.id).limit(limit).offset(offset)).unique())
    return summaries(db, games), total


def filter_options(db: Session) -> dict:
    platforms = sorted({p for (plat,) in db.execute(select(Game.platform)) if plat for p in plat.split("|")})
    return {"genres": sorted(db.scalars(select(Genre.name))), "platforms": platforms,
            "tags": sorted(db.scalars(select(Tag.name))), "aspects": ASPECTS,
            "sort_options": list(SORTS)}


# ---------- per-game community analysis ----------
def community_analysis(db: Session, game: Game, keywords: list[str], freq: str = "W") -> dict:
    sent = next((s for s in game_sentiment_stats(db, MODEL) if s["game_id"] == game.id), None)
    aspects = [s for s in game_aspect_stats(db, MODEL) if s["game_id"] == game.id]
    topics = db.execute(select(Topic.id, Topic.label, Topic.keywords, GameTopic.weight)
                        .join(GameTopic, GameTopic.topic_id == Topic.id).where(GameTopic.game_id == game.id)
                        .order_by(GameTopic.weight.desc()).limit(5)).all()
    vol = message_volume_timeline(db, freq, game.id)
    sen = sentiment_timeline(db, MODEL, freq, game.id)
    timeline = vol.merge(sen[["period", "mean"]].rename(columns={"mean": "mean_sentiment"}), on="period", how="left")
    sc = db.get(GameScore, game.id)
    return {
        "game_id": game.id, "name": game.name,
        "sentiment": sent,
        "aspects": sorted(aspects, key=lambda a: -a["n_mentions"]),
        "keywords": keywords,
        "topics": [{"id": t, "label": lbl, "keywords": kw.split(", ")[:6], "weight": round(w, 3)} for t, lbl, kw, w in topics],
        "timeline": [{"period": r.period.date().isoformat(), "n_messages": int(r.n_messages),
                      "mean_sentiment": None if pd.isna(r.mean_sentiment) else round(float(r.mean_sentiment), 3)}
                     for r in timeline.itertuples()],
        "scores": None if sc is None else {
            "community_score": sc.community_score, "trend_score": sc.trend_score, "status": sc.status,
            "growth_ratio": sc.growth_ratio, "confidence": sc.confidence, "n_messages": sc.n_messages,
            "components": {"sentiment": sc.sentiment_component, "consistency": sc.consistency_component,
                           "volume": sc.volume_component, "aspect": sc.aspect_component,
                           "engagement": sc.engagement_component, "trend": sc.trend_score}},
        "note": "Aggregated statistics only; raw messages and author identifiers are never returned.",
    }


def per_game_keywords(db: Session, n: int = 10) -> dict[int, list[str]]:
    corpus = load_corpus(db, require_game=True)
    if corpus.empty:
        return {}
    extra = name_stopwords(list(db.scalars(select(Game.name))))
    found = distinctive_keywords(corpus["text_clean"].tolist(), corpus["game_id"].astype(int).tolist(), n, extra)
    return {int(g): [t for t, _ in terms] for g, terms in found.items()}


# ---------- trending / analytics ----------
def trending_games(db: Session, limit: int) -> list[dict]:
    rows = db.execute(select(Game, GameScore).join(GameScore, GameScore.game_id == Game.id)
                      .order_by(GameScore.trend_score.desc()).limit(limit)).all()
    sent = _sent_map(db)
    return [{**summary(g, s, sent.get(g.id)), "growth_ratio": s.growth_ratio, "recent_count": s.recent_count}
            for g, s in rows]


def trending_topics(db: Session, limit: int, recent_periods: int = 4, prior_periods: int = 8) -> list[dict]:
    shares = topic_trends(db, "W")
    if shares.empty:
        return []
    recent = shares.tail(recent_periods).mean()
    earlier = shares.iloc[:-recent_periods].tail(prior_periods)
    prior = earlier.mean() if len(earlier) else pd.Series(0.0, index=shares.columns)
    kw = {t.label: t.keywords.split(", ")[:6] for t in db.scalars(select(Topic))}
    out = [{"label": lbl, "keywords": kw.get(lbl, []), "recent_share": round(float(recent[lbl]), 4),
            "previous_share": round(float(prior.get(lbl, 0)), 4),
            "change": round(float(recent[lbl] - prior.get(lbl, 0)), 4),
            "series": [{"period": p.date().isoformat(), "share": round(float(v), 4)} for p, v in shares[lbl].items()]}
           for lbl in shares.columns]
    return sorted(out, key=lambda t: -t["change"])[:limit]


def sentiment_overview(db: Session) -> dict:
    rows = db.execute(select(SentimentResult.label, func.count(), func.avg(SentimentResult.score))
                      .where(SentimentResult.model_name == MODEL).group_by(SentimentResult.label)).all()
    total = sum(n for _, n, _ in rows)
    dist = {lbl: round(100 * n / total, 1) for lbl, n, _ in rows} if total else {}
    timeline = sentiment_timeline(db, MODEL, "W")
    share_rows = db.execute(select(Message.created_at, SentimentResult.label)
                            .join(SentimentResult, SentimentResult.message_id == Message.id)
                            .where(SentimentResult.model_name == MODEL)).all()
    shares = []
    if share_rows:
        df = pd.DataFrame(share_rows, columns=["created_at", "label"])
        df["period"] = pd.to_datetime(df["created_at"]).dt.to_period("W").dt.start_time
        tab = pd.crosstab(df["period"], df["label"], normalize="index").reindex(
            columns=["positive", "neutral", "negative"], fill_value=0)
        shares = [{"period": p.date().isoformat(), **{k: round(float(v) * 100, 1) for k, v in r.items()}}
                  for p, r in tab.iterrows()]
    sc = db.execute(select(Game.id, Game.name, GameScore.sentiment_component, GameScore.confidence)
                    .join(GameScore, GameScore.game_id == Game.id).order_by(GameScore.sentiment_component.desc())).all()
    fmt = lambda r: {"game_id": r[0], "name": r[1], "sentiment": round(r[2], 3), "confidence": round(r[3], 2)}  # noqa: E731
    return {"model": MODEL, "n_messages": total, "distribution_pct": dist,
            "mean_score": float(timeline["mean"].mean()) if not timeline.empty else None,
            "timeline": [{"period": r.period.date().isoformat(), "mean": round(float(r.mean), 3), "n": int(r.n)}
                         for r in timeline.itertuples()],
            "label_shares_by_period": shares,
            "most_positive_games": [fmt(r) for r in sc[:5]], "most_negative_games": [fmt(r) for r in sc[::-1][:5]]}


def topics_overview(db: Session) -> dict:
    freq = topic_frequency(db)
    kw = {t.id: t for t in db.scalars(select(Topic))}
    games = {g.id: g.name for g in db.scalars(select(Game))}
    top_games = {}
    for tid, gid, w in db.execute(select(GameTopic.topic_id, GameTopic.game_id, GameTopic.weight)
                                  .order_by(GameTopic.weight.desc())):
        top_games.setdefault(tid, [])
        if len(top_games[tid]) < 3:
            top_games[tid].append({"game_id": gid, "name": games.get(gid), "weight": round(w, 3)})
    return {"topics": [{"id": int(r.topic_id), "label": r.label, "keywords": kw[int(r.topic_id)].keywords.split(", ")[:8],
                        "n_messages": int(r.n_messages), "share": round(float(r.share), 4),
                        "top_games": top_games.get(int(r.topic_id), [])} for r in freq.itertuples()],
            "trends": [{"label": t["label"], "series": t["series"]} for t in trending_topics(db, 50)]}


def aspects_overview(db: Session, game_id: int | None = None) -> dict:
    if game_id is not None:
        return {"game_id": game_id, "aspects": [s for s in game_aspect_stats(db, MODEL) if s["game_id"] == game_id]}
    df = pd.DataFrame(db.execute(select(AspectSentiment.aspect, AspectSentiment.label, AspectSentiment.score)
                                 .where(AspectSentiment.model_name == MODEL)).all(), columns=["aspect", "label", "score"])
    glob = [{"aspect": a, "n_mentions": len(g), "mean_score": round(float(g["score"].mean()), 3),
             "positive_share": round(float((g["label"] == "positive").mean()), 3),
             "negative_share": round(float((g["label"] == "negative").mean()), 3)}
            for a, g in df.groupby("aspect")]
    mat = game_aspect_matrix(db, MODEL)
    names = {g.id: g.name for g in db.scalars(select(Game))}
    best = {a: [{"game_id": int(i), "name": names.get(int(i)), "score": round(float(v), 3)}
                for i, v in mat[a].sort_values(ascending=False).head(3).items()] for a in mat.columns}
    return {"aspects": sorted(glob, key=lambda a: -a["n_mentions"]), "best_games_by_aspect": best}


def keywords_overview(db: Session, n: int = 20) -> dict:
    corpus = load_corpus(db)
    if corpus.empty:
        return {"top": [], "emerging": [], "by_genre": {}}
    games = list(db.scalars(select(Game)))
    extra = name_stopwords([g.name for g in games])
    by_game_genre = pd.DataFrame([(g.id, x.name) for g in games for x in g.genres], columns=["game_id", "genre"])
    exp = corpus.dropna(subset=["game_id"]).assign(game_id=lambda d: d["game_id"].astype(int)).merge(by_game_genre, on="game_id")
    by_genre = distinctive_keywords(exp["text_clean"].tolist(), exp["genre"].tolist(), 8, extra) if not exp.empty else {}
    return {"top": [{"term": t, "score": round(s, 4)} for t, s in top_keywords(corpus["text_clean"].tolist(), n, extra)],
            "emerging": emerging_keywords(corpus, extra_stop=extra),
            "by_genre": {g: [t for t, _ in terms] for g, terms in by_genre.items()}}


def activity_overview(db: Session) -> dict:
    rows = db.execute(select(Game.id, Game.name, GameScore.n_messages, GameScore.recent_count, GameScore.status)
                      .join(GameScore, GameScore.game_id == Game.id).order_by(GameScore.n_messages.desc()).limit(10)).all()
    vol = message_volume_timeline(db, "W")
    return {"top_games_by_activity": [{"game_id": r[0], "name": r[1], "n_messages": r[2], "recent_count": r[3], "status": r[4]} for r in rows],
            "volume_timeline": [{"period": r.period.date().isoformat(), "n_messages": int(r.n_messages)} for r in vol.itertuples()],
            "genre_popularity": genre_popularity(db).to_dict("records")}
