"""Assemble the hybrid recommender from the database and produce recommendations for a user.

build_bundle() fits the heavy parts (TF-IDF, CF similarities) once; reuse the bundle across requests and
rebuild it after new ratings/messages arrive in bulk. A single user's new rating needs NO rebuild: the profile
is read from the database on every call, and CF predicts from the user's ratings directly.
"""
import logging
from dataclasses import dataclass
from datetime import datetime

import pandas as pd
from sqlalchemy import delete, select
from sqlalchemy.orm import Session

from app.models import Game, GameScore, Rating, Recommendation as RecommendationRow, User, UserPreference
from app.recommender.collaborative import ItemItemCF, implicit_rating
from app.recommender.hybrid import HybridRecommender, Recommendation
from app.recommender.profile import UserProfile, build_profile
from app.services.aspect_service import game_aspect_attention, game_aspect_matrix
from app.services.content_service import build_content_recommender
from app.services.sentiment_service import game_sentiment_stats

log = logging.getLogger(__name__)


@dataclass
class Bundle:
    hybrid: HybridRecommender
    game_meta: pd.DataFrame          # index game_id: name, genres, tags
    attention: pd.DataFrame          # game x aspect mention share
    model_name: str = "vader"


def ratings_frame(db: Session) -> pd.DataFrame:
    rows = db.execute(select(Rating.user_id, Rating.game_id, Rating.rating, Rating.interaction)).all()
    df = pd.DataFrame(rows, columns=["user_id", "game_id", "rating", "interaction"])
    df["rating"] = [implicit_rating(r, i) for r, i in zip(df["rating"], df["interaction"])]
    return df


def build_bundle(db: Session, model_name: str = "vader", weights: dict | None = None,
                 use_keywords: bool = True) -> Bundle:
    content = build_content_recommender(db, use_keywords=use_keywords)
    collab = ItemItemCF().fit(ratings_frame(db))
    info = content.games.set_index("game_id")[["name", "genres", "tags"]].copy()

    scores = pd.DataFrame(db.execute(select(GameScore.game_id, GameScore.sentiment_component, GameScore.trend_score,
                                            GameScore.status, GameScore.confidence)).all(),
                          columns=["game_id", "sentiment", "trend", "status", "confidence"]).set_index("game_id")
    info = info.join(scores)
    info["catalog_rating"] = pd.Series(dict(db.execute(select(Game.id, Game.rating)).all()), dtype=float)
    for col in ("sentiment", "trend", "confidence"):
        if col not in info:
            info[col] = float("nan")
    pos = {s["game_id"]: s["positive_pct"] for s in game_sentiment_stats(db, model_name)}
    info["pos_pct"] = pd.Series(pos)

    aspects = game_aspect_matrix(db, model_name)
    hybrid = HybridRecommender(content, collab, info, aspects if not aspects.empty else None, weights)
    return Bundle(hybrid, info[["name", "genres", "tags"]], game_aspect_attention(db, model_name), model_name)


def load_profile(db: Session, bundle: Bundle, user_id: int) -> UserProfile:
    if db.get(User, user_id) is None:
        raise LookupError(f"User {user_id} not found")
    ratings = db.execute(select(Rating.game_id, Rating.rating, Rating.interaction).where(Rating.user_id == user_id)).all()
    prefs = db.execute(select(UserPreference.kind, UserPreference.key, UserPreference.value)
                       .where(UserPreference.user_id == user_id)).all()
    return build_profile(
        user_id, ratings,
        stated_genres=[k for kind, k, _ in prefs if kind == "genre"],
        stated_tags=[k for kind, k, _ in prefs if kind == "tag"],
        favorite_ids=[int(k) for kind, k, _ in prefs if kind == "favorite_game"],
        explicit_aspects={k: v for kind, k, v in prefs if kind == "aspect"},
        game_meta=bundle.game_meta, attention=bundle.attention,
        aspect_sentiment=bundle.hybrid.aspect_scores)


MAX_HISTORY_BATCHES = 10


def recommend_for_user(db: Session, bundle: Bundle, user_id: int, n: int = 10, weights: dict | None = None,
                       store: bool = False) -> list[Recommendation]:
    """store=True appends this list to the user's recommendation history (one batch = one timestamp) and
    keeps only the latest MAX_HISTORY_BATCHES batches."""
    recs = bundle.hybrid.recommend(load_profile(db, bundle, user_id), n=n, weights=weights)
    if store and recs:
        now = datetime.utcnow()
        db.add_all(RecommendationRow(user_id=user_id, game_id=r.game_id, score=r.score, created_at=now,
                                     explanation="\n".join(x["text"] for x in r.reasons)) for r in recs)
        db.flush()
        stamps = list(db.scalars(select(RecommendationRow.created_at).where(RecommendationRow.user_id == user_id)
                                 .distinct().order_by(RecommendationRow.created_at.desc())))
        if len(stamps) > MAX_HISTORY_BATCHES:
            db.execute(delete(RecommendationRow).where(RecommendationRow.user_id == user_id,
                                                       RecommendationRow.created_at < stamps[MAX_HISTORY_BATCHES - 1]))
        db.commit()
    return recs


def explain_for_user(db: Session, bundle: Bundle, user_id: int, game_id: int, weights: dict | None = None):
    """(Recommendation, rank, total) for one game, or None if the user has already seen/rated it."""
    return bundle.hybrid.explain_one(load_profile(db, bundle, user_id), game_id, weights)
