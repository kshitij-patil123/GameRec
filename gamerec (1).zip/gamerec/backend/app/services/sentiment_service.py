"""Run a sentiment model over stored messages and aggregate results per game."""
import logging
from collections import defaultdict

import pandas as pd
from sqlalchemy import delete, func, select
from sqlalchemy.orm import Session

from app.models import Message, SentimentResult
from app.nlp.preprocessing import preprocess_frame
from app.nlp.sentiment import SentimentModel

log = logging.getLogger(__name__)


def analyze_messages(db: Session, model: SentimentModel, reset: bool = True) -> int:
    """Score every valid, non-duplicate message and store results. Returns rows written.

    Empty/emoji-only messages and exact duplicates (same game + cleaned text) are skipped so
    spam and noise do not distort per-game statistics.
    """
    if reset:
        db.execute(delete(SentimentResult).where(SentimentResult.model_name == model.name))
    rows = db.execute(select(Message.id, Message.game_id, Message.text)).all()
    if not rows:
        return 0
    df = pd.DataFrame(rows, columns=["id", "game_id", "text"])
    df["game_id"] = df["game_id"].fillna(-1)
    df = preprocess_frame(df, group_col="game_id")
    df = df[df["is_valid"] & ~df["is_duplicate"]]
    preds = model.predict(df["text_original"].tolist(), df["text_clean"].tolist())
    db.add_all(
        SentimentResult(message_id=int(mid), model_name=model.name, label=label, score=score)
        for mid, (label, score) in zip(df["id"], preds)
    )
    db.commit()
    log.info("Stored %d sentiment results (%s); skipped %d", len(df), model.name, len(rows) - len(df))
    return len(df)


def game_sentiment_stats(db: Session, model_name: str) -> list[dict]:
    """Per game: message count, positive/neutral/negative %, average sentiment score."""
    q = (select(Message.game_id, SentimentResult.label, func.count(), func.sum(SentimentResult.score))
         .join(SentimentResult, SentimentResult.message_id == Message.id)
         .where(SentimentResult.model_name == model_name, Message.game_id.is_not(None))
         .group_by(Message.game_id, SentimentResult.label))
    counts: dict[int, dict[str, int]] = defaultdict(lambda: {"positive": 0, "neutral": 0, "negative": 0})
    totals: dict[int, float] = defaultdict(float)
    for game_id, label, n, score_sum in db.execute(q):
        counts[game_id][label] = n
        totals[game_id] += score_sum or 0.0
    stats = []
    for game_id, c in sorted(counts.items()):
        n = sum(c.values())
        stats.append({
            "game_id": game_id, "n_messages": n,
            "positive_pct": round(100 * c["positive"] / n, 1),
            "neutral_pct": round(100 * c["neutral"] / n, 1),
            "negative_pct": round(100 * c["negative"] / n, 1),
            "avg_sentiment": round(totals[game_id] / n, 3),
        })
    return stats
