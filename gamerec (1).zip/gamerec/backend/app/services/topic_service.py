"""Fit topics, persist them, and compute topic frequency / trends."""
import logging

import pandas as pd
from sqlalchemy import delete, select
from sqlalchemy.orm import Session

from app.analytics.keywords import name_stopwords
from app.analytics.topics import dominant_topics, fit_topics, select_k
from app.models import Game, GameTopic, Message, MessageTopic, Topic
from app.services.corpus import load_corpus

log = logging.getLogger(__name__)


def run_topic_analysis(db: Session, k: int | str = 8, candidates: tuple[int, ...] = (4, 6, 8, 10, 12)) -> dict:
    corpus = load_corpus(db)
    if len(corpus) < 20:
        raise ValueError("Not enough messages for topic modeling (need at least 20 valid, unique messages)")
    extra = name_stopwords(list(db.scalars(select(Game.name))))
    texts = corpus["text_clean"].tolist()
    coherence_by_k = None
    if k == "auto":  # coherence favors small k, so auto is a hint, not an oracle
        k, coherence_by_k = select_k(texts, candidates, extra_stop=extra)
    result = fit_topics(texts, k=k, extra_stop=extra)

    for model in (MessageTopic, GameTopic, Topic):
        db.execute(delete(model))
    topic_rows = [Topic(label=t["label"], keywords=", ".join(t["keywords"])) for t in result.topics]
    db.add_all(topic_rows)
    db.flush()
    ids = [t.id for t in topic_rows]

    dom = dominant_topics(result.doc_topic)
    db.add_all(MessageTopic(message_id=int(mid), topic_id=ids[int(t)], weight=float(w))
               for mid, t, w in zip(corpus["id"], dom["topic_id"], dom["weight"]))

    per_game = pd.DataFrame(result.doc_topic, columns=ids).assign(game_id=corpus["game_id"].values).dropna()
    for gid, row in per_game.groupby("game_id").mean().iterrows():
        db.add_all(GameTopic(game_id=int(gid), topic_id=int(tid), weight=float(w)) for tid, w in row.items())
    db.commit()
    log.info("Fitted %d topics (coherence %.2f)", k, result.coherence)
    return {"k": k, "coherence": result.coherence, "coherence_by_k": coherence_by_k, "topics": result.topics}


def topic_frequency(db: Session) -> pd.DataFrame:
    """Messages per topic (dominant assignment) and share."""
    q = select(Topic.id, Topic.label, MessageTopic.message_id).join(MessageTopic, MessageTopic.topic_id == Topic.id)
    df = pd.DataFrame(db.execute(q).all(), columns=["topic_id", "label", "message_id"])
    if df.empty:
        return pd.DataFrame(columns=["topic_id", "label", "n_messages", "share"])
    out = df.groupby(["topic_id", "label"]).size().rename("n_messages").reset_index()
    out["share"] = out["n_messages"] / out["n_messages"].sum()
    return out.sort_values("n_messages", ascending=False).reset_index(drop=True)


def topic_trends(db: Session, freq: str = "W") -> pd.DataFrame:
    """Topic SHARE of messages per period (share, not counts, so busy weeks do not dominate)."""
    q = (select(Topic.label, Message.created_at).join(MessageTopic, MessageTopic.topic_id == Topic.id)
         .join(Message, Message.id == MessageTopic.message_id))
    df = pd.DataFrame(db.execute(q).all(), columns=["label", "created_at"])
    if df.empty:
        return pd.DataFrame()
    df["period"] = pd.to_datetime(df["created_at"]).dt.to_period(freq).dt.start_time
    counts = df.groupby(["period", "label"]).size().unstack(fill_value=0)
    return counts.div(counts.sum(axis=1), axis=0)
