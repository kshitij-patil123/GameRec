"""Compute and store trend + community scores; timelines and genre popularity for the dashboard."""
import logging

import numpy as np
import pandas as pd
from sqlalchemy import delete, func, select
from sqlalchemy.orm import Session

from app.analytics.community import compute_community_scores, shrink
from app.analytics.trends import compute_trend_scores, mean_timeline, minmax, volume_timeline
from app.models import AspectSentiment, Game, GameScore, Message, SentimentResult
from app.services.corpus import load_corpus

log = logging.getLogger(__name__)
SHRINK_K = 10.0


def _sentiment_frame(db: Session, model_name: str) -> pd.DataFrame:
    q = (select(Message.game_id, Message.created_at, SentimentResult.score)
         .join(SentimentResult, SentimentResult.message_id == Message.id)
         .where(SentimentResult.model_name == model_name, Message.game_id.is_not(None)))
    return pd.DataFrame(db.execute(q).all(), columns=["game_id", "created_at", "score"])


def compute_and_store_scores(db: Session, model_name: str = "vader", weights: dict | None = None,
                             trend_weights: dict | None = None, **trend_kw) -> pd.DataFrame:
    """Needs sentiment results (run scripts/run_sentiment.py first). Aspect results are optional."""
    msgs = load_corpus(db, require_game=True)[["game_id", "created_at", "engagement"]]
    sent = _sentiment_frame(db, model_name)
    if msgs.empty or sent.empty:
        raise ValueError("No messages or sentiment results found; load data and run sentiment first")
    trend = compute_trend_scores(msgs, weights=trend_weights, **trend_kw)
    as_of = pd.to_datetime(msgs["created_at"]).max()

    g = sent.groupby("game_id")["score"].agg(["sum", "count", "std"])
    shrunk = shrink(g["sum"], g["count"], sent["score"].mean(), SHRINK_K)
    comp = pd.DataFrame(index=trend.index)
    comp["sentiment"] = ((shrunk + 1) / 2).reindex(comp.index)
    comp["consistency"] = (1 - g["std"].fillna(0).clip(0, 1)).reindex(comp.index)
    comp["volume"] = minmax(np.log1p(trend["total_count"]))
    comp["trend"] = trend["trend_score"]
    comp["engagement"] = trend["engagement_score"]

    asp = pd.DataFrame(db.execute(select(AspectSentiment.game_id, AspectSentiment.score)
                                  .where(AspectSentiment.model_name == model_name)).all(),
                       columns=["game_id", "score"])
    if not asp.empty:
        ag = asp.groupby("game_id")["score"].agg(["sum", "count"])
        comp["aspect"] = ((shrink(ag["sum"], ag["count"], asp["score"].mean(), SHRINK_K) + 1) / 2).reindex(comp.index)
    comp["community"] = compute_community_scores(comp, weights)
    n = trend["total_count"]

    db.execute(delete(GameScore))
    for gid, row in trend.iterrows():
        c = comp.loc[gid]
        opt = lambda v: None if pd.isna(v) else float(v)  # noqa: E731
        db.add(GameScore(
            game_id=int(gid), as_of=as_of.to_pydatetime(), n_messages=int(n[gid]),
            recent_count=int(row["recent_count"]), growth_ratio=float(row["growth_ratio"]),
            status=row["status"], trend_score=float(row["trend_score"]),
            sentiment_component=opt(c["sentiment"]), consistency_component=opt(c["consistency"]),
            volume_component=opt(c["volume"]), aspect_component=opt(c.get("aspect", np.nan)),
            engagement_component=opt(c["engagement"]), community_score=opt(c["community"]),
            confidence=float(n[gid] / (n[gid] + SHRINK_K)),
        ))
    db.commit()
    log.info("Stored scores for %d games (as_of %s)", len(trend), as_of)
    return latest_scores(db)


def latest_scores(db: Session) -> pd.DataFrame:
    rows = db.execute(select(Game.id, Game.name, GameScore)
                      .join(GameScore, GameScore.game_id == Game.id)).all()
    cols = ["game_id", "game", "as_of", "n_messages", "recent_count", "growth_ratio", "status", "trend_score",
            "sentiment_component", "consistency_component", "volume_component", "aspect_component",
            "engagement_component", "community_score", "confidence"]
    return pd.DataFrame([(r[0], r[1], *[getattr(r[2], c) for c in cols[2:]]) for r in rows], columns=cols)


def message_volume_timeline(db: Session, freq: str = "W", game_id: int | None = None) -> pd.DataFrame:
    return volume_timeline(load_corpus(db, require_game=True), freq, game_id)


def sentiment_timeline(db: Session, model_name: str = "vader", freq: str = "W",
                       game_id: int | None = None) -> pd.DataFrame:
    df = _sentiment_frame(db, model_name)
    if game_id is not None:
        df = df[df["game_id"] == game_id]
    return mean_timeline(df, "score", freq)


def genre_popularity(db: Session) -> pd.DataFrame:
    """Messages per genre (a message counts toward each genre of its game)."""
    counts = pd.Series(dict(db.execute(select(Message.game_id, func.count()).where(
        Message.game_id.is_not(None)).group_by(Message.game_id)).all()))
    rows = [(genre.name, int(counts.get(game.id, 0))) for game in db.scalars(select(Game)) for genre in game.genres]
    if not rows:
        return pd.DataFrame(columns=["genre", "n_messages", "n_games"])
    df = pd.DataFrame(rows, columns=["genre", "n"])
    out = df.groupby("genre")["n"].agg(n_messages="sum", n_games="count").reset_index()
    return out.sort_values("n_messages", ascending=False).reset_index(drop=True)
