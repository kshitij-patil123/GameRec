"""User, rating and preference writes + the profile read model."""
import uuid

from sqlalchemy import delete, func, select
from sqlalchemy.orm import Session

from app.models import Game, Genre, Rating, Recommendation, Tag, User, UserPreference
from app.nlp.aspects import ASPECTS
from app.recommender.profile import COLD_START_MIN_RATINGS
from app.services.recommendation_service import Bundle, load_profile


class NotFound(LookupError):
    pass


class Invalid(ValueError):
    pass


def get_user(db: Session, user_id: int) -> User:
    user = db.get(User, user_id)
    if user is None:
        raise NotFound(f"User {user_id} not found")
    return user


def create_user(db: Session, display_name: str) -> User:
    user = User(external_id=f"user-{uuid.uuid4().hex[:12]}", display_name=display_name)
    db.add(user)
    db.commit()
    return user


def list_users(db: Session, limit: int = 50) -> list[dict]:
    counts = dict(db.execute(select(Rating.user_id, func.count()).group_by(Rating.user_id)).all())
    users = db.scalars(select(User).order_by(User.id.desc()).limit(limit))
    return [{"id": u.id, "display_name": u.display_name or u.external_id, "n_ratings": counts.get(u.id, 0)} for u in users]


def upsert_rating(db: Session, user_id: int, game_id: int, rating: float | None, interaction: str) -> Rating:
    get_user(db, user_id)
    if db.get(Game, game_id) is None:
        raise NotFound(f"Game {game_id} not found")
    row = db.scalar(select(Rating).where(Rating.user_id == user_id, Rating.game_id == game_id))
    if row is None:
        row = Rating(user_id=user_id, game_id=game_id)
        db.add(row)
    row.rating, row.interaction = rating, interaction
    db.commit()
    return row


def set_preferences(db: Session, user_id: int, genres=None, tags=None, favorite_game_ids=None, aspects=None) -> None:
    get_user(db, user_id)
    new: dict[str, list[tuple[str, float]]] = {}
    if genres is not None:
        known = {g.lower(): g for g in db.scalars(select(Genre.name))}
        unknown = [g for g in genres if g.lower() not in known]
        if unknown:
            raise Invalid(f"Unknown genre(s): {unknown}")
        new["genre"] = [(known[g.lower()], 1.0) for g in dict.fromkeys(genres)]
    if tags is not None:
        known = {t.lower(): t for t in db.scalars(select(Tag.name))}
        unknown = [t for t in tags if t.lower() not in known]
        if unknown:
            raise Invalid(f"Unknown tag(s): {unknown}")
        new["tag"] = [(known[t.lower()], 1.0) for t in dict.fromkeys(tags)]
    if favorite_game_ids is not None:
        ids = list(dict.fromkeys(favorite_game_ids))
        found = set(db.scalars(select(Game.id).where(Game.id.in_(ids)))) if ids else set()
        if set(ids) - found:
            raise Invalid(f"Unknown game id(s): {sorted(set(ids) - found)}")
        new["favorite_game"] = [(str(i), 1.0) for i in ids]
    if aspects is not None:
        new["aspect"] = [(a, float(v)) for a, v in aspects.items() if a in ASPECTS]
    for kind, items in new.items():
        db.execute(delete(UserPreference).where(UserPreference.user_id == user_id, UserPreference.kind == kind))
        db.add_all(UserPreference(user_id=user_id, kind=kind, key=k, value=v) for k, v in items)
    db.commit()


def profile_view(db: Session, bundle: Bundle, user_id: int, top: int = 6) -> dict:
    user = get_user(db, user_id)
    p = load_profile(db, bundle, user_id)
    names = bundle.game_meta["name"]
    rows = db.execute(select(Rating.game_id, Rating.rating, Rating.interaction, Rating.created_at)
                      .where(Rating.user_id == user_id).order_by(Rating.created_at.desc())).all()
    ratings = [{"game_id": g, "name": names.get(g), "genres": list(bundle.game_meta.at[g, "genres"]) if g in names.index else [],
                "rating": r, "interaction": i, "rated_at": c.isoformat()} for g, r, i, c in rows]
    liked = [x for x in ratings if (x["rating"] or 0) >= 4 or (x["rating"] is None and x["interaction"] == "liked")]
    favorites = [{"game_id": g, "name": names.get(g)} for g in p.favorite_ids]
    ranked = lambda d, pos_only=True: [{"name": k, "weight": round(v, 3)} for k, v in sorted(  # noqa: E731
        d.items(), key=lambda kv: -kv[1]) if (v > 0 or not pos_only)][:top]
    stated_aspects = dict(db.execute(select(UserPreference.key, UserPreference.value).where(
        UserPreference.user_id == user_id, UserPreference.kind == "aspect")).all())
    history_rows = db.execute(select(Recommendation.created_at, Recommendation.game_id, Recommendation.score)
                              .where(Recommendation.user_id == user_id)
                              .order_by(Recommendation.created_at.desc(), Recommendation.score.desc())).all()
    batches: dict = {}
    for created, gid, score in history_rows:
        batch = batches.setdefault(created.isoformat(), [])
        if len(batch) < 5:
            batch.append({"game_id": gid, "name": names.get(gid), "score": round(score, 3)})
    return {
        "user": {"id": user.id, "display_name": user.display_name or user.external_id},
        "n_ratings": p.n_ratings, "cold_start": p.n_ratings < COLD_START_MIN_RATINGS,
        "ratings": ratings, "liked_games": liked, "favorite_games": favorites,
        "stated": {"genres": p.stated_genres, "tags": p.stated_tags, "aspects": stated_aspects},
        "favorite_genres": ranked(p.genre_weights), "preferred_tags": ranked(p.tag_weights),
        "aspect_preferences": ranked(p.aspect_prefs), "genre_weights": ranked(p.genre_weights, pos_only=False),
        "recommendation_history": [{"created_at": k, "items": v} for k, v in list(batches.items())[:3]],
    }
