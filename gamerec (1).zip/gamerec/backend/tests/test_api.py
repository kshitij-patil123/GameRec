import os
from types import SimpleNamespace

import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from app.api.deps import get_db
from app.core.db import Base
from app.ingestion.loader import load_source
from app.ingestion.sources import get_source
from app.main import create_app
from app.nlp.sentiment import VaderModel
from app.services.aspect_service import analyze_aspects
from app.services.sentiment_service import analyze_messages
from app.services.topic_service import run_topic_analysis
from app.services.trend_service import compute_and_store_scores


# Set GAMEREC_TEST_DB_URL to a throwaway PostgreSQL database to run this whole file against Postgres
# (the schema is dropped and recreated). Default: in-memory SQLite.
PG_URL = os.environ.get("GAMEREC_TEST_DB_URL")


def make_client(prepare: bool = True) -> TestClient:
    if PG_URL:
        engine = create_engine(PG_URL)
        Base.metadata.drop_all(engine)
    else:
        engine = create_engine("sqlite://", connect_args={"check_same_thread": False}, poolclass=StaticPool)
    Base.metadata.create_all(engine)
    Session = sessionmaker(bind=engine, expire_on_commit=False)
    if prepare:
        with Session() as db:
            load_source(db, get_source("demo"))
            analyze_messages(db, VaderModel())
            analyze_aspects(db, VaderModel())
            run_topic_analysis(db, k=6)
            compute_and_store_scores(db)
    app = create_app()

    def override():
        db = Session()
        try:
            yield db
        finally:
            db.close()

    app.dependency_overrides[get_db] = override
    return TestClient(app, raise_server_exceptions=False)


@pytest.fixture(scope="module")
def client():
    return make_client()


def new_user(client, name="Tester") -> int:
    r = client.post("/users", json={"display_name": name})
    assert r.status_code == 201
    return r.json()["id"]


# ---------- system ----------
def test_health_and_meta(client):
    assert client.get("/health").json() == {"status": "ok"}
    m = client.get("/meta").json()
    assert m["is_demo"] is True and "synthetic" in m["banner"].lower()
    assert all(m["pipeline"].values()) and m["counts"]["games"] == 24


def test_unhandled_error_is_generic_500(client, monkeypatch):
    def boom(db):
        raise RuntimeError("secret internals")
    monkeypatch.setattr("app.services.query_service.data_meta", boom)
    r = client.get("/meta")
    assert r.status_code == 500 and r.json() == {"detail": "Internal server error"}


def test_cors_allows_configured_origin_only(client):
    ok = client.options("/games", headers={"Origin": "http://localhost:5173", "Access-Control-Request-Method": "GET"})
    bad = client.options("/games", headers={"Origin": "http://evil.example", "Access-Control-Request-Method": "GET"})
    assert ok.headers.get("access-control-allow-origin") == "http://localhost:5173"
    assert "access-control-allow-origin" not in bad.headers


def test_refresh_requires_admin_token(client, monkeypatch):
    assert client.post("/system/refresh").status_code == 403           # disabled by default
    monkeypatch.setattr("app.api.deps.get_settings", lambda: SimpleNamespace(admin_token="s3cret"))
    assert client.post("/system/refresh", headers={"X-Admin-Token": "nope"}).status_code == 403
    assert client.post("/system/refresh", headers={"X-Admin-Token": "s3cret"}).json() == {"status": "refreshed"}
    assert client.get("/games/1/similar").status_code == 200           # bundle rebuilds lazily


# ---------- games ----------
def test_list_games_pagination_and_sort(client):
    r = client.get("/games", params={"limit": 5, "offset": 0, "sort": "community_score", "order": "desc"}).json()
    assert r["total"] == 24 and len(r["items"]) == 5
    scores = [g["community_score"] for g in r["items"]]
    assert scores == sorted(scores, reverse=True)
    page2 = client.get("/games", params={"limit": 5, "offset": 5, "sort": "community_score", "order": "desc"}).json()
    assert {g["id"] for g in r["items"]}.isdisjoint({g["id"] for g in page2["items"]})


def test_list_games_filters(client):
    rpg = client.get("/games", params={"genre": "rpg", "limit": 100}).json()
    assert rpg["total"] > 0 and all("RPG" in g["genres"] for g in rpg["items"])
    pc = client.get("/games", params={"platform": "switch", "limit": 100}).json()
    assert pc["total"] > 0 and all("Switch" in g["platforms"] for g in pc["items"])
    high = client.get("/games", params={"min_rating": 4.5, "limit": 100}).json()
    assert all(g["rating"] >= 4.5 for g in high["items"])
    assert client.get("/games", params={"q": "ashen"}).json()["items"][0]["name"] == "Ashen Crown"
    assert client.get("/games", params={"q": "%"}).json()["total"] == 0      # wildcard is escaped


@pytest.mark.parametrize("params", [{"sort": "bogus"}, {"limit": 1000}, {"limit": 0}, {"offset": -1}, {"min_rating": 9}])
def test_list_games_rejects_bad_params(client, params):
    r = client.get("/games", params=params)
    assert r.status_code == 422 and r.json()["detail"] == "Validation failed"


def test_search_ranks_prefix_first_and_validates(client):
    names = [g["name"] for g in client.get("/games/search", params={"q": "s"}).json()]
    assert names and names[0].lower().startswith("s")
    assert client.get("/games/search").status_code == 422


def test_filters_endpoint(client):
    f = client.get("/games/filters").json()
    assert "RPG" in f["genres"] and "PC" in f["platforms"] and "story" in f["aspects"]


def test_game_detail_and_404(client):
    g = client.get("/games/1").json()
    assert g["name"] and g["genres"] and g["community_score"] is not None
    assert client.get("/games/9999").status_code == 404
    assert client.get("/games/abc").status_code == 422


def test_similar_games(client):
    items = client.get("/games/1/similar", params={"limit": 4}).json()
    sims = [i["similarity"] for i in items]
    assert len(items) == 4 and sims == sorted(sims, reverse=True) and all(i["game"]["id"] != 1 for i in items)
    assert client.get("/games/9999/similar").status_code == 404


def test_community_analysis_has_no_raw_text(client):
    a = client.get("/games/1/community-analysis").json()
    assert a["sentiment"]["n_messages"] > 0 and a["aspects"] and a["timeline"] and a["scores"]["components"]
    assert a["keywords"] and a["topics"]
    def keys(x):
        if isinstance(x, dict):
            return set(x) | {k for v in x.values() for k in keys(v)}
        return {k for v in x for k in keys(v)} if isinstance(x, list) else set()
    assert not keys(a) & {"text", "author", "author_hash", "message", "messages", "user_id"}
    assert client.get("/games/9999/community-analysis").status_code == 404


# ---------- trending / analytics ----------
def test_trending(client):
    games = client.get("/trending/games", params={"limit": 5}).json()
    scores = [g["trend_score"] for g in games]
    assert len(games) == 5 and scores == sorted(scores, reverse=True) and "growth_ratio" in games[0]
    topics = client.get("/trending/topics").json()
    assert topics and {"label", "recent_share", "change", "series"} <= set(topics[0])
    assert client.get("/trending/games", params={"limit": 500}).status_code == 422


def test_analytics_endpoints(client):
    ov = client.get("/analytics/overview").json()
    assert ov["trending_games"] and ov["genres"] and ov["meta"]["is_demo"]
    s = client.get("/analytics/sentiment").json()
    assert abs(sum(s["distribution_pct"].values()) - 100) < 0.5 and s["timeline"] and s["most_positive_games"]
    t = client.get("/analytics/topics").json()
    assert len(t["topics"]) == 6 and abs(sum(x["share"] for x in t["topics"]) - 1) < 0.01
    a = client.get("/analytics/aspects").json()
    assert a["aspects"] and a["best_games_by_aspect"]["story"]
    assert client.get("/analytics/aspects", params={"game_id": 1}).json()["aspects"]
    assert client.get("/analytics/aspects", params={"game_id": 9999}).status_code == 404
    k = client.get("/analytics/keywords").json()
    assert k["top"] and "RPG" in k["by_genre"]
    act = client.get("/analytics/activity").json()
    assert act["top_games_by_activity"] and act["volume_timeline"]


# ---------- users ----------
def test_create_user_validation(client):
    assert client.post("/users", json={"display_name": ""}).status_code == 422
    assert client.post("/users", json={"display_name": "x", "admin": True}).status_code == 422   # extra field
    assert client.post("/users", json={}).status_code == 422
    uid = new_user(client, "  Padded  ")
    assert any(u["id"] == uid and u["display_name"] == "Padded" for u in client.get("/users").json())


def test_ratings_upsert_and_validation(client):
    uid = new_user(client)
    assert client.post(f"/users/{uid}/ratings", json={"game_id": 1, "rating": 5}).status_code == 201
    client.post(f"/users/{uid}/ratings", json={"game_id": 1, "rating": 2})                    # update, not duplicate
    ratings = client.get(f"/users/{uid}/profile").json()["ratings"]
    assert len(ratings) == 1 and ratings[0]["rating"] == 2
    assert client.post(f"/users/{uid}/ratings", json={"game_id": 2, "interaction": "liked"}).status_code == 201
    for bad in ({"game_id": 1, "rating": 6}, {"game_id": 1, "rating": 0}, {"game_id": 1}, {"game_id": 0, "rating": 3},
                {"game_id": 1, "interaction": "rated"}, {"game_id": 1, "rating": 3, "interaction": "love"}):
        assert client.post(f"/users/{uid}/ratings", json=bad).status_code == 422, bad
    assert client.post(f"/users/{uid}/ratings", json={"game_id": 9999, "rating": 3}).status_code == 404
    assert client.post("/users/99999/ratings", json={"game_id": 1, "rating": 3}).status_code == 404


def test_preferences_replace_and_validate(client):
    uid = new_user(client)
    ok = {"genres": ["rpg", "Action"], "tags": ["story rich"], "favorite_game_ids": [1], "aspects": {"story": 0.9}}
    assert client.post(f"/users/{uid}/preferences", json=ok).status_code == 200
    p = client.get(f"/users/{uid}/profile").json()
    assert set(p["stated"]["genres"]) == {"RPG", "Action"} and p["favorite_games"][0]["game_id"] == 1
    assert p["aspect_preferences"][0]["name"] == "story" and p["cold_start"] is True
    client.post(f"/users/{uid}/preferences", json={"genres": []})                              # clears genres only
    p = client.get(f"/users/{uid}/profile").json()
    assert p["stated"]["genres"] == [] and p["stated"]["tags"] == ["story rich"]
    for bad in ({"genres": ["Nonexistent"]}, {"tags": ["nope"]}, {"favorite_game_ids": [9999]},
                {"aspects": {"story": 1.5}}, {"aspects": {"smell": 0.5}}, {"genres": "RPG"}, {"foo": 1}):
        assert client.post(f"/users/{uid}/preferences", json=bad).status_code == 422, bad
    assert client.post("/users/99999/preferences", json={"genres": []}).status_code == 404


def test_profile_shape_for_rated_user(client):
    p = client.get("/users/1/profile").json()
    assert p["n_ratings"] > 0 and p["cold_start"] is False and p["liked_games"] is not None
    assert {"favorite_genres", "preferred_tags", "aspect_preferences", "recommendation_history"} <= set(p)
    assert client.get("/users/99999/profile").status_code == 404


# ---------- recommendations ----------
def test_recommendations_for_existing_user(client):
    r = client.get("/recommendations/1", params={"n": 5}).json()
    assert r["strategy"] == "hybrid" and len(r["items"]) == 5 and r["is_demo"] is True
    assert abs(sum(r["weights"].values()) - 1) < 1e-9 and "relative" in r["note"]
    first = r["items"][0]
    assert first["rank"] == 1 and 0 <= first["score"] <= 1 and first["reasons"] and first["game"]["name"]
    scores = [i["score"] for i in r["items"]]
    assert scores == sorted(scores, reverse=True)
    rated = {x["game_id"] for x in client.get("/users/1/profile").json()["ratings"]}
    assert not rated & {i["game"]["id"] for i in r["items"]}


def test_recommendation_weights_param(client):
    r = client.get("/recommendations/1", params={"weights": '{"content": 1, "collaborative": 0, "preference": 0, '
                                                            '"community": 0, "trend": 0, "aspect": 0}'}).json()
    assert set(r["items"][0]["components"]) == {"content"}
    for bad in ("not json", "[1,2]", '{"bogus": 1}', '{"content": -1}',
                '{"content":0,"collaborative":0,"preference":0,"community":0,"trend":0,"aspect":0}'):
        assert client.get("/recommendations/1", params={"weights": bad}).status_code == 422, bad


def test_cold_start_users(client):
    uid = new_user(client)
    assert client.get(f"/recommendations/{uid}").json()["strategy"] == "popular_trending"
    client.post(f"/users/{uid}/preferences", json={"genres": ["Racing"], "aspects": {"multiplayer": 0.9}})
    r = client.get(f"/recommendations/{uid}", params={"n": 3}).json()
    assert r["strategy"] == "cold_start_preferences" and "Racing" in r["items"][0]["game"]["genres"]
    assert client.get("/recommendations/99999").status_code == 404
    assert client.get("/recommendations/1", params={"n": 0}).status_code == 422


def test_rating_a_game_updates_recommendations(client):
    uid = new_user(client)
    client.post(f"/users/{uid}/preferences", json={"genres": ["RPG"]})
    before = client.get(f"/recommendations/{uid}", params={"n": 8}).json()
    top = before["items"][0]["game"]["id"]
    client.post(f"/users/{uid}/ratings", json={"game_id": top, "rating": 5})
    after = client.get(f"/recommendations/{uid}", params={"n": 8}).json()
    assert top not in {i["game"]["id"] for i in after["items"]}
    assert [i["game"]["id"] for i in after["items"]] != [i["game"]["id"] for i in before["items"]]


def test_save_builds_history(client):
    uid = new_user(client)
    client.post(f"/users/{uid}/preferences", json={"genres": ["RPG"]})
    client.get(f"/recommendations/{uid}", params={"n": 3})                                     # not saved
    assert client.get(f"/users/{uid}/profile").json()["recommendation_history"] == []
    client.get(f"/recommendations/{uid}", params={"n": 3, "save": True})
    hist = client.get(f"/users/{uid}/profile").json()["recommendation_history"]
    assert len(hist) == 1 and len(hist[0]["items"]) == 3


def test_explain_endpoint(client):
    recs = client.get("/recommendations/1", params={"n": 3}).json()["items"]
    gid = recs[1]["game"]["id"]
    e = client.get(f"/recommendations/1/explain/{gid}").json()
    assert e["game"]["id"] == gid and e["rank"] == 2 and e["reasons"]
    seen = client.get("/users/1/profile").json()["ratings"][0]["game_id"]
    assert client.get(f"/recommendations/1/explain/{seen}").status_code == 409
    assert client.get("/recommendations/1/explain/9999").status_code == 404
    assert client.get(f"/recommendations/99999/explain/{gid}").status_code == 404


# ---------- empty system ----------
def test_empty_database_gives_503_not_500():
    empty = make_client(prepare=False)
    assert empty.get("/health").status_code == 200 and empty.get("/meta").json()["counts"]["games"] == 0
    assert empty.get("/games").json()["total"] == 0
    assert empty.get("/recommendations/1").status_code == 503
    assert empty.get("/users/1/profile").status_code == 503


# ---------- never-loaded database (the most common first-run mistake) ----------
def test_unloaded_database_gets_tables_and_clear_503s():
    from app.main import ensure_schema
    engine = create_engine("sqlite://", connect_args={"check_same_thread": False}, poolclass=StaticPool)
    assert ensure_schema(engine) is True and ensure_schema(engine) is True       # idempotent
    Session = sessionmaker(bind=engine, expire_on_commit=False)
    app = create_app()

    def override():
        db = Session()
        try:
            yield db
        finally:
            db.close()

    app.dependency_overrides[get_db] = override
    c = TestClient(app, raise_server_exceptions=False)
    assert c.get("/meta").json()["counts"] == {"games": 0, "messages": 0, "ratings": 0}
    for path in ("/analytics/overview", "/analytics/sentiment", "/analytics/topics", "/analytics/aspects",
                 "/analytics/keywords", "/analytics/activity", "/trending/games", "/trending/topics"):
        r = c.get(path)
        assert r.status_code == 503 and "run_pipeline" in r.json()["detail"], path
    assert c.get("/games").json()["total"] == 0 and c.get("/health").status_code == 200


def test_unreachable_database_does_not_crash_startup():
    from app.main import ensure_schema
    assert ensure_schema(create_engine("postgresql+psycopg2://nobody:x@127.0.0.1:1/none")) is False
