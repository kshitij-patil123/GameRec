import pytest
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from app.core.db import Base
from app.ingestion.loader import load_source
from app.ingestion.sources import get_source
from app.nlp.aspects import ASPECTS, extract_mentions, find_aspects, mask_aspect_terms, score_aspects, split_clauses
from app.nlp.sentiment import VaderModel
from app.services.aspect_service import analyze_aspects, game_aspect_matrix, game_aspect_stats


def test_clause_split_on_contrast():
    assert len(split_clauses("story is great but performance is terrible")) == 2


def test_find_aspects_multiword_and_none():
    assert "difficulty" in find_aspects("the difficulty curve is steep")
    assert find_aspects("nice weather today") == []


def test_mixed_message_gets_opposite_aspect_sentiments():
    res = score_aspects(["The story is amazing but the performance is terrible"], VaderModel())[0]
    by = {a: label for a, label, _ in res}
    assert by["story"] == "positive" and by["performance"] == "negative"


def test_masking_removes_lexicon_bias_but_keeps_sentiment_words():
    assert "combat" not in mask_aspect_terms("the combat is great").lower()
    assert "expensive" in mask_aspect_terms("too expensive")
    (aspect, _, score), = score_aspects(["the fighting is great"], VaderModel())[0]
    assert aspect == "combat" and score > 0


def test_empty_and_no_aspect_messages():
    assert score_aspects(["", "hello there"], VaderModel()) == [[], []]
    assert extract_mentions("") == []


@pytest.fixture()
def db():
    engine = create_engine("sqlite://")
    Base.metadata.create_all(engine)
    with sessionmaker(bind=engine)() as s:
        load_source(s, get_source("demo"))
        yield s


def test_aspect_pipeline_and_matrix(db):
    assert analyze_aspects(db, VaderModel()) > 0
    stats = game_aspect_stats(db)
    assert {s["label"] for s in stats} <= {"Positive", "Negative", "Mixed", "Neutral", "Insufficient data"}
    m = game_aspect_matrix(db)
    assert list(m.columns) == ASPECTS and m.shape[0] == 24
    assert m.abs().max().max() <= 1.0


def test_matrix_empty_when_no_results(db):
    assert game_aspect_matrix(db, "nonexistent").empty
