import numpy as np
import pandas as pd
import pytest

from app.recommender.collaborative import ItemItemCF, implicit_rating
from app.recommender.profile import build_profile

# users 1-4 like games 1&2 and dislike 3&4; user 5 likes 3&4 and dislikes 1&2
RATINGS = pd.DataFrame(
    [(u, g, r) for u in (1, 2, 3, 4) for g, r in ((1, 5), (2, 5), (3, 1), (4, 1))]
    + [(5, 1, 1), (5, 2, 1), (5, 3, 5), (5, 4, 5), (6, 1, 5), (6, 5, 4), (7, 5, 4), (7, 2, 5)],
    columns=["user_id", "game_id", "rating"])


def test_implicit_rating():
    assert implicit_rating(4.0, "liked") == 4.0
    assert implicit_rating(None, "liked") == 4.5 and implicit_rating(float("nan"), "disliked") == 1.5
    assert implicit_rating(None, None) is None


def test_similar_items_follow_co_preference():
    cf = ItemItemCF(shrinkage=1.0).fit(RATINGS)
    assert cf.similar_items(1, 1)[0][0] == 2
    assert cf.sim[cf.index[1], cf.index[3]] < 0          # liked by different people -> negative similarity


def test_predictions_rank_liked_cluster_higher():
    cf = ItemItemCF(shrinkage=1.0).fit(RATINGS)
    pred = cf.predict({1: 5.0})                         # likes game 1 only
    assert 1 not in pred.index and pred[2] > pred[3]
    assert ((pred.dropna() >= 1) & (pred.dropna() <= 5)).all()


def test_cold_start_and_unknown_items_give_no_prediction():
    cf = ItemItemCF().fit(RATINGS)
    assert cf.predict({}).empty and cf.predict({999: 5.0}).empty
    assert ItemItemCF().fit(RATINGS.iloc[0:0]).predict({1: 5.0}).empty
    assert cf.similar_items(999) == []


def test_constant_or_single_rating_still_carries_signal_and_stays_bounded():
    cf = ItemItemCF(shrinkage=1.0).fit(RATINGS)
    for ratings in ({1: 4.0, 2: 4.0}, {1: 5.0}):
        pred = cf.predict(ratings).dropna()
        assert pred.map(np.isfinite).all() and pred.between(1, 5).all()
    assert cf.predict({1: 5.0})[2] > cf.predict({1: 5.0})[3]


META = pd.DataFrame({"genres": [["RPG", "Action"], ["Racing"], ["RPG"]],
                     "tags": [["story rich"], ["fast"], ["story rich"]]}, index=[1, 2, 3])
ATT = pd.DataFrame({"story": [0.8, 0.1, 0.9], "combat": [0.2, 0.9, 0.1]}, index=[1, 2, 3])
SENT = pd.DataFrame({"story": [0.9, 0.0, 0.8], "combat": [0.5, -0.6, 0.0]}, index=[1, 2, 3])


def test_profile_weights_and_dislikes():
    p = build_profile(7, [(1, 5, "rated"), (2, 1, "rated")], game_meta=META)
    assert p.weighted_games == {1: 2.0, 2: -2.0}
    assert p.genre_weights["RPG"] > 0 > p.genre_weights["Racing"]
    assert max(abs(v) for v in p.genre_weights.values()) == pytest.approx(1.0)


def test_profile_stated_prefs_and_favorites_for_new_user():
    p = build_profile(8, [], stated_genres=["RPG"], stated_tags=["story rich"], favorite_ids=[3], game_meta=META)
    assert p.n_ratings == 1 and p.ratings[3] == 5.0 and p.has_signal
    assert p.genre_weights["RPG"] == pytest.approx(1.0)


def test_profile_empty_user_has_no_signal():
    p = build_profile(9, [])
    assert not p.has_signal and p.genre_weights == {} and p.aspect_prefs == {} and p.seen == set()


def test_aspect_inference_counts_only_praised_aspects_and_explicit_overrides():
    # user liked game 2, whose talk is 90% about combat but combat is criticized (-0.6) -> not a priority
    p = build_profile(1, [(2, 5, "rated"), (1, 5, "rated")], game_meta=META, attention=ATT, aspect_sentiment=SENT)
    assert p.aspect_prefs["story"] > p.aspect_prefs.get("combat", 0)
    p2 = build_profile(1, [(1, 5, "rated")], game_meta=META, attention=ATT, aspect_sentiment=SENT,
                       explicit_aspects={"story": 0.2})
    assert p2.aspect_prefs == {"story": 0.2}            # stated aspects are authoritative; no inferred extras
