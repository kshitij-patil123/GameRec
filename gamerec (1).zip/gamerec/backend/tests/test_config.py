from app.core.config import ROOT, Settings


def test_relative_sqlite_path_is_anchored_to_project_root():
    assert Settings(database_url="sqlite:///./gamerec.db").database_url == f"sqlite:///{ROOT / 'gamerec.db'}"
    assert Settings(database_url="sqlite:///data.db").database_url == f"sqlite:///{ROOT / 'data.db'}"


def test_other_urls_are_left_alone():
    for url in ("sqlite:////abs/path/x.db", "sqlite://", "sqlite:///:memory:",
                "postgresql+psycopg2://u:p@localhost:5432/gamerec"):
        assert Settings(database_url=url).database_url == url


def test_default_database_is_inside_the_project():
    assert Settings().database_url.startswith(f"sqlite:///{ROOT}")
