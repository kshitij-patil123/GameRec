import pandas as pd
import pytest
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from app.core.db import Base
from app.ingestion.loader import load_source
from app.ingestion.sources import get_source
from app.recommender.content import ContentRecommender, UnknownGameError, rating_to_weight
from app.services.content_service import build_content_recommender, user_weighted_games

GAMES = pd.DataFrame([
    dict(game_id=1, genres=["RPG", "Action"], tags=["open world", "story rich"], description="epic fantasy quest", keywords="story"),
    dict(game_id=2, genres=["RPG"], tags=["open world"], description="fantasy adventure quest", keywords="story"),
    dict(game_id=3, genres=["Racing"], tags=["fast paced"], description="street cars speed", keywords="speed"),
    dict(game_id=4, genres=["Racing"], tags=["multiplayer"], description="kart party speed", keywords="speed"),
    dict(game_id=5, genres=[], tags=[], description="", keywords=""),   # no metadata at all
])


@pytest.fixture(scope="module")
def rec():
    return ContentRecommender().fit(GAMES)


def test_similar_games_ranks_same_genre_first(rec):
    assert rec.similar_games(1, 2)[0][0] == 2
    assert rec.similar_games(3, 1)[0][0] == 4
    assert all(g != 1 for g, _ in rec.similar_games(1, 10))


def test_unknown_game_raises(rec):
    with pytest.raises(UnknownGameError):
        rec.similar_games(999)


def test_game_without_metadata_does_not_crash(rec):
    assert all(s == 0 for s in rec.similarity_scores(5).values())
    assert all(g != 5 or s == 0 for g, s in rec.recommend({1: 2.0}, n=10))


def test_profile_recommendation_excludes_seen_and_respects_dislikes(rec):
    liked = rec.recommend({1: 2.0}, n=3)
    assert 1 not in [g for g, _ in liked] and liked[0][0] == 2
    mixed = rec.recommend({1: 2.0, 3: -2.0}, n=4)
    assert mixed[0][0] == 2
    assert rec.recommend({}, n=3) == [] and rec.recommend({1: 0.0}, n=3) == []


def test_cold_start_preferences_and_new_game(rec):
    assert rec.recommend_for_preferences(["Racing"], [])[0][0] in (3, 4)
    assert rec.recommend_for_preferences(["RPG"], ["open world"], favorite_game_ids=[2])[0][0] == 1
    assert rec.recommend_for_preferences([], []) == []
    assert rec.similar_to_new_game(["RPG"], ["story rich"], "a fantasy quest")[0][0] in (1, 2)
    assert rec.similar_to_new_game([], [], "") == []


def test_shared_features(rec):
    sf = rec.shared_features(1, [2])
    assert "rpg" in sf["genres"] and "open_world" in sf["tags"]


def test_rating_to_weight():
    assert rating_to_weight(5) == 2 and rating_to_weight(1) == -2 and rating_to_weight(3) == 0
    assert rating_to_weight(None, "liked") > 0 and rating_to_weight(None, "disliked") < 0
    assert rating_to_weight(float("nan"), None) == 0


def test_weights_are_normalized():
    assert sum(ContentRecommender({"genres": 3, "tags": 3, "description": 2, "keywords": 2}).weights.values()) == pytest.approx(1)


@pytest.fixture()
def db():
    engine = create_engine("sqlite://")
    Base.metadata.create_all(engine)
    with sessionmaker(bind=engine)() as s:
        load_source(s, get_source("demo"))
        yield s


def test_service_builds_and_reads_user_ratings(db):
    rec = build_content_recommender(db)
    assert len(rec.ids) == 24
    weights = user_weighted_games(db, user_id=1)
    assert weights and rec.recommend(weights, n=5)
    assert user_weighted_games(db, user_id=99999) == {}
