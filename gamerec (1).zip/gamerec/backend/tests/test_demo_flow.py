"""The 12-step demo flow from the project brief, end to end through the HTTP API."""
from tests.test_api import make_client


def test_demo_flow():
    c = make_client()
    # 1-2. open the app, see demo banner, create a profile
    assert c.get("/meta").json()["banner"]
    uid = c.post("/users", json={"display_name": "Demo student"}).json()["id"]
    # 3. choose favorite genres/tags + aspect priorities
    assert c.post(f"/users/{uid}/preferences", json={"genres": ["RPG", "Action"], "tags": ["open world"],
                                                     "aspects": {"story": 0.9, "exploration": 0.9}}).status_code == 200
    cold = c.get(f"/recommendations/{uid}", params={"n": 5}).json()
    assert cold["strategy"] == "cold_start_preferences" and cold["n_ratings"] == 0
    # 4-5. rate several games -> preference profile is rebuilt
    for game in cold["items"][:3]:
        assert c.post(f"/users/{uid}/ratings", json={"game_id": game["game"]["id"], "rating": 5}).status_code == 201
    profile = c.get(f"/users/{uid}/profile").json()
    assert profile["n_ratings"] == 3 and not profile["cold_start"] and profile["favorite_genres"]
    # 6-7. community analytics and trends are available
    assert c.get("/analytics/sentiment").json()["timeline"] and c.get("/trending/games").json()
    # 8. personalized, explained, ranked recommendations (full hybrid now)
    recs = c.get(f"/recommendations/{uid}", params={"n": 6, "save": True}).json()
    assert recs["strategy"] == "hybrid" and set(recs["items"][0]["components"]) >= {"content", "collaborative"}
    assert all(i["reasons"] for i in recs["items"])
    # 9-10. open a recommended game: similarity, community, aspects, trend, personal explanation
    gid = recs["items"][0]["game"]["id"]
    assert c.get(f"/games/{gid}/similar").json()
    community = c.get(f"/games/{gid}/community-analysis").json()
    assert community["aspects"] and community["timeline"] and community["sentiment"]
    explanation = c.get(f"/recommendations/{uid}/explain/{gid}").json()
    assert explanation["rank"] == 1 and explanation["reasons"]
    # 11-12. rate the recommendation: it leaves the list and the profile/history update
    assert c.post(f"/users/{uid}/ratings", json={"game_id": gid, "rating": 2}).status_code == 201
    after = c.get(f"/recommendations/{uid}", params={"n": 6, "save": True}).json()
    assert gid not in {i["game"]["id"] for i in after["items"]}
    p2 = c.get(f"/users/{uid}/profile").json()
    assert p2["n_ratings"] == 4 and len(p2["recommendation_history"]) == 2
    assert p2["genre_weights"] != profile["genre_weights"]
