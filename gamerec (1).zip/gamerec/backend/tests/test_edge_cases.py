"""Edge cases required by the brief: new user, unknown game, empty review, missing metadata, no ratings,
insufficient community data; plus a Discord-export ingestion and privacy check."""
import json
import shutil
from pathlib import Path

import pandas as pd
import pytest
from sqlalchemy import create_engine, func, select
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from app.core.db import Base
from app.ingestion.loader import load_source
from app.ingestion.sources import CsvSource, DiscordExportSource, hash_id
from app.models import Game, Message, Rating
from app.nlp.sentiment import VaderModel
from app.services.aspect_service import analyze_aspects, game_aspect_matrix
from app.services.recommendation_service import build_bundle, recommend_for_user
from app.services.sentiment_service import analyze_messages, game_sentiment_stats
from app.services.trend_service import compute_and_store_scores
from app.services.user_service import create_user
from tests.test_api import make_client

SAMPLE = Path(__file__).resolve().parents[2] / "data" / "sample"


def write_source(tmp_path, games, messages, ratings):
    pd.DataFrame(games).to_csv(tmp_path / "games.csv", index=False)
    pd.DataFrame(messages).to_csv(tmp_path / "messages.csv", index=False)
    pd.DataFrame(ratings).to_csv(tmp_path / "ratings.csv", index=False)
    return CsvSource(tmp_path, "test", "synthetic")


@pytest.fixture()
def db():
    engine = create_engine("sqlite://", connect_args={"check_same_thread": False}, poolclass=StaticPool)
    Base.metadata.create_all(engine)
    with sessionmaker(bind=engine, expire_on_commit=False)() as s:
        yield s


def test_games_with_missing_metadata_and_no_ratings_or_messages(db, tmp_path):
    """Only id+name given for every game; no ratings; no messages at all."""
    src = write_source(tmp_path, [{"game_id": 1, "game_name": "Bare One"}, {"game_id": 2, "game_name": "Bare Two"}],
                       [{"message_id": "m", "text": "x", "timestamp": "2026-01-01"}][:0] or
                       pd.DataFrame(columns=["message_id", "text", "timestamp"]),
                       pd.DataFrame(columns=["user_id", "game_id"]))
    load_source(db, src)
    assert db.scalar(select(func.count()).select_from(Game)) == 2
    assert analyze_messages(db, VaderModel()) == 0 and game_sentiment_stats(db, "vader") == []
    assert game_aspect_matrix(db).empty
    with pytest.raises(ValueError):                       # no sentiment -> clear error, not a crash
        compute_and_store_scores(db)
    bundle = build_bundle(db)                             # recommender still builds with zero ratings/community
    user = create_user(db, "Newbie")
    recs = recommend_for_user(db, bundle, user.id, n=5)
    assert len(recs) == 2 and recs[0].strategy == "catalog_fallback" and recs[0].reasons
    assert all(r.reasons and not any("community" == x["type"] for x in r.reasons if x["positive"]) for r in recs)


def test_empty_and_junk_reviews_are_handled(db, tmp_path):
    msgs = [{"message_id": f"m{i}", "game_id": 1, "user_id": "u1", "text": t, "timestamp": "2026-02-01"}
            for i, t in enumerate(["", "   ", "!!!", "👍", "😂😂", "https://x.co", "Great story!", "Great story!"])]
    load_source(db, write_source(tmp_path, [{"game_id": 1, "game_name": "G"}], msgs, pd.DataFrame(columns=["user_id", "game_id"])))
    n = analyze_messages(db, VaderModel())
    assert n <= 2                                          # junk skipped; duplicate "Great story!" counted once
    stats = game_sentiment_stats(db, "vader")
    assert stats and stats[0]["n_messages"] == n


def test_api_with_insufficient_community_data():
    c = make_client()
    created = c.post("/users", json={"display_name": "Edge"}).json()["id"]
    # a game rated by nobody and (in a fresh client) fully analyzed still returns well-formed answers;
    # unknown ids give clean 404s
    assert c.get("/games/424242/similar").status_code == 404
    assert c.get("/games/424242/community-analysis").status_code == 404
    assert c.get(f"/recommendations/{created}/explain/424242").status_code == 404
    assert c.get("/recommendations/424242").status_code == 404


def test_game_with_no_messages_gets_empty_but_valid_analysis(db, tmp_path):
    src = write_source(
        tmp_path, [{"game_id": 1, "game_name": "Talked About", "genre": "RPG"}, {"game_id": 2, "game_name": "Silent", "genre": "RPG"}],
        [{"message_id": f"m{i}", "game_id": 1, "user_id": "u", "text": "Talked About has great story and amazing graphics",
          "timestamp": f"2026-03-{i + 1:02d}", "engagement": 1} for i in range(12)],
        [{"user_id": "u1", "game_id": 1, "rating": 5}, {"user_id": "u1", "game_id": 2, "rating": 4}])
    load_source(db, src)
    analyze_messages(db, VaderModel()); analyze_aspects(db, VaderModel())
    scores = compute_and_store_scores(db)
    assert set(scores["game_id"]) == {1}                  # the silent game has no score row, and nothing crashed
    bundle = build_bundle(db)
    u = create_user(db, "x")
    assert {r.game_id for r in recommend_for_user(db, bundle, u.id)} == {1, 2}


# ---------- Discord export ingestion and privacy ----------
def test_discord_export_is_hashed_live_and_linked_by_name(db, tmp_path):
    for name in ("games.csv", "ratings.csv"):
        shutil.copy(SAMPLE / name, tmp_path / name)
    export = [{"id": "9001", "author_id": "424242424242", "content": "Honestly Ashen Crown has an amazing story",
               "timestamp": "2026-08-30T10:00:00", "reactions": 3},
              {"id": "9002", "author_id": "555", "content": "nothing about any game here", "timestamp": "2026-08-30T11:00:00"},
              {"id": "9003", "author_id": "556", "content": "Ashen Crown and Star Drifters both good", "timestamp": "2026-08-30T12:00:00"}]
    (tmp_path / "discord_export.json").write_text(json.dumps(export))
    src = DiscordExportSource(tmp_path)
    assert src.source_type == "live" and not src.is_demo
    load_source(db, src)
    rows = {m.external_id: m for m in db.scalars(select(Message))}
    assert set(rows) == {"9001", "9002", "9003"} and {m.source_type for m in rows.values()} == {"live"}
    assert rows["9001"].author_hash == hash_id("424242424242") and "424242424242" not in rows["9001"].author_hash
    assert rows["9001"].game_id is not None and rows["9001"].engagement == 3
    assert rows["9002"].game_id is None and rows["9003"].game_id is None   # no mention / ambiguous -> unlinked
    assert db.scalar(select(func.count()).select_from(Rating)) > 0


def test_discord_export_missing_file_gives_clear_error(tmp_path):
    for name in ("games.csv", "ratings.csv"):
        shutil.copy(SAMPLE / name, tmp_path / name)
    with pytest.raises(FileNotFoundError, match="discord_export.json"):
        DiscordExportSource(tmp_path).messages()
