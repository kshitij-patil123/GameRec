import math
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

from app.evaluation.experiments import (EvalContext, Popularity, make_cases, run_evaluation, tune_weights)
from app.evaluation.metrics import (bootstrap_ci, f1_at_k, hit_rate_at_k, ndcg_at_k, paired_diff_ci,
                                    precision_at_k, recall_at_k, user_metrics)
from app.evaluation.report import SYNTHETIC_BANNER, render_markdown
from app.evaluation.splits import chronological_split
from app.recommender.content import ContentRecommender

SAMPLE = Path(__file__).resolve().parents[2] / "data" / "sample"


# ---------- metrics (hand-computed values) ----------
def test_precision_recall_f1_hit_rate():
    ranked, rel = [1, 2, 3, 4, 5], {2, 5, 9}
    assert precision_at_k(ranked, rel, 5) == pytest.approx(2 / 5)
    assert recall_at_k(ranked, rel, 5) == pytest.approx(2 / 3)
    assert f1_at_k(ranked, rel, 5) == pytest.approx(2 * (2 / 5) * (2 / 3) / (2 / 5 + 2 / 3))
    assert precision_at_k(ranked, rel, 1) == 0 and f1_at_k(ranked, rel, 1) == 0 and hit_rate_at_k(ranked, rel, 1) == 0
    assert hit_rate_at_k(ranked, rel, 2) == 1


def test_precision_uses_k_not_list_length():
    assert precision_at_k([7], {7}, 5) == pytest.approx(1 / 5)


def test_ndcg_known_values():
    assert ndcg_at_k([1, 2, 3], {1}, 3) == pytest.approx(1.0)                       # hit at rank 1
    assert ndcg_at_k([9, 1, 3], {1}, 3) == pytest.approx(1 / math.log2(3))          # hit at rank 2
    two = (1 / math.log2(2) + 1 / math.log2(4)) / (1 / math.log2(2) + 1 / math.log2(3))
    assert ndcg_at_k([1, 9, 2], {1, 2}, 3) == pytest.approx(two)
    assert ndcg_at_k([9, 8, 7], {1}, 3) == 0
    assert math.isnan(ndcg_at_k([1], set(), 3)) and math.isnan(recall_at_k([1], set(), 3))


def test_user_metrics_keys():
    assert set(user_metrics([1, 2], {1}, [1, 2])) == {f"{m}@{k}" for m in
                                                      ("precision", "recall", "f1", "ndcg", "hit_rate") for k in (1, 2)}


def test_bootstrap_ci_and_paired_diff():
    rng = np.random.default_rng(0)
    a, b = rng.normal(0.6, 0.1, 200), rng.normal(0.5, 0.1, 200)
    mean, lo, hi = bootstrap_ci(a)
    assert lo < mean < hi and hi - lo < 0.05
    assert paired_diff_ci(a, b)["significant"] is True
    assert paired_diff_ci(a, a + rng.normal(0, 0.001, 200))["significant"] is False
    assert math.isnan(bootstrap_ci([])[0])


# ---------- splits ----------
def _ratings(n_users=10, n_items=12, per_user=10):
    rng = np.random.default_rng(1)
    rows = []
    for u in range(1, n_users + 1):
        for t, g in enumerate(rng.choice(np.arange(1, n_items + 1), per_user, replace=False)):
            rows.append((u, int(g), float(rng.integers(1, 6)), pd.Timestamp("2026-01-01") + pd.Timedelta(days=t)))
    return pd.DataFrame(rows, columns=["user_id", "game_id", "rating", "created_at"])


def test_split_is_chronological_disjoint_and_complete():
    r = _ratings()
    splits = chronological_split(r)
    assert len(splits) == 10
    for s in splits:
        mine = r[r.user_id == s.user_id].sort_values("created_at")
        order = list(mine.game_id)
        got = list(s.train) + list(s.val) + list(s.test)
        assert got == order                                     # same items, same chronological order
        assert not set(s.train) & set(s.val) and not set(s.val) & set(s.test)
        assert len(s.train) >= 2 and len(s.test) >= 1


def test_split_drops_short_users_and_validates_fractions():
    r = pd.concat([_ratings(3), pd.DataFrame([(99, 1, 5.0, pd.Timestamp("2026-01-01"))] * 1,
                                              columns=["user_id", "game_id", "rating", "created_at"])])
    assert 99 not in {s.user_id for s in chronological_split(r)}
    with pytest.raises(ValueError):
        chronological_split(r, train_frac=0.9, val_frac=0.2)


def test_cases_have_no_leakage():
    r = _ratings()
    splits = chronological_split(r)
    games = list(range(1, 13))
    val, _ = make_cases(splits, "val", games, 4.0)
    test, _ = make_cases(splits, "test", games, 4.0)
    by_user = {s.user_id: s for s in splits}
    for c in val:
        s = by_user[c.user_id]
        assert not set(c.candidates) & (set(s.train) | set(s.test))     # no history, no future items
        assert c.relevant <= set(s.val) and set(c.history) == set(s.train)
    for c in test:
        s = by_user[c.user_id]
        assert not set(c.candidates) & (set(s.train) | set(s.val))
        assert c.relevant <= set(s.test) and all(s.test[g] >= 4 for g in c.relevant)
        assert set(c.history) == set(s.train) | set(s.val)           # the test ratings are never in the history


def test_popularity_ranker_and_leave_one_out():
    df = pd.DataFrame({"game_id": [1, 1, 2, 3], "rating": [5, 4, 3, 5]})
    assert Popularity(df).rank([1, 2, 3])[0] == 1
    assert Popularity(df).rank([1, 2, 3], exclude={1: 5.0})[0] in (2, 3, 1)      # still well-defined
    assert Popularity(df).rank([1, 2, 3], exclude={1: 5, })[:1] != [] and Popularity(df).count[1] == 2


# ---------- full harness with positive and null controls (no database needed) ----------
@pytest.fixture(scope="module")
def ctx():
    games = pd.read_csv(SAMPLE / "games.csv")
    frame = pd.DataFrame({
        "game_id": games.game_id, "genres": games.genre.str.split("|"), "tags": games.tags.str.split("|"),
        "description": games.description, "keywords": ""})
    content = ContentRecommender().fit(frame)
    info = frame.set_index("game_id")[["genres", "tags"]].assign(
        name=games.set_index("game_id").game_name, sentiment=np.nan, trend=np.nan, status=None, confidence=np.nan)
    return EvalContext(content, info, pd.DataFrame(), pd.DataFrame(), info[["name", "genres", "tags"]])


def _planted(ctx, n_users=250, per_user=14, seed=3, planted=True):
    """Ratings driven by genre affinity (planted=True) or pure noise (planted=False)."""
    rng = np.random.default_rng(seed)
    genres = sorted({g for gs in ctx.game_info.genres for g in gs})
    ids = list(ctx.game_info.index)
    rows = []
    for u in range(1, n_users + 1):
        liked = set(rng.choice(genres, 3, replace=False))
        for t, g in enumerate(rng.choice(ids, per_user, replace=False)):
            match = len(liked & set(ctx.game_info.at[g, "genres"]))
            rating = 2.5 + 1.2 * match + rng.normal(0, 0.5) if planted else rng.uniform(1, 5)
            rows.append((u, int(g), float(np.clip(round(rating), 1, 5)), pd.Timestamp("2026-01-01") + pd.Timedelta(days=t)))
    return pd.DataFrame(rows, columns=["user_id", "game_id", "rating", "created_at"])


def test_positive_control_harness_detects_planted_signal(ctx):
    res = run_evaluation(ctx, _planted(ctx), ks=[5], tune_trials=5, n_boot=500)
    s = res["test"]["summary"]
    assert res["data"]["n_eval_users"] > 100
    for model in ("content_only", "cf_only", "hybrid_default"):
        assert s[model]["ndcg@5"]["mean"] > s["random"]["ndcg@5"]["mean"] + 0.05, model
    assert res["test"]["paired"]["hybrid_default vs content_cf"]["ndcg@5"]["mean_diff"] is not None
    assert res["tuning"]["best_val"] >= res["tuning"]["default_val"]


def test_null_control_no_model_beats_random_on_noise(ctx):
    res = run_evaluation(ctx, _planted(ctx, planted=False), ks=[5], tune_trials=5, n_boot=500)
    s = res["test"]["summary"]
    for model in ("content_only", "cf_only", "hybrid_default", "popularity"):
        diff = s[model]["ndcg@5"]["mean"] - s["random"]["ndcg@5"]["mean"]
        assert abs(diff) < 0.06, f"{model} differs from random by {diff:.3f} on pure noise (leakage?)"


def test_cold_start_section_and_limits(ctx):
    res = run_evaluation(ctx, _planted(ctx), ks=[5], tune_trials=3, n_boot=200)
    cs = res["cold_start"]
    assert cs["n_users"] > 100 and cs["summary"]["content_only"]["ndcg@5"]["mean"] > cs["summary"]["random"]["ndcg@5"]["mean"]
    with pytest.raises(ValueError):
        run_evaluation(ctx, _planted(ctx), cold_given=3)


def test_small_data_gets_warnings_and_report_banner(ctx):
    res = run_evaluation(ctx, _planted(ctx, n_users=12), ks=[10], tune_trials=2, n_boot=100)
    assert any("test users" in w for w in res["warnings"]) and any("pool" in w for w in res["warnings"])
    assert SYNTHETIC_BANNER in render_markdown(res, synthetic=True)
    assert "SYNTHETIC" not in render_markdown(res, synthetic=False)
    assert "| Model |" in render_markdown(res, False)


def test_tune_weights_returns_normalized_weights(ctx):
    r = _planted(ctx, n_users=60)
    from app.evaluation.experiments import ItemItemCF
    splits = chronological_split(r)
    cases, _ = make_cases(splits, "val", list(ctx.game_info.index), 4.0)
    train = pd.DataFrame([(s.user_id, g, v) for s in splits for g, v in s.train.items()], columns=["user_id", "game_id", "rating"])
    out = tune_weights(ctx.hybrid(ItemItemCF().fit(train)), ctx, cases, trials=5, k=5, seed=1)
    assert sum(out["best_weights"].values()) == pytest.approx(1.0) and out["best_val"] >= out["default_val"]
