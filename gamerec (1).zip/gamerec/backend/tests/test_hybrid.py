import numpy as np
import pandas as pd
import pytest

from app.recommender.collaborative import ItemItemCF
from app.recommender.content import ContentRecommender
from app.recommender.explain import build_reasons
from app.recommender.hybrid import DEFAULT_WEIGHTS, HybridRecommender, validate_weights
from app.recommender.profile import build_profile

GAMES = pd.DataFrame([
    dict(game_id=1, name="Alpha", genres=["RPG"], tags=["story rich"], description="fantasy quest", keywords="story"),
    dict(game_id=2, name="Beta", genres=["RPG"], tags=["story rich"], description="fantasy adventure", keywords="story"),
    dict(game_id=3, name="Gamma", genres=["Racing"], tags=["fast"], description="cars speed", keywords="speed"),
    dict(game_id=4, name="Delta", genres=["Racing"], tags=["fast"], description="kart speed", keywords="speed"),
    dict(game_id=5, name="Eps", genres=["Puzzle"], tags=["relaxing"], description="calm puzzles", keywords="calm"),
])
INFO = GAMES.set_index("game_id")[["name", "genres", "tags"]].assign(
    sentiment=[0.8, 0.7, 0.4, 0.6, 0.5], trend=[0.5, 0.9, 0.2, 0.3, 0.1],
    status=["stable", "rising", "declining", "stable", "stable"], confidence=[0.9, 0.9, 0.9, 0.3, 0.9],
    pos_pct=[70.0, 65.0, 30.0, 50.0, 40.0])
ASP = pd.DataFrame({"story": [0.5, 0.6, -0.2, 0.0, 0.1], "combat": [0.2, 0.3, 0.4, 0.3, 0.0]}, index=[1, 2, 3, 4, 5])
RATINGS = pd.DataFrame([(u, g, r) for u in range(1, 7) for g, r in ((1, 5), (2, 4), (3, 2), (4, 2), (5, 3))],
                       columns=["user_id", "game_id", "rating"])


@pytest.fixture(scope="module")
def engine():
    return HybridRecommender(ContentRecommender().fit(GAMES), ItemItemCF(shrinkage=1.0).fit(RATINGS), INFO, ASP)


def profile(rows=(), **kw):
    return build_profile(1, rows, game_meta=INFO, **kw)


def test_weights_validation_and_default_sum():
    assert sum(DEFAULT_WEIGHTS.values()) == pytest.approx(1.0)
    with pytest.raises(ValueError):
        validate_weights({"nonsense": 1})
    with pytest.raises(ValueError):
        validate_weights({c: 0 for c in DEFAULT_WEIGHTS})
    with pytest.raises(ValueError):
        validate_weights({"content": -1})


def test_rated_user_gets_similar_unseen_games_first_and_no_seen_games(engine):
    recs = engine.recommend(profile([(1, 5, "rated"), (3, 1, "rated"), (4, 1, "rated")]), n=5)
    assert recs[0].game_id == 2
    assert not {r.game_id for r in recs} & {1, 3, 4}
    assert recs[0].strategy == "hybrid" and 0 <= recs[0].score <= 1
    assert sum(recs[0].contributions.values()) == pytest.approx(recs[0].score)


def test_scores_sorted_and_components_normalized(engine):
    recs = engine.recommend(profile([(1, 5, "rated"), (3, 1, "rated"), (5, 3, "rated")]), n=5)
    assert [r.score for r in recs] == sorted([r.score for r in recs], reverse=True)
    assert all(0 <= v <= 1 for r in recs for v in r.components.values())


def test_new_user_with_preferences_is_cold_start(engine):
    recs = engine.recommend(profile(stated_genres=["Racing"]), n=2)
    assert {r.game_id for r in recs} == {3, 4} and recs[0].strategy == "cold_start_preferences"
    assert "collaborative" not in recs[0].components            # too few ratings -> CF dropped, weights renormalized


def test_user_with_no_signal_gets_popular_trending(engine):
    recs = engine.recommend(profile(), n=3)
    assert recs and recs[0].strategy == "popular_trending"
    assert set(recs[0].components) == {"community", "trend"}


def test_ablation_weights_change_ranking(engine):
    p = profile(stated_genres=["Racing"])
    trend_only = engine.recommend(p, n=1, weights={c: (1 if c == "trend" else 0) for c in DEFAULT_WEIGHTS})
    content_only = engine.recommend(p, n=1, weights={c: (1 if c == "content" else 0) for c in DEFAULT_WEIGHTS})
    assert trend_only[0].game_id == 2 and content_only[0].game_id in (3, 4)
    assert list(trend_only[0].components) == ["trend"]


def test_everyone_seen_returns_empty(engine):
    assert engine.recommend(profile([(g, 4, "rated") for g in range(1, 6)])) == []


def test_missing_community_data_uses_neutral_value():
    info = INFO.copy()
    info.loc[5, ["sentiment", "trend", "confidence"]] = np.nan
    eng = HybridRecommender(ContentRecommender().fit(GAMES), ItemItemCF().fit(RATINGS), info)
    recs = eng.recommend(profile(), n=5)
    assert len(recs) == 5 and all(np.isfinite(r.score) for r in recs)


def test_reasons_are_evidence_based_and_include_caveats(engine):
    p = profile([(1, 5, "rated")], explicit_aspects={"story": 0.9})
    recs = {r.game_id: r for r in engine.recommend(p, n=4)}
    texts2 = " | ".join(x["text"] for x in recs[2].reasons)
    assert "content similarity with Alpha" in texts2 and "Strong positive community sentiment" in texts2
    assert "Story" in texts2 and "trending" in texts2
    texts3 = " | ".join(x["text"] for x in recs[3].reasons)
    assert "Caveat: the community is negative about Story" in texts3 and "declining" in texts3
    assert "Limited community data" in " | ".join(x["text"] for x in recs[4].reasons)
    assert "Strong positive" not in texts3


def test_fallback_reason_when_nothing_qualifies(engine):
    info = INFO.assign(sentiment=0.5, trend=0.5, status="stable", confidence=0.9)
    eng = HybridRecommender(engine.content, engine.collab, info, None)
    reasons = build_reasons(5, pd.Series(dtype=float), profile(), eng.content, eng.collab, info, pd.DataFrame())
    assert reasons[0]["type"] == "overall"


def test_catalog_fallback_when_no_signal_at_all():
    info = INFO.assign(sentiment=np.nan, trend=np.nan, confidence=np.nan, catalog_rating=[4.0, 4.8, 3.0, np.nan, 4.5])
    eng = HybridRecommender(ContentRecommender().fit(GAMES), ItemItemCF().fit(RATINGS.iloc[0:0]), info)
    recs = eng.recommend(profile(), n=5)
    assert [r.strategy for r in recs] == ["catalog_fallback"] * 5
    assert [r.game_id for r in recs][:3] == [2, 5, 1] and recs[-1].game_id in (3, 4)
    assert recs[0].reasons[0]["type"] == "overall" and recs[0].components == {}
    # without any catalog rating it still returns every game, in a deterministic order
    bare = HybridRecommender(ContentRecommender().fit(GAMES), ItemItemCF(), info.drop(columns="catalog_rating"))
    assert [r.game_id for r in bare.recommend(profile(), n=5)] == [1, 2, 3, 4, 5]
