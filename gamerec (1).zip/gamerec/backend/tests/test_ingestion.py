import pandas as pd
import pytest
from sqlalchemy import create_engine, func, select
from sqlalchemy.orm import sessionmaker

from app.core.db import Base
from app.ingestion.loader import link_games_by_name, load_source
from app.ingestion.sources import SchemaError, get_source, validate
from app.models import Game, Message, Rating


@pytest.fixture()
def db():
    engine = create_engine("sqlite://")
    Base.metadata.create_all(engine)
    with sessionmaker(bind=engine)() as session:
        yield session


def test_validate_rejects_missing_required():
    with pytest.raises(SchemaError):
        validate("games", pd.DataFrame({"game_name": ["x"]}))


def test_validate_fills_optional():
    out = validate("games", pd.DataFrame({"game_id": [1], "game_name": ["x"]}))
    assert "genre" in out.columns


def test_link_games_by_name_handles_none_and_ambiguous():
    games = pd.DataFrame({"game_id": [1, 2], "game_name": ["Alpha", "Beta"]})
    msgs = pd.DataFrame({"game_id": [pd.NA] * 3, "text": ["alpha rocks", "nothing here", "alpha vs beta"]})
    out = link_games_by_name(msgs, games)
    assert out["game_id"].iloc[0] == 1
    assert pd.isna(out["game_id"].iloc[1]) and pd.isna(out["game_id"].iloc[2])


def test_demo_load_marks_synthetic_and_skips_duplicates(db):
    counts = load_source(db, get_source("demo"))
    assert counts["games"] > 0 and counts["ratings"] > 0
    assert db.scalar(select(func.count()).select_from(Game)) == counts["games"]
    kinds = set(db.scalars(select(Message.source_type)))
    assert kinds == {"synthetic"}
    assert db.scalar(select(func.count()).select_from(Rating)) == counts["ratings"]
