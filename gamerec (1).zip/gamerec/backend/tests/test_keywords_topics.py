import pandas as pd
import pytest
from sqlalchemy import create_engine, func, select
from sqlalchemy.orm import sessionmaker

from app.analytics.keywords import distinctive_keywords, emerging_keywords, name_stopwords, top_keywords
from app.analytics.topics import fit_topics, label_topic, select_k
from app.core.db import Base
from app.ingestion.loader import load_source
from app.ingestion.sources import get_source
from app.models import GameTopic, MessageTopic, Topic
from app.services.topic_service import run_topic_analysis, topic_frequency, topic_trends

DOCS = (["story character plot narrative ending"] * 8 + ["combat weapon boss fight melee"] * 8
        + ["multiplayer server matchmaking coop online"] * 8)


def test_top_keywords_and_empty():
    assert top_keywords(DOCS, 3, min_df=1)
    assert top_keywords([], 5) == [] and top_keywords(["", ""], 5) == []


def test_distinctive_keywords_excludes_game_names():
    texts = ["zelda dungeon puzzle"] * 5 + ["mario jump platform"] * 5
    out = distinctive_keywords(texts, ["a"] * 5 + ["b"] * 5, 3, extra_stop=name_stopwords(["Zelda", "Mario"]))
    assert "zelda" not in [t for t, _ in out["a"]] and "dungeon" in " ".join(t for t, _ in out["a"])


def test_emerging_keywords_finds_growth():
    now = pd.Timestamp("2026-09-01")
    old = pd.DataFrame({"created_at": [now - pd.Timedelta(days=45)] * 20, "text_clean": ["story fun"] * 20})
    new = pd.DataFrame({"created_at": [now - pd.Timedelta(days=3)] * 20, "text_clean": ["season update"] * 20})
    out = emerging_keywords(pd.concat([old, new]), min_recent=5)
    assert out and out[0]["term"] in {"season", "update", "season update"}
    assert emerging_keywords(pd.DataFrame(columns=["created_at", "text_clean"])) == []


def test_fit_topics_discovers_three_groups():
    res = fit_topics(DOCS, k=3, min_df=1, max_df=1.0)
    assert len(res.topics) == 3 and res.doc_topic.shape == (24, 3)
    assert abs(res.doc_topic.sum(axis=1) - 1).max() < 1e-6
    labels = {t["label"] for t in res.topics}
    assert "Combat" in labels and "Multiplayer" in labels


def test_fit_topics_too_few_docs_raises():
    with pytest.raises(ValueError):
        fit_topics(["a b"], k=5)


def test_label_falls_back_to_none():
    assert label_topic(["zzz", "qqq"]) is None


def test_select_k_returns_candidate():
    k, scores = select_k(DOCS, candidates=(2, 3), min_df=1, max_df=1.0)
    assert k in scores


@pytest.fixture()
def db():
    engine = create_engine("sqlite://")
    Base.metadata.create_all(engine)
    with sessionmaker(bind=engine)() as s:
        load_source(s, get_source("demo"))
        yield s


def test_topic_service_persists_and_trends(db):
    res = run_topic_analysis(db, k=6)
    assert res["k"] == 6
    assert db.scalar(select(func.count()).select_from(Topic)) == 6
    assert db.scalar(select(func.count()).select_from(MessageTopic)) > 0
    assert db.scalar(select(func.count()).select_from(GameTopic)) > 0
    assert abs(topic_frequency(db)["share"].sum() - 1) < 1e-6
    trends = topic_trends(db)
    assert abs(trends.sum(axis=1) - 1).max() < 1e-6


def test_topic_service_insufficient_data():
    engine = create_engine("sqlite://")
    Base.metadata.create_all(engine)
    with sessionmaker(bind=engine)() as s, pytest.raises(ValueError):
        run_topic_analysis(s)
