import pandas as pd

from app.nlp.preprocessing import normalize_classical, normalize_light, preprocess_frame


def test_urls_and_mentions_removed():
    assert "http" not in normalize_light("check https://x.com/a now <@123> hi")
    assert normalize_classical("look https://x.com/a") == "look"


def test_negations_survive_stopword_removal():
    assert "not" in normalize_classical("this is not good").split()
    assert "not" in normalize_classical("I don't like it").split()


def test_light_view_keeps_case_punctuation_emoji():
    out = normalize_light("AMAZING!!! 🔥 :)")
    assert "AMAZING!!!" in out and "🔥" in out and ":)" in out


def test_slang_and_emoji_words():
    assert "good game" in normalize_classical("gg", lemmatize=False)
    assert "great" in normalize_classical("🔥", lemmatize=False)


def test_empty_and_invalid_inputs():
    for bad in ["", "   ", "!!!", None, float("nan")]:
        assert normalize_classical(bad) == ""


def test_lemmatization_never_crashes():
    assert normalize_classical("playing games") != ""


def test_preprocess_frame_flags_invalid_and_duplicates():
    df = pd.DataFrame({"game_id": [1, 1, 2], "text": ["Great story!!", "great story", ""]})
    out = preprocess_frame(df, group_col="game_id")
    assert list(out["is_valid"]) == [True, True, False]
    assert list(out["is_duplicate"]) == [False, True, False]
    assert len(out) == 3
