import pytest
from sqlalchemy import create_engine, func, select
from sqlalchemy.orm import sessionmaker

from app.core.db import Base
from app.ingestion.loader import load_source
from app.ingestion.sources import get_source
from app.models import Rating, Recommendation as RecRow, User, UserPreference
from app.nlp.sentiment import VaderModel
from app.services.aspect_service import analyze_aspects
from app.services.recommendation_service import build_bundle, load_profile, recommend_for_user
from app.services.sentiment_service import analyze_messages
from app.services.trend_service import compute_and_store_scores


@pytest.fixture(scope="module")
def ctx():
    engine = create_engine("sqlite://")
    Base.metadata.create_all(engine)
    db = sessionmaker(bind=engine, expire_on_commit=False)()
    load_source(db, get_source("demo"))
    analyze_messages(db, VaderModel())
    analyze_aspects(db, VaderModel())
    compute_and_store_scores(db)
    yield db, build_bundle(db)
    db.close()


def test_existing_user_gets_explained_recommendations(ctx):
    db, bundle = ctx
    seen = set(db.scalars(select(Rating.game_id).where(Rating.user_id == 1)))
    recs = recommend_for_user(db, bundle, 1, n=5)
    assert len(recs) == 5 and not {r.game_id for r in recs} & seen
    assert all(r.reasons for r in recs) and recs[0].strategy == "hybrid"


def test_new_user_and_blank_user_and_unknown_user(ctx):
    db, bundle = ctx
    u = User(external_id="t-new"); db.add(u); db.flush()
    db.add_all([UserPreference(user_id=u.id, kind="genre", key="RPG"),
                UserPreference(user_id=u.id, kind="aspect", key="story", value=0.9)])
    blank = User(external_id="t-blank"); db.add(blank); db.commit()
    assert recommend_for_user(db, bundle, u.id, n=3)[0].strategy == "cold_start_preferences"
    assert recommend_for_user(db, bundle, blank.id, n=3)[0].strategy == "popular_trending"
    with pytest.raises(LookupError):
        load_profile(db, bundle, 999999)


def test_new_rating_changes_recommendations_without_rebuild(ctx):
    db, bundle = ctx
    u = User(external_id="t-rater"); db.add(u); db.commit()
    before = [r.game_id for r in recommend_for_user(db, bundle, u.id, n=5)]
    db.add_all([Rating(user_id=u.id, game_id=g, rating=5, interaction="rated") for g in (7, 3, 10)])
    db.commit()
    after = recommend_for_user(db, bundle, u.id, n=5)
    assert [r.game_id for r in after] != before and not {7, 3, 10} & {r.game_id for r in after}


def test_store_appends_batches_and_prunes(ctx):
    db, bundle = ctx
    recommend_for_user(db, bundle, 2, n=4, store=True)
    recommend_for_user(db, bundle, 2, n=3, store=True)
    assert db.scalar(select(func.count()).select_from(RecRow).where(RecRow.user_id == 2)) == 7
    for _ in range(11):
        recommend_for_user(db, bundle, 2, n=2, store=True)
    stamps = set(db.scalars(select(RecRow.created_at).where(RecRow.user_id == 2)))
    assert len(stamps) == 10
