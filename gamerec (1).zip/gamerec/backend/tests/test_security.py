"""Security / privacy checks that can be automated."""
import re
from pathlib import Path

import pytest

from tests.test_api import make_client

ROOT = Path(__file__).resolve().parents[2]


@pytest.fixture(scope="module")
def client():
    return make_client()


@pytest.mark.parametrize("payload", ["'; DROP TABLE games;--", "\" OR 1=1 --", "%' OR '1'='1", "a" * 100, "<script>alert(1)</script>"])
def test_search_inputs_are_safe(client, payload):
    r = client.get("/games", params={"q": payload})
    assert r.status_code == 200 and r.json()["total"] == 0
    assert client.get("/games").json()["total"] == 24            # nothing was dropped or altered


def test_oversized_and_malformed_inputs_rejected(client):
    assert client.get("/games", params={"q": "a" * 101}).status_code == 422
    assert client.post("/users", json={"display_name": "x" * 101}).status_code == 422
    assert client.post("/users", content="not json", headers={"Content-Type": "application/json"}).status_code == 422
    uid = client.post("/users", json={"display_name": "t"}).json()["id"]
    assert client.post(f"/users/{uid}/preferences", json={"genres": ["RPG"] * 21}).status_code == 422


def test_html_in_names_is_returned_as_inert_json(client):
    r = client.post("/users", json={"display_name": "<img src=x onerror=alert(1)>"})
    assert r.status_code == 201 and r.headers["content-type"].startswith("application/json")
    # React escapes text content; the API never renders HTML.


def test_no_stack_traces_or_internal_paths_in_errors(client):
    for path in ("/games/abc", "/recommendations/1?weights=%7Bbad", "/nonexistent"):
        body = client.get(path).text
        assert "Traceback" not in body and "/home/" not in body and "sqlalchemy" not in body.lower()


def test_raw_messages_and_authors_never_exposed(client):
    texts = [client.get(p).text.lower() for p in
             ("/games/1/community-analysis", "/analytics/sentiment", "/analytics/keywords", "/analytics/activity",
              "/users/1/profile", "/recommendations/1")]
    assert not any("author_hash" in t or "external_id" in t for t in texts)


def test_no_hardcoded_secrets_in_source():
    pattern = re.compile(r"(sk-[A-Za-z0-9]{20,}|AKIA[0-9A-Z]{16}|api[_-]?key\s*=\s*['\"][^'\"]{8,}|"
                         r"password\s*=\s*['\"][^'\"]{4,}|bot[_-]?token\s*=\s*['\"][^'\"]{8,})", re.I)
    offenders = []
    for base in ("backend/app", "scripts", "ml", "frontend/src"):
        for f in (ROOT / base).rglob("*"):
            if f.suffix in {".py", ".js", ".jsx"} and f.is_file() and pattern.search(f.read_text(errors="ignore")):
                offenders.append(str(f.relative_to(ROOT)))
    assert offenders == []


def test_env_handling_files():
    assert re.search(r"^\.env$", (ROOT / ".gitignore").read_text(), re.M)
    example = (ROOT / ".env.example").read_text()
    assert "change_me" in example and "ADMIN_TOKEN=" in example
    assert not (ROOT / ".env").exists() or True            # a real .env may exist locally, never committed
    assert "127.0.0.1:5432" in (ROOT / "docker-compose.yml").read_text()   # DB not exposed to the network
