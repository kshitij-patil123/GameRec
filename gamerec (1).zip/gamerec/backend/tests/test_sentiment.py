import pytest
from sqlalchemy import create_engine, select
from sqlalchemy.orm import sessionmaker

from app.core.db import Base
from app.ingestion.loader import load_source
from app.ingestion.sources import get_source
from app.models import SentimentResult
from app.nlp.sentiment import TfidfLogRegModel, VaderModel, vader_label
from app.services.sentiment_service import analyze_messages, game_sentiment_stats


def test_vader_label_thresholds():
    assert vader_label(0.05) == "positive" and vader_label(-0.05) == "negative" and vader_label(0.0) == "neutral"


def test_vader_obvious_cases():
    preds = VaderModel().predict(["this game is amazing, I love it!", "terrible, boring and broken", "ok"])
    assert preds[0][0] == "positive" and preds[1][0] == "negative"


def test_tfidf_logreg_learns_simple_signal():
    x = ["great fun"] * 4 + ["awful bug"] * 4 + ["play tonight"] * 4
    y = ["positive"] * 4 + ["negative"] * 4 + ["neutral"] * 4
    model = TfidfLogRegModel().fit(x, y)
    (lab, score), = model.predict(["great fun"], ["great fun"])
    assert lab == "positive" and score > 0


@pytest.fixture()
def db():
    engine = create_engine("sqlite://")
    Base.metadata.create_all(engine)
    with sessionmaker(bind=engine)() as s:
        load_source(s, get_source("demo"))
        yield s


def test_pipeline_and_game_stats(db):
    n = analyze_messages(db, VaderModel())
    assert n > 0
    assert len(list(db.scalars(select(SentimentResult)))) == n
    stats = game_sentiment_stats(db, "vader")
    assert stats
    for row in stats:
        assert abs(row["positive_pct"] + row["neutral_pct"] + row["negative_pct"] - 100) < 0.5
        assert -1 <= row["avg_sentiment"] <= 1


def test_no_data_returns_empty(db):
    assert game_sentiment_stats(db, "nonexistent_model") == []
