import numpy as np
import pandas as pd
import pytest
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from app.analytics.community import DEFAULT_WEIGHTS, compute_community_scores, shrink
from app.analytics.trends import compute_trend_scores, mean_timeline, minmax, volume_timeline
from app.core.db import Base
from app.ingestion.loader import load_source
from app.ingestion.sources import get_source
from app.nlp.sentiment import VaderModel
from app.services.aspect_service import analyze_aspects
from app.services.sentiment_service import analyze_messages
from app.services.trend_service import (compute_and_store_scores, genre_popularity, latest_scores,
                                        message_volume_timeline, sentiment_timeline)

NOW = pd.Timestamp("2026-09-01")


def _msgs(game_id, days_ago, engagement=0):
    return pd.DataFrame({"game_id": game_id, "created_at": [NOW - pd.Timedelta(days=d) for d in days_ago],
                         "engagement": engagement})


def test_minmax_constant_is_neutral():
    assert (minmax(pd.Series([3, 3, 3])) == 0.5).all()


def test_rising_beats_declining_and_old_big_game_does_not_dominate():
    rising = _msgs(1, [1, 2, 3, 4, 5, 6, 7, 8] + [40, 41])            # 8 recent, 2 baseline
    declining = _msgs(2, [1, 2] + list(range(35, 55)))                # 2 recent, 20 baseline
    old_big = _msgs(3, list(range(90, 200)) + [1])                    # huge history, almost nothing recent
    out = compute_trend_scores(pd.concat([rising, declining, old_big]), as_of=NOW)
    assert out.loc[1, "status"] == "rising" and out.loc[2, "status"] == "declining"
    assert out.loc[1, "trend_score"] > out.loc[3, "trend_score"]
    assert ((out["trend_score"] >= 0) & (out["trend_score"] <= 1)).all()


def test_insufficient_data_status_and_empty_input():
    out = compute_trend_scores(_msgs(1, [1, 2]), as_of=NOW)
    assert out.loc[1, "status"] == "insufficient data"
    assert compute_trend_scores(pd.DataFrame(columns=["game_id", "created_at", "engagement"])).empty


def test_timelines():
    df = _msgs(1, [1, 2, 10, 20])
    assert volume_timeline(df)["n_messages"].sum() == 4
    assert volume_timeline(df, game_id=99).empty
    sent = df.assign(score=[0.5, 0.5, -0.5, -0.5])
    assert len(mean_timeline(sent, "score")) >= 1 and mean_timeline(sent.iloc[0:0], "score").empty


def test_community_score_weights_and_missing_components():
    comp = pd.DataFrame({"sentiment": [1.0, 0.0], "consistency": [1.0, 0.0], "volume": [1.0, 0.0],
                         "trend": [1.0, 0.0], "aspect": [np.nan, np.nan], "engagement": [1.0, 0.0]})
    s = compute_community_scores(comp)
    assert s.iloc[0] == pytest.approx(1.0) and s.iloc[1] == pytest.approx(0.0)  # aspect missing -> renormalized
    assert sum(DEFAULT_WEIGHTS.values()) == pytest.approx(1.0)
    custom = compute_community_scores(comp.assign(aspect=0.5), {"sentiment": 1.0, "consistency": 0, "volume": 0,
                                                                "trend": 0, "aspect": 0, "engagement": 0})
    assert custom.iloc[0] == pytest.approx(1.0)


def test_shrink_pulls_small_samples_to_prior():
    few = shrink(pd.Series([2.0]), pd.Series([2]), prior=0.0, k=10).iloc[0]
    many = shrink(pd.Series([200.0]), pd.Series([200]), prior=0.0, k=10).iloc[0]
    assert few < 0.2 < many


@pytest.fixture()
def db():
    engine = create_engine("sqlite://")
    Base.metadata.create_all(engine)
    with sessionmaker(bind=engine)() as s:
        load_source(s, get_source("demo"))
        yield s


def test_scores_require_sentiment_first(db):
    with pytest.raises(ValueError):
        compute_and_store_scores(db)


def test_full_score_pipeline(db):
    analyze_messages(db, VaderModel())
    analyze_aspects(db, VaderModel())
    df = compute_and_store_scores(db)
    assert len(df) == 24 and df["community_score"].between(0, 1).all()
    assert df["confidence"].between(0, 1).all() and set(df["status"]) <= {"rising", "stable", "declining", "insufficient data"}
    assert len(latest_scores(db)) == 24
    assert not message_volume_timeline(db).empty and not sentiment_timeline(db).empty
    assert genre_popularity(db)["n_messages"].iloc[0] > 0


def test_scores_work_without_aspects(db):
    analyze_messages(db, VaderModel())
    assert compute_and_store_scores(db)["community_score"].notna().all()
