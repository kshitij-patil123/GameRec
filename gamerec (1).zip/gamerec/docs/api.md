# GameRec REST API (Phase 11)

Interactive docs: `http://localhost:8000/docs` (OpenAPI). All responses are JSON. The recommender is built lazily on first use and cached; `POST /system/refresh` (admin token) rebuilds it after a pipeline run.

| Method | Path | Notes |
|---|---|---|
| GET | `/health`, `/meta` | `/meta`: loaded data source types, `is_demo`, banner text, pipeline step flags |
| GET | `/games` | `q, genre, platform, min_rating, sort (name/rating/release_date/community_score/trend_score), order, limit (1-100), offset` |
| GET | `/games/search?q=` | autocomplete, prefix matches first |
| GET | `/games/filters` | genres, platforms, tags, aspects, sort options |
| GET | `/games/{id}` | summary incl. community/trend scores |
| GET | `/games/{id}/similar` | content similarity + shared genres/tags |
| GET | `/games/{id}/community-analysis` | sentiment, aspects, keywords, topics, weekly timeline, score components. Aggregates only |
| GET | `/trending/games`, `/trending/topics` | trend score order; topics by change in share |
| GET | `/analytics/overview, sentiment, topics, aspects, keywords, activity` | `aspects?game_id=` for one game |
| GET/POST | `/users` | list / create profile (`display_name`) |
| POST | `/users/{id}/ratings` | `{game_id, rating 1-5 and/or interaction}`; upsert per user+game |
| POST | `/users/{id}/preferences` | `{genres, tags, favorite_game_ids, aspects{aspect: 0-1}}`; provided fields replace, omitted unchanged |
| GET | `/users/{id}/profile` | ratings, liked games, preference profile, last 3 recommendation batches |
| GET | `/recommendations/{id}` | `n (1-50), weights (JSON), save (history)`; items carry score, match_percent, components, contributions, reasons, strategy |
| GET | `/recommendations/{id}/explain/{game_id}` | explanation + rank for any unseen game; 409 if already rated |
| POST | `/system/refresh` | header `X-Admin-Token`; disabled unless `ADMIN_TOKEN` is set |

## Errors
- `404` unknown user/game, `409` explaining an already-rated game, `422` validation (`{"detail": "Validation failed", "errors": [{field, message}]}`), `503` pipeline has not been run (no games), `500` generic message only (details are logged server-side).
- Request bodies reject unknown fields; list endpoints cap `limit`; search text is escaped (a `%` is not a wildcard).

## Security and privacy notes
- CORS: only origins in `CORS_ORIGINS`; methods GET/POST. No secrets in code; `.env` only.
- Raw messages and author identifiers are never returned, only aggregates. Discord author IDs are hashed on ingestion.
- **No authentication yet**: profiles are open by ID, which is acceptable for a local demo but not for deployment. Adding login would mean password hashing (`users.password_hash` already exists) plus tokens; listed under future scope.
- `match_percent` in recommendations is relative to the candidate pool, not a probability (the response says so in `note`).
