# GameRec data dictionary (standard schema)

Any dataset can be plugged in by mapping it to these three tables (`genre`/`tags` use `|` as separator).

| Table | Column | Required | Notes |
|---|---|---|---|
| games | game_id, game_name | yes | |
| games | description, genre, tags, platform, developer, publisher, release_date, rating | no | |
| messages | message_id, text, timestamp | yes | ISO 8601 timestamps |
| messages | game_id, user_id, engagement | no | If `game_id` is empty, the loader links by unambiguous game-name mention |
| ratings | user_id, game_id | yes | |
| ratings | rating (1-5), interaction (rated/liked/disliked/played), timestamp | no | |

## Data source types (stored on every message)
- `live`: legitimately obtained (own test server, permitted bot). Author IDs are salted+hashed on load.
- `public`: public/academic datasets converted to the schema above (`data/raw/`).
- `synthetic`: generated demo data. Fictional games, template messages. Not real.

## Demo data
`scripts/generate_demo_data.py` writes `data/sample/*.csv` (seeded). The extra `demo_label` / `demo_aspect`
columns in `messages.csv` are the template's intended labels, only for smoke tests, not for reporting accuracy.

## Discord export format (`data/raw/discord_export.json`)
`[{"id": "...", "author_id": "...", "content": "...", "timestamp": "...", "reactions": 3, "game_id": 1}]`
Only export from servers you own or have explicit permission to use.
