# Dataset strategy

GameRec reads **three standard tables** (games, community messages, ratings), so any dataset can be used by mapping it to the schema in [`data_dictionary.md`](data_dictionary.md). Three kinds of data are kept strictly apart; every message row stores its `source_type`, and the UI shows a banner whenever only synthetic data is loaded.

| Kind | `source_type` | Where it lives | Use it for |
|---|---|---|---|
| Legitimately obtained live data | `live` | `data/raw/discord_export.json` | Your own test server, or a server where the owner gave written permission |
| Public / academic datasets | `public` | `data/raw/{games,messages,ratings}.csv` | The evaluation you report |
| Synthetic demo data | `synthetic` | `data/sample/` | Development, demos, tests. **Never** as evidence |

## Recommended starting points (verify terms before use)
No dataset below ships with the project and none has been downloaded or checked here. Read each one's license and terms of use, and cite it in the report.
- **Game metadata and reviews:** public Steam game and review datasets published by academic groups or on Kaggle. They usually have metadata, review text and a thumbs-up/thumbs-down flag, but **no star ratings**: say explicitly how you map the flag to ratings (for example recommended = 5, not recommended = 1) and treat it as implicit feedback.
- **Discussion text:** a Discord export from a server you control (a test server your team runs is enough), collected through a bot you added with permission. Do not scrape servers you do not own or have not been authorized to read.
- **Ratings:** reviews with an author id give user-game interactions; a review dataset can therefore supply both the community text and the ratings.
- For the project's central claim (community text helps recommendations) the text and the ratings must be about **the same games**, and the catalog should be much larger than K.

## Mapping a dataset (checklist)
1. Games to `games.csv` (`game_id`, `game_name`, genres and tags joined with `|`).
2. Review/message text to `messages.csv` (`message_id`, `game_id` if known, `user_id`, `text`, ISO `timestamp`, optional `engagement` such as helpful votes).
3. Feedback to `ratings.csv` (`user_id`, `game_id`, `rating` 1-5 and/or `interaction`).
4. Put the files in `data/raw/`, set `DATA_SOURCE=public`, run `python scripts/run_pipeline.py public`.
5. For a Discord export use `DATA_SOURCE=discord_export` (see the format in the data dictionary). Author IDs are salted and hashed on load; set `USER_HASH_SALT`.

## Sample records (synthetic, from `data/sample/`)
```csv
game_id,game_name,genre,tags,platform,release_date,rating
1,Ashen Crown,RPG|Action,open world|story rich|dark fantasy,PC|PS5,2024-06-01,4.3

message_id,game_id,user_id,text,timestamp,engagement
demo-2,1,u47,100% recommend Ashen Crown just for the story tbh,2026-05-26T03:47:55,18

user_id,game_id,rating,interaction,timestamp
u1,7,4,liked,2026-06-10T00:00:00
```
The demo games and messages are fictional and template-generated; the extra `demo_label` / `demo_aspect` columns in `messages.csv` exist only for smoke tests.

## Train / validation / test strategy
Per-user chronological split: the earliest 60% of each user's ratings train the models, the next 20% tune the hybrid weights, the last 20% are the test set. Users need at least 5 ratings. A game is relevant if its held-out rating is at least 4. Full protocol and the safeguards against leakage: [`evaluation.md`](evaluation.md).
For the sentiment model, hand-label 300 to 500 real messages (positive / neutral / negative), keep two annotators if possible and report their agreement, then run `ml/evaluation/eval_sentiment.py` (stratified 80/20 split, seed 42).
