# Evaluation (Phase 14)

**Status: real-data results are pending execution.** Everything below is implemented and tested; the only run so far used the synthetic demo data and is a code check, not a finding.

```bash
python scripts/run_pipeline.py <source>          # load + analyze your data
python ml/evaluation/run_evaluation.py --k 5 10  # writes data/processed/evaluation/{eval_results.json, evaluation_report.md}
```
Library code: `backend/app/evaluation/` (metrics, splits, experiments, report), tested in `backend/tests/test_evaluation.py`.

## Protocol
- **Split:** per-user chronological, 60% train / 20% validation / 20% test (users need >= 5 ratings). It mimics "predict what the user rates next" and avoids training on the future.
- **Relevant item:** a held-out game rated >= 4. **Candidates:** every game the user has not rated (items rated later are removed from the pool during validation). Unrated games count as non-relevant, which understates precision for all models equally.
- **Metrics @K:** Precision (hits/K), Recall, F1, NDCG (binary gain), hit rate. Users with no relevant held-out item are skipped and counted.
- **No leakage:** CF is refit on train for tuning and on train+validation for the test; weights are tuned on validation only; the test split is scored once per model. Community data comes from messages, which are independent of ratings.
- **Statistics:** 95% bootstrap CIs over users, and **paired** bootstrap differences between models on the same users. A difference counts only if its CI excludes 0 (the report's "Reliable?" column is judged on NDCG).

## Models compared
Random, Popularity (baselines); **A** content-only; **B** collaborative-only; **C** content + collaborative; hybrid without community signals; **D** full hybrid (default weights); **D\*** full hybrid with weights tuned on validation (random search over 60 weight vectors plus the default and single-component vectors; ties keep the default). The key question for the project is **D vs hybrid-without-community**: does community analysis improve recommendations?

**Cold-start experiment:** each user is given only their first 2 ratings (CF is off), and the rest are ranked, comparing content-only, community+trend only, hybrid without community, the full hybrid, and baselines.

## How the harness itself was validated
- Metric functions are checked against hand-computed values.
- **Positive control:** on ratings generated from genre affinity, content, CF and the hybrid all beat random by a clear margin.
- **Null control:** on pure-noise ratings, no model differs from random beyond noise, which would not hold if the pipeline leaked test information.
- Split tests assert no history/future/test items ever appear in each other's candidate sets.

## The synthetic smoke run (do not cite)
24 test users and a ~17-game candidate pool: no paired NDCG difference had a CI excluding 0, and several models were no better than Random or Popularity. The demo ratings were generated from user genre affinity alone, so this data cannot test whether community text helps. The tuned weights it produced fit validation noise. The report carries a banner for synthetic data.

## What real evaluation needs
- Ratings (or reliable implicit feedback) and community text for the **same games**, a few hundred users or more, and a catalog much larger than K (the report warns when the pool is under 2K).
- Mapping into the standard schema (see `docs/data_dictionary.md`); candidate sources to review for license and terms before use: public Steam review/metadata datasets from academic groups or Kaggle, and a Discord export from a server you own or have written permission to use. Steam "recommended" flags are thumbs up/down, not stars, so state how you mapped them to ratings.
- Report the table with CIs and the paired differences, including cases where the hybrid does not win.

## Sentiment model evaluation
Unchanged from Phase 4: `ml/evaluation/eval_sentiment.py` on a human-labeled set. **Pending execution.**
