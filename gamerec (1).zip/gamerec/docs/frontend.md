# Frontend (Phase 12)

React 19 + Vite + Tailwind CSS 4 + React Router; charts with Plotly (`plotly.js-basic-dist-min`, lazy-loaded in its own chunk so the app shell stays small). Config: `frontend/.env` (`VITE_API_URL`, default `http://localhost:8000`).

```bash
cd frontend && npm install
npm run dev        # http://localhost:5173  (backend must be running)
npm test           # vitest: API client, shared components, page behavior (mocked API)
GAMEREC_LIVE=1 npx vitest run src/integration.test.js   # same flows against a live backend
npm run build
```

## Pages and the data behind them
| Page | Route | Shows | API |
|---|---|---|---|
| Home dashboard | `/` | counts, personal picks, trending games chart, sentiment donut, trending topics, popular genres | `/analytics/overview`, `/recommendations/{id}` |
| Game explorer | `/games` | debounced search, genre/platform/rating filters, sorting, pagination | `/games`, `/games/filters` |
| Game details | `/games/:id` | scores, aspect sentiment chart, weekly volume + sentiment trend, keywords, topics, similar games, personal "why" explanation, rate widget | `/games/{id}`, `/community-analysis`, `/similar`, `/recommendations/{id}/explain/{game}` |
| For you | `/for-you` | ranked recommendations with match %, score-breakdown bars, reasons (✓ supports, ! caveat), comparison chart, adjustable model weights, rate / "Not for me" | `/recommendations/{id}` |
| Community analytics | `/community` | sentiment distribution and over time, topics and topic trends, keywords and emerging keywords, aspect sentiment, activity, trending games | `/analytics/*`, `/trending/*` |
| Profile | `/profile` | create profile, genres/tags/aspect importance, quick rating search, preference profile chart, liked games, ratings, recommendation history | `/users/*` |

Charts (all Plotly): sentiment distribution, sentiment timeline, top games by activity, trending games, trending topics, keyword frequency, aspect sentiment, genre popularity, recommendation comparison, user preference profile.

## The demo flow, step by step
1. Open the app: the amber banner says when data is synthetic (from `/meta`).
2. **Profile** page: create a profile (or pick one from the menu).
3. Pick favorite genres/tags and aspect importance; **Save preferences**.
4. **Rate games** with the quick search (three ratings switch on full personalization).
5. The preference profile chart updates; the profile shows cold start vs personalized.
6. **Home** and **Community** show sentiment, topics, trends, activity.
7. **For you** generates explained recommendations (saved to history).
8. Open a recommended game: similarity, community sentiment, aspects, trend, personal explanation.
9. Rate it (stars or "Not for me"): the list refreshes using the new rating, no restart or rebuild.
10. Use **Model weights** to switch signals on/off and watch rankings change (a live mini-ablation).

## Design notes
- Every request goes through one client (`services/api.js`) that turns validation errors into readable messages and explains an unreachable API; pages share `Async` for loading / error / retry; a 503 tells the user to run the pipeline.
- The selected profile is stored in `localStorage` (guarded; falls back to memory). There is no login yet, see `docs/api.md`.
- `match %` is labeled as relative to other candidates, not a probability.

## What has and has not been checked
Verified: production build, 19 unit/behavior tests (mocked API), and a live run of the real API client against the running backend (create profile, preferences, cold-start recommendations, rate, refreshed list, history, 409 and 422 handling).
**Not verified: how pages look in a real browser** (layout, chart appearance, responsiveness). No browser was available in the build environment, so check the screens yourself and screenshot them for the report.
