# Integration and deployment (Phase 13)

## Run it locally without Docker
```bash
cp .env.example .env
python scripts/run_pipeline.py demo
cd backend && uvicorn app.main:app --reload      # http://localhost:8000/docs
cd ../frontend && npm install && npm run dev      # http://localhost:5173
```
Leave `DATABASE_URL` as in `.env.example` for PostgreSQL, or unset it for a local SQLite file.

## Docker
`docker compose up --build` starts PostgreSQL 16, the API (its start-up script creates tables and, only if the database is empty, loads and analyzes the configured data source) and the web app (nginx serving the built frontend) at http://localhost:8080. Postgres is published on localhost only. Passwords come from `.env`, never from code. The API container runs as a non-root user.

## What was verified, and how
| Check | Result |
|---|---|
| Backend test suite (SQLite) | 117 passing |
| Full pipeline on **PostgreSQL 16** | loads, analyzes, scores |
| API tests + 12-step demo flow on **PostgreSQL 16** | 30 passing |
| Frontend unit/behavior tests, production build | passing |
| Real frontend API client against the running backend | passing |
| Start-up script on an empty then populated database | loads once, then skips |

PostgreSQL was exercised with an embedded Postgres 16 (pip `pgserver`), not Docker. **Not verified here:** `docker compose up --build` itself (no Docker in the build environment), and the pages in a real browser. Try the compose stack once and fix any environment-specific issue before the demo.

To run the API tests against your own Postgres: `GAMEREC_TEST_DB_URL=postgresql+psycopg2://user:pass@localhost/gamerec_test pytest backend/tests/test_api.py` (the schema in that database is dropped and recreated, so use a throwaway database).
