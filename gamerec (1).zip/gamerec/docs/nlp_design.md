# NLP design notes (Phases 3-4)

## Why two text views?
| View | Used by | Keeps | Removes |
|---|---|---|---|
| `text_original` (light) | VADER, transformer | case, punctuation, emoji, negations | URLs, Discord mentions, extra whitespace |
| `text_clean` (aggressive) | TF-IDF, topics, keywords | content words, negations | stopwords, punctuation, emoji, slang forms; lemmatized |

VADER and transformers use capitalization, "!!!", emoticons and word order as signals, so heavy cleaning
would hurt them. Bag-of-words models benefit from a smaller, normalized vocabulary. Negations
("not", "never") are deliberately excluded from stopword removal.

## Duplicates and invalid rows
`preprocess_frame` never drops rows; it adds `is_valid` and `is_duplicate` flags. Sentiment skips invalid and
duplicate (same game + cleaned text) messages so spam does not skew per-game stats. The demo data is
template-based, so it contains many exact repeats and a large share is skipped; real data will not behave this way.

## Models
1. VADER: lexicon baseline, no training.
2. TF-IDF (1-2 grams) + Logistic Regression (balanced class weights): supervised baseline, needs labels.
3. Transformer (`cardiffnlp/twitter-roberta-base-sentiment-latest`): optional, trained on social-media text.
   Requires `requirements-transformer.txt` and internet for weights. Not run in this build.

## Evaluation methodology
`ml/evaluation/eval_sentiment.py`: stratified 80/20 split, seed 42, all models scored on the same test split.
Reports accuracy, macro precision/recall/F1, per-class report, confusion matrix -> `data/processed/sentiment_eval.json`.

**Results: pending execution on a human-labeled dataset.** Label ~300-500 real messages by hand (or use a public
labeled dataset such as a Steam-review set mapped to pos/neu/neg) and pass it with `--labels`.
The synthetic demo labels are template-generated: metrics on them are only a smoke test of the code.

## Per-game sentiment
`game_sentiment_stats` returns positive/neutral/negative % and average score (p_pos - p_neg, or VADER compound).
