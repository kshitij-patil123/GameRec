# Collaborative filtering, user profile, hybrid engine (Phases 9-10)

## Collaborative filtering (`recommender/collaborative.py`)
Item-item CF on mean-centered ratings.
- **Similarity:** cosine between item columns of the user-centered rating matrix, shrunk by co-rating count (`sim * n/(n+3)`) so a pair rated together by one user is not "perfectly similar".
- **Prediction:** `mean_u + sum(sim * (r_j - mean_u)) / sum(|sim|)` over the 20 most similar rated items, clipped to 1-5. `mean_u` is shrunk toward the global mean (m = 2); plain centering made one-rating users carry no signal, which a test caught.
- **Input is the user's ratings, not a matrix row**, so a user who just rated a game gets updated predictions without refitting.
- Ratings missing but interaction known: liked 4.5, disliked 1.5, played 3.5 (implicit mapping).
- **Cold start:** no ratings, or fewer than 3, means no CF component; unseen items with no co-ratings get no prediction.
- Dense item x item matrix: fine for thousands of items; use sparse neighbor lists beyond that.

## User profile (`recommender/profile.py`)
Built from ratings, stated genres/tags, favorite games and optional aspect sliders.
- Preference weight per game = rating - 3 (favorites count as 5 stars); genre/tag weights are sums over those games plus stated picks, scaled to [-1, 1] (poorly rated games give negative weight).
- Aspect priorities (0-1): inferred from liked games as `weight * attention * max(aspect sentiment, 0)`, where attention is the share of that game's aspect talk. Only praised aspects count, so a liked game with many bug complaints does not make "bugs" a priority. If the user sets any aspect slider, only the stated aspects are used (stated priorities are authoritative); inference applies only when none are set.

## Hybrid engine (`recommender/hybrid.py`)
`final = sum(w_c * norm_c) / sum(w_c)` over available components with `w_c > 0`.

| Component | Default weight | Source |
|---|---|---|
| content | 0.30 | cosine to the user's content profile and/or stated genres/tags |
| collaborative | 0.25 | item-item predicted rating |
| preference | 0.15 | genre/tag match with the profile |
| community | 0.15 | shrunk community sentiment |
| trend | 0.10 | trend score |
| aspect | 0.05 | sum of pref_a * aspect sentiment (0-1) / sum of pref_a |

- Every component is **min-max normalized across the candidate games**; games missing a component get the neutral 0.5.
- Weights are configurable per call and validated (non-negative, not all zero). A weight of 0 turns a component off, which is how the Phase 14 ablation runs (content-only, CF-only, content + CF, full hybrid).
- Weights are **starting values, not tuned**. Phase 14 will tune them on a validation split (grid or random search maximizing NDCG@10), then report the chosen weights on the held-out test split only.
- `match_percent` = final score x 100. Because components are normalized within the candidate pool, it is a **relative score**, not a probability that the user will like the game: the top candidate is often near 100% by construction.

### Cold start (automatic)
| Situation | Strategy | What runs |
|---|---|---|
| No ratings, no preferences | `popular_trending` | community + trend only |
| Stated genres/tags/favorites, < 3 ratings | `cold_start_preferences` | content (from stated prefs), preference, community, trend, aspect |
| >= 3 ratings | `hybrid` | all six components |
| New game | metadata | content vector from genre/tags/description; community terms join once enough messages exist |

## Explanations (`recommender/explain.py`)
Reasons are generated only when a statistic supports them (thresholds are constants): content similarity >= 0.20 with a liked game (named), genre/tag overlap, CF prediction >= 3.8 (names a liked neighbor game), community sentiment >= 0.60 with confidence >= 0.5, aspects the user cares about with sentiment >= 0.2, and rising trend. **Caveats** are shown too (low community confidence, negative sentiment on a priority aspect, declining discussion). If nothing qualifies, the reason says so instead of inventing one. The response also carries per-component contributions for the recommendation-comparison chart.

## Evidence so far
Real-data recommendation quality: **pending execution** (Phase 14 computes Precision@K, Recall@K, NDCG@K for content, CF and hybrid, plus the ablation). The only checks so far are unit/integration tests on toy and synthetic demo data; those show the code behaves as designed, not that the recommendations are good.
