---
title: "GameRec: An NLP-Based Discord Gaming Community Analysis and Hybrid Personalized Game Recommendation System"
subtitle: "Mini-project report: Text / Web / Social Media Analysis and Recommendation Systems"
author: "[Team member names and roll numbers]  |  Guide: [name]  |  [Department, Institute]  |  [Academic year]"
---

# Abstract {.unnumbered}

Game recommenders usually rely on ratings and metadata, even though gaming communities produce large amounts of opinion text about what is good, what is broken and what is currently popular. GameRec is a community-aware recommendation system that mines such text and combines it with user preferences. It ingests games, community messages and ratings through an interchangeable, privacy-respecting layer; cleans text into two views; extracts sentiment, keywords, topics, aspect-level sentiment and trends; derives a project-defined Community Intelligence Score; builds a user preference profile; and ranks games with an interpretable weighted hybrid of content similarity, item-item collaborative filtering, preference match, community sentiment, trend and aspect match. Every recommendation is explained using only statistics that support each statement, with caveats shown. The system is delivered as a FastAPI backend, a PostgreSQL schema of 16 tables and a React dashboard, with an evaluation harness reporting Precision, Recall, F1 and NDCG at K against baselines and ablations with bootstrap confidence intervals. The implementation was verified with 135 backend and 19 frontend automated tests. **Evaluation on real data has not yet been run; results are marked "Result pending execution", and only synthetic demo data was used to test the code.**

**Keywords:** recommender systems, hybrid recommendation, sentiment analysis, aspect-based sentiment analysis, topic modeling, explainable recommendation, cold start, social media text.

# Introduction

Online gaming communities on platforms such as Discord discuss games continuously: what is fun, which update broke performance, which game is rising. This text is a signal about both the games and the community's attitude to specific aspects such as story, combat or multiplayer. Recommendation systems, meanwhile, are typically built from user-item ratings and item metadata. GameRec combines the two subjects of this course: text and social media analysis (to understand the community) and recommendation systems (to personalize and rank).

# Problem Statement

Given game metadata, community text and user ratings, produce a personalized ranked list of games for a user, together with a human-readable explanation, such that community information (sentiment, aspects, trends) is used and its contribution can be measured. The system must work for new users and new games, must not depend on unauthorized data collection, and must not present synthetic data as real.

# Motivation

1. Ratings alone say little about *why* a game is liked; community text carries aspect-level opinion.
2. A highly similar game may be currently disliked or declining; trends and sentiment add context.
3. Users trust recommendations they can inspect; explanations and honest caveats support that.
4. New users and new games have no rating history; text and metadata can help.
5. The project allows a defensible experiment: does adding community analysis improve recommendations?

# Objectives

1. Build an interchangeable ingestion layer with labeled real, public and synthetic data.
2. Implement preprocessing, sentiment analysis, keyword extraction, topic modeling, aspect-based sentiment and trend analysis.
3. Define a transparent Community Intelligence Score.
4. Implement a user profile, content-based, collaborative and hybrid recommenders with cold-start handling.
5. Explain each recommendation.
6. Provide a REST API, a dashboard and an evaluation harness that does not fabricate results.

# Existing System

Typical game storefront and community recommenders rely mainly on purchase, playtime or rating behaviour, popularity, and genre/tag metadata. Community text, when used at all, tends to be reduced to a single review score. Such systems generally give little aspect-level information, do not separate "similar" from "currently well received", and offer limited explanation. (This is a general characterization of the approach; the report does not make claims about the internals of any specific commercial service.)

# Proposed System

GameRec adds a community-intelligence layer between raw text and the recommender (Figure 1). Text is analysed for sentiment, topics, keywords, aspect sentiment and trends; these become per-game features (community sentiment, aspect profile, trend score) that enter the ranking alongside content similarity, collaborative filtering and the user's preferences.

![Figure 1. System architecture.](../diagrams/architecture.png){width=6.3in}

# Literature Review

> *Note to authors: the works below are well-known foundations, listed to anchor the methods used. Check volume, page and venue details against the originals before submission, and extend this section with 5 to 10 recent papers on game recommendation and review analysis found through a scholarly search.*

**Sentiment analysis.** Liu (2012) surveys sentiment analysis and opinion mining. VADER (Hutto and Gilbert, 2014) is a rule- and lexicon-based model designed for social media text and is used here as a transparent baseline. Pretrained transformer language models (Devlin et al., 2019; Liu et al., 2019) fine-tuned on social media benchmarks such as TweetEval (Barbieri et al., 2020) are the stronger option for informal text, and are supported here as an optional model.

**Keyword extraction and topics.** TF-IDF term weighting (Salton and Buckley, 1988) underlies keyword extraction and the content features. Latent Dirichlet Allocation (Blei et al., 2003) and non-negative matrix factorization (Lee and Seung, 1999) discover topics from word co-occurrence; this project uses NMF on TF-IDF and the UMass coherence measure (Mimno et al., 2011) as a heuristic for choosing the number of topics.

**Aspect-based sentiment.** Aspect-based sentiment analysis was formalized in shared tasks such as SemEval-2014 Task 4 (Pontiki et al., 2014): detect aspects of an entity and the sentiment toward each. GameRec uses a lightweight rule-based variant and names fine-tuned ABSA models as future work.

**Recommender systems.** Collaborative filtering goes back to GroupLens (Resnick et al., 1994); item-based methods (Sarwar et al., 2001) scale well and are used here. Matrix factorization (Koren et al., 2009) is a stronger family left for future work. Hybrid recommenders combine techniques to offset individual weaknesses (Burke, 2002). Cold-start methods are studied by Schein et al. (2002).

**Explanation and evaluation.** Explanations improve users' ability to judge recommendations (Herlocker et al., 2000). Evaluation practice for recommenders, including offline metrics and their pitfalls, is covered by Herlocker et al. (2004); NDCG comes from Järvelin and Kekäläinen (2002).

**Gap addressed.** Work on game recommendation typically uses ratings, playtime or metadata. GameRec's contribution is an engineered, explainable pipeline that feeds community sentiment, aspects and trends into the ranking and an evaluation design that isolates their effect.

# Methodology

The method follows the pipeline in Figure 1; the data flow is in Figure 2.

![Figure 2. Data flow.](../diagrams/data_flow.png){width=6.3in}

## Data and ingestion

Three standard tables (games, community messages, ratings) are produced by interchangeable sources. Each message stores `source_type` as `live` (legitimately obtained, such as an export from a server the team owns), `public` (public or academic datasets) or `synthetic` (demo data); the interface shows a banner whenever only synthetic data is loaded. Discord author IDs are salted and hashed on load, and the API never returns raw message text or author identifiers. A seeded generator provides fictional demo data so that the full system runs without external services; it is not real data.

## Preprocessing

Two views of each message are kept. The **light view** replaces URLs and mentions but keeps case, punctuation, emoji and negations, because VADER and transformers use them ("AMAZING!!!", "not good"). The **cleaned view** lowercases, expands contractions, maps common emoji and slang to words, removes stopwords **except negations**, and lemmatizes; it feeds TF-IDF, topics and keywords. Empty, emoji-only and duplicate messages are flagged rather than silently dropped, and excluded from per-game statistics.

## System architecture and components

The backend is organized as ingestion, NLP, analytics, recommender, services and API layers; the main classes are shown in Figure 3.

![Figure 3. Main classes.](../diagrams/class_diagram.png){width=6.3in}

## Database design

PostgreSQL stores 16 normalized tables with primary keys, foreign keys with cascading deletes, unique and check constraints and indexes (Figures 4 and 5). The diagrams are generated from the SQLAlchemy models by `scripts/generate_er_diagram.py`, so they match the implementation; a single full-schema diagram is in `docs/diagrams/er_diagram.png`.

![Figure 4. ER diagram, part 1: games, users, ratings, preferences, scores and recommendations.](../diagrams/er_core.png){width=6.5in}

![Figure 5. ER diagram, part 2: text analytics tables (messages, sentiment, aspects, topics).](../diagrams/er_text.png){width=5.2in}

# NLP Methodology

## Sentiment analysis

Messages are classified as positive, neutral or negative. Three models share one interface: VADER (lexicon baseline, compound score thresholds of plus or minus 0.05), TF-IDF with Logistic Regression (supervised baseline trained on labeled data, balanced class weights), and an optional transformer (`cardiffnlp/twitter-roberta-base-sentiment-latest`, trained on social media text; **not run in the development environment because model weights could not be downloaded**). Per game the system stores the positive, neutral and negative percentages and the mean score. The evaluation protocol (Section 12) uses a stratified 80/20 split and reports accuracy, macro precision, recall, F1 and the confusion matrix; **sentiment accuracy is pending execution because it needs a human-labeled set**.

## Keyword extraction

Top keywords use mean TF-IDF over unigrams and bigrams. Game- and genre-specific keywords merge each group's messages into one document so TF-IDF rewards group-distinctive terms (game names are excluded). Emerging keywords compare a term's share of messages in the last 30 days with the previous 60 days, with smoothing and a minimum count. Opinion words and negations are removed for keywords and topics, because they describe how people feel rather than what they discuss.

## Topic modeling

Topics are learned with NMF on TF-IDF (default 8 topics). They are discovered from the data; a seed list of themes (story, combat, multiplayer, ...) is used only to label discovered topics for readability. The system reports topic frequency, representative keywords, games associated with each topic and topic share over time. UMass coherence can suggest the number of topics but favors small values and is only a hint.

## Aspect-based sentiment analysis

Messages are split into clauses at sentence punctuation and contrast words (but, however, although). A lexicon over ten aspects (story, graphics, combat, difficulty, performance, multiplayer, music, price, bugs, exploration) detects aspects in each clause; the clause is scored with the sentiment model; each aspect in it receives that score. Neutral aspect nouns are masked before scoring, because a lexicon scorer treats words such as "combat" as negative; sentiment-bearing terms ("expensive", "buggy") stay visible. A game's aspect label is Positive, Negative, Mixed, Neutral or Insufficient data from the mean score and the positive and negative shares. For recommendation, a game-by-aspect matrix of shrunk mean sentiment is used: $(\sum s + k\,\mu_a)/(n + k)$ with $k=5$, so a handful of mentions cannot create an extreme score. Limitations: fixed aspect list, one score per clause, no sarcasm handling.

## Trend analysis and Community Intelligence Score

For each game, with recent window $R$ (28 days) and baseline window $B$ (the 56 days before it), $r$ and $b$ the message counts in each, and pseudo-count $a=3$:

$$g = \frac{r + a}{b\,R/B + a}, \qquad \text{growth score} = \frac{g}{1+g}$$

The trend score is $0.4\cdot\text{volume} + 0.4\cdot\text{growth} + 0.2\cdot\text{engagement}$, where volume is the min-max scaled $\log(1+r)$ across games and engagement the min-max scaled mean engagement of recent messages. Only recent volume enters, and growth compares a game with its own history, so games with a large past archive do not dominate. Status is rising (g at least 1.25), declining (at most 0.8), stable, or insufficient data.

The **Community Intelligence Score** is a project-defined metric, not an objective measure of quality. It is the weighted mean of six components scaled to [0, 1]: shrunk sentiment (0.35), consistency, one minus the standard deviation of message sentiment (0.10), volume (0.15), trend (0.20), aspect sentiment (0.15) and engagement (0.05); missing components are dropped and weights renormalized. Each game also stores a confidence $n/(n+10)$ showing how much data supports the score.

# Recommendation Algorithms

## User profile

A profile is built from ratings, stated genres and tags, favorite games and optional aspect sliders. A game's preference weight is its rating minus 3 (so a low rating pushes the profile away), and favorites count as 5 stars. Genre and tag weights are the weight sums scaled to [-1, 1]. Aspect priorities are the stated sliders when any are set; otherwise they are inferred from liked games as the sum of weight times attention (the share of the game's aspect talk) times the positive part of the game's aspect sentiment, so complaints do not become priorities.

## Content-based recommendation

Each game is four TF-IDF blocks: genres (0.30), tags (0.30), description (0.25) and community keywords (0.15), each L2-normalized and scaled by the square root of its weight, so a dot product is the weighted mean of block cosines. Similar games are ranked by cosine; a user profile vector is the weighted sum of rated games' vectors.

## Collaborative filtering

Item-item filtering on user-mean-centered ratings: cosine between item columns, shrunk by co-rating count ($\text{sim}\cdot n/(n+3)$). A prediction is the user's mean plus the similarity-weighted deviation over the 20 most similar rated items, clipped to 1 to 5. The user's mean is shrunk toward the global mean so a user with one rating still carries signal. Predictions are computed from the user's ratings directly, so a new rating takes effect without refitting.

## Hybrid recommendation

![Figure 6. Recommendation request.](../diagrams/sequence_recommendation.png){width=6in}

For user $u$ and candidate game $g$, six component scores are computed, each min-max normalized to $\hat{x}_c \in [0,1]$ over the candidate set:

$$S(u,g) = \frac{\sum_{c} w_c\,\hat{x}_c(u,g)}{\sum_{c} w_c}$$

| Component $c$ | Default weight $w_c$ |
|---|---|
| Content similarity | 0.30 |
| Collaborative score | 0.25 |
| User preference match | 0.15 |
| Community sentiment | 0.15 |
| Trend score | 0.10 |
| Aspect match | 0.05 |

The weights are configurable per request and are **starting values, not fixed truths**. Components that are unavailable for a user (for example collaborative filtering with fewer than three ratings) are dropped and the remaining weights renormalized. The weights are to be tuned on a validation split (Section 12); until then the defaults are untuned. The reported match percentage is the final score times 100 and is **relative to the other candidates, not a probability**.

## Explainable recommendations

Reasons are produced only when a statistic supports them, for example content similarity of at least 0.20 to a liked game (named), genre or tag overlap with the profile, a collaborative prediction of at least 3.8 with a liked neighbor game, community sentiment of at least 0.60 with enough data, high aspect sentiment on aspects the user prioritizes, or a rising trend. **Caveats** are shown too: limited community data, negative sentiment on a prioritized aspect, declining activity. If nothing qualifies the explanation says so. A stacked bar shows each component's contribution to the score.

## Cold start

| Situation | Behavior |
|---|---|
| New user with stated preferences | content from stated genres/tags/favorites, preference match, community, trend, aspect |
| New user with nothing | popular and trending (community and trend only); if even those are unavailable, catalog rating |
| New game | content vector from metadata and description; community terms added once enough messages exist; a game missing metadata is never an error |
| Fewer than 3 ratings | collaborative filtering switched off, weights renormalized |

# System Design

## Use cases

![Figure 7. Use cases.](../diagrams/use_case.png){width=6.3in}

## Sequence of rating a recommendation

![Figure 8. Rating a recommended game updates the next list without any refit.](../diagrams/sequence_rating.png){width=6in}

## Interface

A React dashboard with six pages: Home (trending games, sentiment, topics, genres, personal picks), Game Explorer (search, filters, sorting), Game Details (aspects, trend chart, keywords, topics, similar games, personal explanation), Personalized Recommendations (match, breakdown, reasons, adjustable weights), Community Analytics, and Profile. A banner states when data is synthetic. A REST API of 23 paths (24 operations) serves it, with input validation, CORS allow-listing and structured errors.

# Evaluation Metrics

For each user, relevant items are held-out games rated at least 4; candidates are all games the user has not rated (unrated games count as non-relevant). With a ranked list and relevant set:

- Precision@K = hits in top K divided by K; Recall@K = hits divided by the number of relevant items; F1@K is their harmonic mean; hit rate@K is 1 if any hit.
- $\text{NDCG@K} = \text{DCG@K}/\text{IDCG@K}$ with $\text{DCG@K}=\sum_{i=1}^{K} \text{rel}_i/\log_2(i+1)$ and binary relevance.

**Protocol.** Per-user chronological split into 60% train, 20% validation, 20% test. Collaborative filtering is refit on train for tuning and on train plus validation for testing; hybrid weights are tuned only on validation (random search of 60 weight vectors plus the default and single-component vectors; ties keep the default); the test split is scored once per model. 95% percentile bootstrap confidence intervals over users are reported, and differences between models are tested with **paired** bootstrap on the same users. **Models compared:** Random and Popularity baselines; (A) content-only; (B) collaborative-only; (C) content plus collaborative; hybrid without community signals; (D) full hybrid with community intelligence with default weights; and (D*) full hybrid with weights tuned on validation. The comparison that matters is D against hybrid-without-community: does community analysis help? A cold-start experiment gives each user only their first two ratings.

**Harness validation.** Metrics are unit-tested against hand-computed values. A positive control (ratings generated from genre affinity) shows content, collaborative and hybrid models beating random clearly; a null control (pure-noise ratings) shows no model beating random beyond noise, which would fail if test information leaked.

# Results

**Result pending execution.** No evaluation has been run on real data. The code that produces every table below is complete and tested (`ml/evaluation/run_evaluation.py`, `ml/evaluation/eval_sentiment.py`).

*Table 1. Recommendation quality (to be filled by running the harness on real data).*

| Model | Precision@10 | Recall@10 | NDCG@10 |
|---|---|---|---|
| Random | Result pending execution | Result pending execution | Result pending execution |
| Popularity | Result pending execution | Result pending execution | Result pending execution |
| A. Content-only | Result pending execution | Result pending execution | Result pending execution |
| B. Collaborative-only | Result pending execution | Result pending execution | Result pending execution |
| C. Content + collaborative | Result pending execution | Result pending execution | Result pending execution |
| D. Full hybrid with community intelligence | Result pending execution | Result pending execution | Result pending execution |

*Table 2. Sentiment model quality (to be filled using a human-labeled set).*

| Model | Accuracy | Macro precision | Macro recall | Macro F1 |
|---|---|---|---|---|
| VADER | Result pending execution | Result pending execution | Result pending execution | Result pending execution |
| TF-IDF + Logistic Regression | Result pending execution | Result pending execution | Result pending execution | Result pending execution |
| Transformer (optional) | Result pending execution | Result pending execution | Result pending execution | Result pending execution |

**What has been verified.** The system was run end to end on synthetic demo data and on PostgreSQL 16, with 135 backend tests (97% measured line coverage), 19 frontend tests and a live check of the frontend's API client against the running backend. A smoke run of the evaluation harness on the synthetic data confirmed that the code works; that data was generated without any link between community text and ratings, so it cannot show whether community analysis helps, and no conclusion is drawn from it. The dashboard pages were not visually inspected in a browser during the build; add screenshots after running the application.

# Limitations

1. No results on real data yet; all quality claims are pending.
2. Aspect sentiment is rule-based with a fixed aspect list and one score per clause.
3. Hybrid and community-score weights are untuned defaults.
4. The synthetic data cannot test the central claim; a dataset where community text and ratings cover the same games is required.
5. Small catalogs make top-K metrics unreliable; the harness warns about this.
6. No authentication, HTTPS or rate limiting.
7. Not verified: Docker Compose start-up, the transformer sentiment model, real-browser rendering.
8. Sentiment models can be biased by slang, sarcasm and community norms.

# Future Scope

Matrix factorization and neural collaborative filtering; fine-tuned aspect-based sentiment transformers; embeddings or KeyBERT for keywords and content similarity; BERTopic; learning-to-rank for the hybrid weights; implicit feedback such as playtime; authentication and per-user privacy controls; incremental updates; a consent-aware Discord bot for live ingestion.

# Ethical and Privacy Considerations

Discord data is collected only through exports or bots the team is authorized to use, with members informed. Author identifiers are salted and hashed before storage; the API returns aggregates only. Synthetic data is always labeled and never presented as real. The community score is described as a project-defined metric. Explanations disclose uncertainty and caveats.

# Conclusion

GameRec shows how community text can be turned into features (sentiment, aspects, trends, topics) and used, transparently and with explanations, in a hybrid recommender. The system, its database, API, dashboard and evaluation harness are implemented and tested. Whether community intelligence actually improves recommendations is an empirical question that the provided evaluation design can answer once run on real ratings and community text; this report deliberately reports that result as pending rather than asserting it.

# References {.unnumbered}

1. Barbieri, F., Camacho-Collados, J., Espinosa Anke, L., and Neves, L. (2020). TweetEval: Unified benchmark and comparative evaluation for tweet classification. Findings of EMNLP.
2. Blei, D. M., Ng, A. Y., and Jordan, M. I. (2003). Latent Dirichlet Allocation. Journal of Machine Learning Research, 3.
3. Burke, R. (2002). Hybrid recommender systems: Survey and experiments. User Modeling and User-Adapted Interaction, 12(4).
4. Devlin, J., Chang, M.-W., Lee, K., and Toutanova, K. (2019). BERT: Pre-training of deep bidirectional transformers for language understanding. NAACL-HLT.
5. Herlocker, J. L., Konstan, J. A., and Riedl, J. (2000). Explaining collaborative filtering recommendations. CSCW.
6. Herlocker, J. L., Konstan, J. A., Terveen, L. G., and Riedl, J. T. (2004). Evaluating collaborative filtering recommender systems. ACM Transactions on Information Systems, 22(1).
7. Hutto, C. J., and Gilbert, E. (2014). VADER: A parsimonious rule-based model for sentiment analysis of social media text. ICWSM.
8. Järvelin, K., and Kekäläinen, J. (2002). Cumulated gain-based evaluation of IR techniques. ACM Transactions on Information Systems, 20(4).
9. Koren, Y., Bell, R., and Volinsky, C. (2009). Matrix factorization techniques for recommender systems. Computer, 42(8).
10. Lee, D. D., and Seung, H. S. (1999). Learning the parts of objects by non-negative matrix factorization. Nature, 401.
11. Liu, B. (2012). Sentiment Analysis and Opinion Mining. Morgan and Claypool.
12. Liu, Y., Ott, M., Goyal, N., et al. (2019). RoBERTa: A robustly optimized BERT pretraining approach. arXiv:1907.11692.
13. Mimno, D., Wallach, H., Talley, E., Leenders, M., and McCallum, A. (2011). Optimizing semantic coherence in topic models. EMNLP.
14. Pontiki, M., Galanis, D., Pavlopoulos, J., et al. (2014). SemEval-2014 Task 4: Aspect based sentiment analysis. SemEval.
15. Resnick, P., Iacovou, N., Suchak, M., Bergstrom, P., and Riedl, J. (1994). GroupLens: An open architecture for collaborative filtering of netnews. CSCW.
16. Salton, G., and Buckley, C. (1988). Term-weighting approaches in automatic text retrieval. Information Processing and Management, 24(5).
17. Sarwar, B., Karypis, G., Konstan, J., and Riedl, J. (2001). Item-based collaborative filtering recommendation algorithms. WWW.
18. Schein, A. I., Popescul, A., Ungar, L. H., and Pennock, D. M. (2002). Methods and metrics for cold-start recommendations. SIGIR.
