# Testing and review (Phase 15)

```bash
cd backend && pytest                                    # 140 tests, in-memory SQLite
pytest --cov=app                                        # coverage (needs pytest-cov)
GAMEREC_TEST_DB_URL=postgresql+psycopg2://user:pass@localhost/gamerec_test pytest tests/test_api.py tests/test_demo_flow.py
cd frontend && npm test                                 # 19 tests (+1 live test: GAMEREC_LIVE=1 with the API running)
```

## What is covered
| Area | Where | Notes |
|---|---|---|
| Preprocessing (unit) | `test_preprocessing.py` | URLs, negations kept, emoji/slang, empty and junk input, duplicates |
| Sentiment (unit) | `test_sentiment.py` | thresholds, VADER and TF-IDF models, per-game statistics |
| Keywords, topics, aspects, trends, community score | `test_keywords_topics.py`, `test_aspects.py`, `test_trends_community.py` | hand-checkable toy cases plus the demo data |
| Recommendation scoring (unit) | `test_content.py`, `test_collaborative_profile.py`, `test_hybrid.py` | weights, normalization, cold start, ablation weights, evidence-based reasons, catalog fallback |
| API endpoints | `test_api.py` | every endpoint, pagination/filter/sort, validation, 404/409/422/503, CORS, admin token |
| Database integration | `test_ingestion.py`, `test_api.py` on PostgreSQL 16 | schema, loader, constraints |
| Recommendation API integration | `test_recommendation_service.py`, `test_demo_flow.py` | the 12-step demo flow end to end |
| Frontend / backend communication | `frontend/src/integration.test.js` (live), `api.test.js`, `pages.test.jsx` | real API client against the running backend |
| Evaluation harness | `test_evaluation.py` | metrics vs hand-computed values, split/leakage checks, **positive and null controls** |
| Required edge cases | `test_edge_cases.py` | new user, unknown game, empty review, missing metadata, no ratings, insufficient community data, Discord export |
| Security / privacy | `test_security.py` | injection-style input, oversized input, no stack traces, no raw text/author ids in responses, no hardcoded secrets, `.env` handling |

**Measured backend line coverage: 97%** (2139 statements). Lowest: `nlp/sentiment.py` 76% (the transformer model path cannot run offline), `core/db.py` 75% (the PostgreSQL branch is exercised only through the gated Postgres run).

## Bugs the tests found (and fixed)
VADER scoring "combat" as negative; one-rating users carrying no CF signal; aspect priorities inferred from complaints; stated aspect sliders being outranked by inferred ones; and a user with no ratings, preferences or community data receiving **zero** recommendations (now a labeled catalog fallback).

## Security and privacy review
| Item | Status |
|---|---|
| Input validation (Pydantic, query bounds, unknown fields rejected) | done, tested |
| SQL injection | queries are parameterized (SQLAlchemy); search text is escaped; tested with injection-style input |
| XSS | API returns JSON only; React escapes text; user-supplied names are stored as-is |
| Secrets | environment variables only, `.env` is git-ignored, `.env.example` has placeholders; scan test for hardcoded secrets |
| CORS | allow-list from `CORS_ORIGINS`, GET/POST only |
| Error handling | validation errors are structured; unexpected errors return a generic 500 and log details |
| Privacy | Discord author ids salted and hashed on load; raw messages and author ids never returned by the API; synthetic data labeled |
| Database exposure | compose publishes Postgres on localhost only; API container runs as non-root |
| **Authentication / authorization** | **not implemented**: profiles are reachable by id. Fine for a local demo, not for deployment (`users.password_hash` is reserved for it) |
| Rate limiting, HTTPS | not implemented; put the API behind a reverse proxy for any real deployment |

## Not verified
Pages in a real browser (layout, charts); `docker compose up --build`; the transformer sentiment model; any result on real data.
