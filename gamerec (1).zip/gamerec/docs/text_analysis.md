# Keywords, topics and aspect sentiment (Phases 5-6)

## Keywords (`analytics/keywords.py`)
- **Top keywords:** mean TF-IDF over unigrams+bigrams.
- **Game / genre-specific:** each group's messages are merged into one document; TF-IDF then rewards terms frequent in the group and rare elsewhere. Game-name tokens (raw and lemmatized) are excluded.
- **Emerging:** term usage *rate* (fraction of messages) in the last 30 days vs the prior 60, smoothed, with a minimum recent count. Reference date = newest message, so older datasets work.
- Opinion/filler words and negations are dropped here (`TOPIC_STOPWORDS`): they describe how people feel, which sentiment analysis already covers. Sentiment models still see them.

## Topics (`analytics/topics.py`)
- NMF on TF-IDF; topics are **learned from the data**. Names come from a seed-theme overlap weighted by keyword weight, purely for readability; unmatched topics keep a keyword label.
- Default k=8. `k="auto"` picks the best UMass coherence, which tends to favor small k, so read the topics before trusting it.
- Persisted: `topics`, `game_topics` (mean topic share per game), `message_topics` (dominant topic). Trends = topic *share* per week.

## Aspect-based sentiment (`nlp/aspects.py`, `services/aspect_service.py`)
1. Split messages into clauses (sentence punctuation and but/however/although/though/yet).
2. Detect aspects (story, graphics, combat, difficulty, performance, multiplayer, music, price, bugs, exploration) with a lexicon.
3. Mask neutral aspect nouns as "it" before scoring, because VADER's lexicon treats words like "combat" as negative. Sentiment-bearing terms ("expensive", "buggy", "lag") stay visible.
4. Score each clause; every aspect in it gets that score.

Per game: mean score, positive/negative share, and a label (Positive >= 0.2, Negative <= -0.2, Mixed if both shares >= 30%, else Neutral; "Insufficient data" under 5 mentions).
`game_aspect_matrix` returns a game x aspect matrix with shrinkage toward each aspect's global mean, `(sum + 5*prior) / (n + 5)`, so games with few mentions are not extreme. The recommender's aspect match (Phase 10) reads this matrix.

**Limitations:** aspect categories are predefined; several aspects in one clause share a score; sarcasm and implicit aspects are missed. Upgrade path: a fine-tuned ABSA transformer.

## Evidence so far
Real-data results: **pending execution**. Only a synthetic smoke check was run: on the demo data, recovered per-game aspect scores correlate with the generator's designed aspect positivity (Pearson r = 0.67 over 104 game-aspect pairs). That confirms the code works, not that it works on real Discord text. Topics on the demo data mostly mirror its message templates.
