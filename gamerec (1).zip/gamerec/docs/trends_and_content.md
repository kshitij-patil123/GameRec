# Trends, community score, content-based recommendation (Phases 7-8)

## Trend score (`analytics/trends.py`)
`Trend = 0.4*volume + 0.4*growth + 0.2*engagement` (weights configurable, each component in [0,1]).
- **volume:** min-max of log(1 + messages in the last 28 days), across games.
- **growth:** `g/(1+g)` with `g = (recent + 3) / (baseline_scaled + 3)`. The baseline (the 56 days before the recent window) is rescaled to the recent window's length; the pseudo-count of 3 stops tiny counts producing huge ratios. 0.5 means flat.
- **engagement:** min-max of mean engagement per recent message.
- **status:** rising (growth >= 1.25), declining (<= 0.8), stable, or "insufficient data" (< 10 messages total).
- Windows are relative to the newest message, so a dataset that ends in the past still works.
Why this avoids the "old games dominate" problem: only the recent window feeds volume, and growth compares each game with its own history.

## Community Intelligence Score (`analytics/community.py`)
A **project-defined metric**, not an objective measure of quality. Weighted mean of six components in [0,1]:
sentiment 0.35 (shrunk mean, mapped from [-1,1]), consistency 0.10 (1 - std of sentiment), volume 0.15 (log-minmax of all-time messages), trend 0.20, aspect 0.15 (shrunk mean aspect sentiment), engagement 0.05.
Missing components (for example no aspect results) are dropped and the remaining weights renormalized. Shrinkage `(sum + 10*prior)/(n + 10)` pulls small-sample games toward the global mean; `confidence = n/(n+10)` is stored so the UI can flag thin data.
Tuning: the weights are a starting point. Check them with the ablation study in Phase 14 rather than trusting them.

## Content-based recommender (`recommender/content.py`)
Each game = four TF-IDF blocks (genres 0.30, tags 0.30, description 0.25, community keywords 0.15), each L2-normalized and scaled by sqrt(weight), so a dot product is the weighted mean of block cosines.
- **Similar games:** cosine to every other game.
- **User profile:** weighted sum of rated games' vectors, weights = rating - 3 (so low ratings push the profile away from similar games); without a rating, liked +1.5, disliked -1.5, played +0.25. Seen games are excluded.
- **Cold-start user:** `recommend_for_preferences(genres, tags, favorite_game_ids)`.
- **Cold-start game:** `similar_to_new_game(genres, tags, description)`; a game missing a block gets zeros there (lower similarity, never a crash).
- Community keywords in the content vectors can be switched off (`use_keywords=False`) for the ablation study.

## Evidence so far
Real-data results: **pending execution**. Synthetic smoke checks only (demo data, generator-designed signals):
- Trend: designed trend vs growth ratio r = 0.75, vs trend score r = 0.82 (24 games). My first demo generator had a tiny growth effect and gave r of about 0 on growth; I strengthened the generator, not the scorer.
- Content: similar games to a RPG/Action title are other RPG/Action titles first.
Recommendation quality (Precision@K, NDCG@K) is measured in Phase 14.
