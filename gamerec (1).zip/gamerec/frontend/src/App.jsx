import { Route, Routes } from 'react-router-dom'
import Layout from './components/Layout'
import Home from './pages/Home'
import Explorer from './pages/Explorer'
import GameDetail from './pages/GameDetail'
import Recommendations from './pages/Recommendations'
import Community from './pages/Community'
import Profile from './pages/Profile'

export default function App() {
  return (
    <Routes>
      <Route element={<Layout />}>
        <Route index element={<Home />} />
        <Route path="games" element={<Explorer />} />
        <Route path="games/:id" element={<GameDetail />} />
        <Route path="for-you" element={<Recommendations />} />
        <Route path="community" element={<Community />} />
        <Route path="profile" element={<Profile />} />
        <Route path="*" element={<p className="py-20 text-center text-slate-500">Page not found.</p>} />
      </Route>
    </Routes>
  )
}
