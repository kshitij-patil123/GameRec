import { lazy, Suspense } from 'react'
import { Spinner } from './ui'

// Plotly is large; load it only when a chart is actually shown.
const PlotlyChart = lazy(() => import('./PlotlyChart'))

export default function Chart({ data, layout, height = 280 }) {
  return (
    <Suspense
      fallback={
        <div style={{ height }} className="grid place-items-center">
          <Spinner />
        </div>
      }
    >
      <PlotlyChart data={data} layout={layout} height={height} />
    </Suspense>
  )
}
