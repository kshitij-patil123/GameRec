import { Link, NavLink, Outlet } from 'react-router-dom'
import { useApi } from '../services/useApi'
import { api } from '../services/api'
import { useUser } from '../context/UserContext'

const NAV = [
  ['/', 'Home'],
  ['/games', 'Explore'],
  ['/for-you', 'For you'],
  ['/community', 'Community'],
  ['/profile', 'Profile'],
]

export default function Layout() {
  const { userId, setUserId, users } = useUser()
  const meta = useApi(() => api.meta(), [])
  return (
    <div className="min-h-screen">
      {meta.data?.banner && (
        <div role="status" className="bg-amber-100 px-4 py-1.5 text-center text-xs font-medium text-amber-800">
          {meta.data.banner}
        </div>
      )}
      <header className="sticky top-0 z-10 border-b border-slate-200 bg-white/90 backdrop-blur">
        <div className="mx-auto flex max-w-6xl flex-wrap items-center gap-x-6 gap-y-2 px-4 py-3">
          <Link to="/" className="text-lg font-bold tracking-tight text-brand-600">
            GameRec
          </Link>
          <nav className="flex flex-1 flex-wrap gap-1 text-sm">
            {NAV.map(([to, label]) => (
              <NavLink
                key={to}
                to={to}
                end={to === '/'}
                className={({ isActive }) =>
                  `rounded-lg px-3 py-1.5 font-medium ${isActive ? 'bg-brand-50 text-brand-700' : 'text-slate-600 hover:bg-slate-100'}`
                }
              >
                {label}
              </NavLink>
            ))}
          </nav>
          <label className="flex items-center gap-2 text-xs text-slate-500">
            Profile
            <select
              className="input py-1.5"
              value={userId ?? ''}
              onChange={(e) => setUserId(e.target.value ? Number(e.target.value) : null)}
              aria-label="Select profile"
            >
              <option value="">Not selected</option>
              {users.map((u) => (
                <option key={u.id} value={u.id}>
                  {u.display_name} ({u.n_ratings})
                </option>
              ))}
            </select>
          </label>
        </div>
      </header>
      <main className="mx-auto max-w-6xl px-4 py-8">
        <Outlet />
      </main>
      <footer className="mx-auto max-w-6xl px-4 pb-8 text-xs text-slate-400">
        Community scores are project-defined metrics, not objective quality ratings.
      </footer>
    </div>
  )
}
