import Plotly from 'plotly.js-basic-dist-min'
import createPlotlyComponent from 'react-plotly.js/factory'

const Plot = createPlotlyComponent(Plotly)
const axis = { gridcolor: '#e2e8f0', zerolinecolor: '#cbd5e1', automargin: true }
const base = {
  margin: { l: 48, r: 12, t: 8, b: 40 },
  paper_bgcolor: 'rgba(0,0,0,0)',
  plot_bgcolor: 'rgba(0,0,0,0)',
  font: { family: 'Inter, system-ui, sans-serif', size: 12, color: '#475569' },
  legend: { orientation: 'h', y: -0.25 },
  autosize: true,
}

export default function PlotlyChart({ data, layout = {}, height = 280 }) {
  const merged = {
    ...base,
    ...layout,
    height,
    xaxis: { ...axis, ...layout.xaxis },
    yaxis: { ...axis, ...layout.yaxis },
  }
  return (
    <Plot
      data={data}
      layout={merged}
      config={{ displayModeBar: false, responsive: true }}
      useResizeHandler
      style={{ width: '100%' }}
    />
  )
}
