import { Link } from 'react-router-dom'
import { Chips, ContributionBar, ReasonList, StarRating, StatusBadge } from './ui'

const STRATEGY_LABEL = {
  hybrid: 'Personalized hybrid',
  cold_start_preferences: 'Based on your stated preferences',
  popular_trending: 'Popular & trending (no profile data yet)',
  catalog_fallback: 'Catalog order (no signals available yet)',
}

export default function RecommendationCard({ item, onRate, busy, compact = false }) {
  const { game } = item
  return (
    <article className="card flex flex-col gap-3">
      <div className="flex items-start justify-between gap-3">
        <div>
          <p className="text-xs text-slate-400">#{item.rank}</p>
          <Link to={`/games/${game.id}`} className="text-lg font-semibold text-slate-900 hover:text-brand-600">
            {game.name}
          </Link>
          <div className="mt-1.5 flex items-center gap-2">
            <Chips items={game.genres} max={3} />
            <StatusBadge status={game.status} />
          </div>
        </div>
        <div className="text-right" title="Relative to the other candidate games, not a probability">
          <p className="text-2xl font-bold text-brand-600">{item.match_percent}%</p>
          <p className="text-[11px] uppercase tracking-wide text-slate-400">match</p>
        </div>
      </div>
      <ContributionBar contributions={item.contributions} />
      <div>
        <p className="mb-1 text-xs font-medium text-slate-500">Recommended because</p>
        <ReasonList reasons={compact ? item.reasons.slice(0, 2) : item.reasons} />
      </div>
      {!compact && <p className="text-[11px] text-slate-400">{STRATEGY_LABEL[item.strategy] || item.strategy}</p>}
      {onRate && (
        <div className="flex flex-wrap items-center justify-between gap-2 border-t border-slate-100 pt-3">
          <div className="flex items-center gap-2 text-xs text-slate-500">
            Rate it <StarRating onRate={(n) => onRate(game.id, { rating: n })} disabled={busy} />
          </div>
          <button
            className="btn btn-ghost py-1 text-xs"
            disabled={busy}
            onClick={() => onRate(game.id, { interaction: 'disliked' })}
          >
            Not for me
          </button>
        </div>
      )}
    </article>
  )
}
