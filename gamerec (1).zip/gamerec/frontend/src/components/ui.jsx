import { Link } from 'react-router-dom'
import { COMPONENT_META, STATUS_STYLE, num } from '../lib/format'

export function Spinner() {
  return (
    <div role="status" aria-label="Loading" className="flex justify-center py-8">
      <div className="h-6 w-6 animate-spin rounded-full border-2 border-brand-100 border-t-brand-600" />
    </div>
  )
}

export function ErrorBox({ error, onRetry }) {
  const notReady = error?.status === 503
  return (
    <div role="alert" className="rounded-xl border border-rose-200 bg-rose-50 p-4 text-sm text-rose-700">
      <p className="font-medium">{notReady ? 'The analysis data is not ready yet.' : 'Something went wrong.'}</p>
      <p className="mt-1">{error?.message}</p>
      {notReady && (
        <p className="mt-1">
          Run <code className="rounded bg-rose-100 px-1">python scripts/run_pipeline.py demo</code> and reload.
        </p>
      )}
      {onRetry && (
        <button className="btn btn-ghost mt-3" onClick={onRetry}>
          Try again
        </button>
      )}
    </div>
  )
}

/** Renders loading / error states for a useApi() result, then `children(data)`. */
export function Async({ state, children }) {
  if (state.loading && state.data == null) return <Spinner />
  if (state.error) return <ErrorBox error={state.error} onRetry={state.reload} />
  if (state.data == null) return null
  return children(state.data)
}

export function EmptyState({ title, children }) {
  return (
    <div className="rounded-xl border border-dashed border-slate-300 p-6 text-center text-sm text-slate-500">
      <p className="font-medium text-slate-700">{title}</p>
      {children && <div className="mt-2">{children}</div>}
    </div>
  )
}

export function PageHeader({ title, subtitle, children }) {
  return (
    <div className="mb-6 flex flex-wrap items-end justify-between gap-3">
      <div>
        <h1 className="text-2xl font-semibold tracking-tight text-slate-900">{title}</h1>
        {subtitle && <p className="mt-1 text-sm text-slate-500">{subtitle}</p>}
      </div>
      {children}
    </div>
  )
}

export function Section({ title, hint, children, className = '' }) {
  return (
    <section className={`card ${className}`}>
      <div className="mb-3">
        <h2 className="text-base font-semibold text-slate-900">{title}</h2>
        {hint && <p className="text-xs text-slate-500">{hint}</p>}
      </div>
      {children}
    </section>
  )
}

export function StatCard({ label, value, hint }) {
  return (
    <div className="card">
      <p className="text-xs font-medium uppercase tracking-wide text-slate-500">{label}</p>
      <p className="mt-1 text-2xl font-semibold text-slate-900">{value}</p>
      {hint && <p className="text-xs text-slate-500">{hint}</p>}
    </div>
  )
}

export function StatusBadge({ status }) {
  if (!status) return null
  return <span className={`chip ${STATUS_STYLE[status] || STATUS_STYLE.stable}`}>{status}</span>
}

export function Chips({ items = [], max = 6 }) {
  return (
    <div className="flex flex-wrap gap-1.5">
      {items.slice(0, max).map((t) => (
        <span key={t} className="chip">
          {t}
        </span>
      ))}
    </div>
  )
}

export function StarRating({ value, onRate, disabled }) {
  return (
    <div className="inline-flex gap-0.5" role="group" aria-label="Rate this game">
      {[1, 2, 3, 4, 5].map((n) => (
        <button
          key={n}
          type="button"
          disabled={disabled}
          aria-label={`${n} star${n > 1 ? 's' : ''}`}
          onClick={() => onRate(n)}
          className={`text-xl leading-none transition ${n <= (value || 0) ? 'text-amber-400' : 'text-slate-300 hover:text-amber-300'}`}
        >
          ★
        </button>
      ))}
    </div>
  )
}

/** ✓ for supporting reasons, ! for caveats. */
export function ReasonList({ reasons = [] }) {
  return (
    <ul className="space-y-1 text-sm">
      {reasons.map((r, i) => (
        <li key={i} className={`flex gap-2 ${r.positive ? 'text-slate-700' : 'text-amber-700'}`}>
          <span aria-hidden className={r.positive ? 'text-emerald-600' : 'text-amber-600'}>
            {r.positive ? '✓' : '!'}
          </span>
          <span>{r.text}</span>
        </li>
      ))}
    </ul>
  )
}

/** Stacked bar: each component's weighted contribution to the final score. */
export function ContributionBar({ contributions = {} }) {
  const entries = Object.entries(contributions).filter(([, v]) => v > 0)
  const total = entries.reduce((s, [, v]) => s + v, 0) || 1
  return (
    <div>
      <div className="flex h-2.5 overflow-hidden rounded-full bg-slate-100" aria-label="Score breakdown">
        {entries.map(([k, v]) => (
          <div
            key={k}
            title={`${COMPONENT_META[k]?.label || k}: ${num(v * 100, 1)} pts`}
            style={{ width: `${(v / total) * 100}%`, background: COMPONENT_META[k]?.color || '#94a3b8' }}
          />
        ))}
      </div>
      <div className="mt-1.5 flex flex-wrap gap-x-3 gap-y-0.5 text-[11px] text-slate-500">
        {entries.map(([k]) => (
          <span key={k} className="inline-flex items-center gap-1">
            <i className="inline-block h-2 w-2 rounded-full" style={{ background: COMPONENT_META[k]?.color }} />
            {COMPONENT_META[k]?.label || k}
          </span>
        ))}
      </div>
    </div>
  )
}

export function GameCard({ game, children }) {
  return (
    <div className="card flex flex-col gap-3 transition hover:shadow-md">
      <div className="flex items-start justify-between gap-2">
        <Link to={`/games/${game.id}`} className="font-semibold text-slate-900 hover:text-brand-600">
          {game.name}
        </Link>
        <StatusBadge status={game.status} />
      </div>
      <Chips items={game.genres} max={3} />
      <div className="mt-auto flex items-center gap-4 text-xs text-slate-500">
        <span title="Project-defined community intelligence score">
          Community <b className="text-slate-800">{game.community_score == null ? '–' : Math.round(game.community_score * 100)}</b>
        </span>
        <span>
          Positive <b className="text-slate-800">{game.positive_pct == null ? '–' : `${Math.round(game.positive_pct)}%`}</b>
        </span>
        <span>
          Rating <b className="text-slate-800">{num(game.rating)}</b>
        </span>
      </div>
      {children}
    </div>
  )
}
