import { fireEvent, render, screen } from '@testing-library/react'
import { MemoryRouter } from 'react-router-dom'
import { describe, expect, it, vi } from 'vitest'
import { Async, ContributionBar, ErrorBox, ReasonList, StarRating } from './ui'

describe('ReasonList', () => {
  it('marks supporting reasons with ✓ and caveats with !', () => {
    render(<ReasonList reasons={[{ text: 'Strong sentiment', positive: true }, { text: 'Caveat: declining', positive: false }]} />)
    const items = screen.getAllByRole('listitem')
    expect(items[0].querySelector('[aria-hidden]')).toHaveTextContent('✓')
    expect(items[0]).toHaveTextContent('Strong sentiment')
    expect(items[1].querySelector('[aria-hidden]')).toHaveTextContent('!')
    expect(items[1]).toHaveTextContent('Caveat: declining')
  })
})

describe('ContributionBar', () => {
  it('sizes segments proportionally and skips zero components', () => {
    const { container } = render(<ContributionBar contributions={{ content: 0.3, trend: 0.1, aspect: 0 }} />)
    const segs = container.querySelectorAll('[style*="width"]')
    expect(segs).toHaveLength(2)
    expect(parseFloat(segs[0].style.width)).toBeCloseTo(75, 5)
    expect(parseFloat(segs[1].style.width)).toBeCloseTo(25, 5)
  })
})

describe('StarRating', () => {
  it('reports the clicked star and honors disabled', () => {
    const onRate = vi.fn()
    const { rerender } = render(<StarRating onRate={onRate} />)
    fireEvent.click(screen.getByLabelText('4 stars'))
    expect(onRate).toHaveBeenCalledWith(4)
    rerender(<StarRating onRate={onRate} disabled />)
    expect(screen.getByLabelText('5 stars')).toBeDisabled()
  })
})

describe('Async / ErrorBox', () => {
  it('shows a spinner, an error with retry, then data', () => {
    const retry = vi.fn()
    const { rerender } = render(<Async state={{ loading: true, data: null }}>{() => <p>data</p>}</Async>)
    expect(screen.getByRole('status')).toBeInTheDocument()
    rerender(<Async state={{ loading: false, error: new Error('boom'), reload: retry }}>{() => <p>data</p>}</Async>)
    fireEvent.click(screen.getByText('Try again'))
    expect(retry).toHaveBeenCalled()
    rerender(<Async state={{ loading: false, data: { a: 1 } }}>{(d) => <p>got {d.a}</p>}</Async>)
    expect(screen.getByText('got 1')).toBeInTheDocument()
  })

  it('tells the user how to prepare data on a 503', () => {
    render(<ErrorBox error={Object.assign(new Error('No games loaded yet.'), { status: 503 })} />)
    expect(screen.getByText(/run_pipeline/)).toBeInTheDocument()
  })
})
