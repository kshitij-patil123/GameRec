import { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react'
import { api } from '../services/api'

const UserContext = createContext(null)
const KEY = 'gamerec.userId'

export function UserProvider({ children }) {
  const [userId, setUserIdState] = useState(() => {
    try {
      const v = localStorage.getItem(KEY)
      return v ? Number(v) : null
    } catch {
      return null
    }
  })
  const [users, setUsers] = useState([])

  const refreshUsers = useCallback(() => api.users().then(setUsers).catch(() => setUsers([])), [])
  useEffect(() => {
    refreshUsers()
  }, [refreshUsers])

  const setUserId = useCallback((id) => {
    setUserIdState(id)
    try {
      id ? localStorage.setItem(KEY, String(id)) : localStorage.removeItem(KEY)
    } catch {
      /* storage unavailable: keep in memory only */
    }
  }, [])

  const value = useMemo(() => ({ userId, setUserId, users, refreshUsers }), [userId, setUserId, users, refreshUsers])
  return <UserContext.Provider value={value}>{children}</UserContext.Provider>
}

export const useUser = () => useContext(UserContext)
