// Runs the real api.js against a live backend. Skipped unless GAMEREC_LIVE=1 (backend on VITE_API_URL).
import { describe, expect, it } from 'vitest'
import { api } from './services/api'

describe.skipIf(!process.env.GAMEREC_LIVE)('live API', () => {
  // the first recommendation request builds the recommender, so allow generous time
  it('serves the dashboard, explorer, recommendations and profile flows', { timeout: 60000 }, async () => {
    const meta = await api.meta()
    expect(meta.counts.games).toBeGreaterThan(0)
    const overview = await api.overview()
    expect(overview.trending_games.length).toBeGreaterThan(0)
    const list = await api.games({ genre: 'RPG', sort: 'community_score', order: 'desc', limit: 5 })
    expect(list.items.length).toBeGreaterThan(0)

    const user = await api.createUser('Vitest user')
    await api.setPreferences(user.id, { genres: ['RPG'], tags: [], aspects: { story: 0.9 } })
    const cold = await api.recommendations(user.id, { n: 3 })
    expect(cold.strategy).toBe('cold_start_preferences')
    const top = cold.items[0].game.id
    await api.rate(user.id, { game_id: top, rating: 5 })
    const after = await api.recommendations(user.id, { n: 3, save: true })
    expect(after.items.map((i) => i.game.id)).not.toContain(top)
    const profile = await api.profile(user.id)
    expect(profile.recommendation_history).toHaveLength(1)
    await expect(api.explain(user.id, top)).rejects.toMatchObject({ status: 409 })
    await expect(api.rate(user.id, { game_id: top, rating: 9 })).rejects.toMatchObject({ status: 422 })
  })
})
