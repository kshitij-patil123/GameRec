import { Link } from 'react-router-dom'
import Chart from '../components/Chart'
import { Async, PageHeader, Section, StatusBadge } from '../components/ui'
import { cap } from '../lib/format'
import { api } from '../services/api'
import { useApi } from '../services/useApi'

const SENT_COLOR = { positive: '#22c55e', neutral: '#94a3b8', negative: '#f43f5e' }
const STATUS_COLOR = { rising: '#10b981', stable: '#94a3b8', declining: '#f43f5e', 'insufficient data': '#f59e0b' }

export default function Community() {
  const sentiment = useApi(() => api.sentiment(), [])
  const topics = useApi(() => api.topics(), [])
  const aspects = useApi(() => api.aspects(), [])
  const keywords = useApi(() => api.keywords(), [])
  const activity = useApi(() => api.activity(), [])
  const trending = useApi(() => api.trendingGames(10), [])
  const trendTopics = useApi(() => api.trendingTopics(8), [])

  return (
    <>
      <PageHeader title="Community analytics" subtitle="What gaming communities are saying, extracted from message text with NLP." />
      <div className="grid gap-6 lg:grid-cols-2">
        <Section title="Sentiment distribution" hint={`Model: VADER lexicon baseline`}>
          <Async state={sentiment}>
            {(s) => (
              <Chart height={260}
                data={[{ type: 'pie', hole: 0.55, sort: false, labels: Object.keys(s.distribution_pct).map(cap),
                  values: Object.values(s.distribution_pct), marker: { colors: Object.keys(s.distribution_pct).map((k) => SENT_COLOR[k]) } }]}
                layout={{ margin: { l: 8, r: 8, t: 8, b: 8 } }} />
            )}
          </Async>
        </Section>
        <Section title="Sentiment over time" hint="Weekly share of positive / neutral / negative messages">
          <Async state={sentiment}>
            {(s) => (
              <Chart height={260}
                data={['positive', 'neutral', 'negative'].map((k) => ({
                  type: 'scatter', mode: 'lines', stackgroup: 'one', name: cap(k), line: { color: SENT_COLOR[k], width: 0.5 },
                  x: s.label_shares_by_period.map((p) => p.period), y: s.label_shares_by_period.map((p) => p[k]) }))}
                layout={{ yaxis: { title: '% of messages', range: [0, 100] } }} />
            )}
          </Async>
        </Section>

        <Section title="Most discussed topics" hint="Topics discovered from the data with NMF, then labeled for readability">
          <Async state={topics}>
            {(t) => (
              <>
                <Chart height={260}
                  data={[{ type: 'bar', orientation: 'h', y: [...t.topics].reverse().map((x) => x.label),
                    x: [...t.topics].reverse().map((x) => x.share * 100), marker: { color: '#6366f1' },
                    customdata: [...t.topics].reverse().map((x) => x.keywords.slice(0, 5).join(', ')),
                    hovertemplate: '%{y}: %{x:.1f}%<br>%{customdata}<extra></extra>' }]}
                  layout={{ margin: { l: 150, r: 8, t: 8, b: 40 }, xaxis: { title: '% of messages' } }} />
              </>
            )}
          </Async>
        </Section>
        <Section title="Topic trends" hint="Change in share: last 4 weeks vs. previous 8">
          <Async state={trendTopics}>
            {(t) => (
              <Chart height={260}
                data={[{ type: 'bar', orientation: 'h', y: [...t].reverse().map((x) => x.label),
                  x: [...t].reverse().map((x) => x.change * 100),
                  marker: { color: [...t].reverse().map((x) => (x.change >= 0 ? '#10b981' : '#f43f5e')) } }]}
                layout={{ margin: { l: 150, r: 8, t: 8, b: 40 }, xaxis: { title: 'Change in share (percentage points)' } }} />
            )}
          </Async>
        </Section>

        <Section title="Top keywords" hint="TF-IDF over cleaned text; game names and opinion words removed">
          <Async state={keywords}>
            {(k) => (
              <Chart height={300}
                data={[{ type: 'bar', orientation: 'h', y: [...k.top].reverse().map((x) => x.term),
                  x: [...k.top].reverse().map((x) => x.score), marker: { color: '#0ea5e9' } }]}
                layout={{ margin: { l: 110, r: 8, t: 8, b: 40 }, xaxis: { title: 'Mean TF-IDF' } }} />
            )}
          </Async>
        </Section>
        <Section title="Emerging keywords" hint="Terms used much more in the last 30 days than the 60 before">
          <Async state={keywords}>
            {(k) => k.emerging.length === 0 ? <p className="text-sm text-slate-500">Not enough data in both windows.</p> : (
              <table className="w-full text-sm">
                <thead className="text-left text-xs text-slate-500"><tr><th>Term</th><th className="text-right">Growth</th><th className="text-right">Recent</th></tr></thead>
                <tbody>
                  {k.emerging.slice(0, 10).map((e) => (
                    <tr key={e.term} className="border-t border-slate-100">
                      <td className="py-1.5 font-medium">{e.term}</td>
                      <td className="text-right">×{e.growth.toFixed(1)}</td>
                      <td className="text-right text-slate-500">{e.recent_count}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </Async>
        </Section>

        <Section title="Aspect sentiment" hint="Average sentiment toward each aspect across all games">
          <Async state={aspects}>
            {(a) => (
              <Chart height={300}
                data={[{ type: 'bar', orientation: 'h', y: [...a.aspects].reverse().map((x) => x.aspect),
                  x: [...a.aspects].reverse().map((x) => x.mean_score),
                  marker: { color: [...a.aspects].reverse().map((x) => (x.mean_score >= 0 ? '#22c55e' : '#f43f5e')) },
                  customdata: [...a.aspects].reverse().map((x) => x.n_mentions),
                  hovertemplate: '%{y}: %{x:.2f} (%{customdata} mentions)<extra></extra>' }]}
                layout={{ xaxis: { range: [-1, 1], title: 'Mean sentiment' }, margin: { l: 100, r: 8, t: 8, b: 48 } }} />
            )}
          </Async>
        </Section>
        <Section title="Community activity" hint="Messages per week across all games">
          <Async state={activity}>
            {(a) => (
              <Chart height={300}
                data={[{ type: 'scatter', mode: 'lines', fill: 'tozeroy', x: a.volume_timeline.map((p) => p.period),
                  y: a.volume_timeline.map((p) => p.n_messages), line: { color: '#6366f1' } }]}
                layout={{ yaxis: { title: 'Messages' } }} />
            )}
          </Async>
        </Section>

        <Section title="Top games by community activity" hint="All-time messages; color shows trend status">
          <Async state={activity}>
            {(a) => (
              <Chart height={300}
                data={[{ type: 'bar', x: a.top_games_by_activity.map((g) => g.name), y: a.top_games_by_activity.map((g) => g.n_messages),
                  marker: { color: a.top_games_by_activity.map((g) => STATUS_COLOR[g.status]) } }]}
                layout={{ xaxis: { tickangle: -30 }, margin: { l: 48, r: 8, t: 8, b: 90 }, yaxis: { title: 'Messages' } }} />
            )}
          </Async>
        </Section>
        <Section title="Trending games">
          <Async state={trending}>
            {(g) => (
              <ol className="divide-y divide-slate-100 text-sm">
                {g.map((x, i) => (
                  <li key={x.id} className="flex items-center justify-between py-2">
                    <span><span className="mr-2 text-slate-400">{i + 1}</span>
                      <Link className="font-medium hover:text-brand-600" to={`/games/${x.id}`}>{x.name}</Link></span>
                    <span className="flex items-center gap-2 text-xs text-slate-500">×{x.growth_ratio.toFixed(1)} <StatusBadge status={x.status} /></span>
                  </li>
                ))}
              </ol>
            )}
          </Async>
        </Section>
      </div>
    </>
  )
}
