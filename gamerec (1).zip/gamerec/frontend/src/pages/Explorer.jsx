import { useEffect, useState } from 'react'
import { Async, EmptyState, GameCard, PageHeader } from '../components/ui'
import { api } from '../services/api'
import { useApi } from '../services/useApi'

const PAGE = 12
const SORTS = [
  ['name', 'Name'], ['community_score', 'Community score'], ['trend_score', 'Trending'],
  ['rating', 'Rating'], ['release_date', 'Release date'],
]

export default function Explorer() {
  const [q, setQ] = useState('')
  const [debounced, setDebounced] = useState('')
  const [genre, setGenre] = useState('')
  const [platform, setPlatform] = useState('')
  const [minRating, setMinRating] = useState('')
  const [sort, setSort] = useState('community_score')
  const [page, setPage] = useState(0)

  useEffect(() => {
    const t = setTimeout(() => setDebounced(q.trim()), 300)
    return () => clearTimeout(t)
  }, [q])
  useEffect(() => setPage(0), [debounced, genre, platform, minRating, sort])

  const filters = useApi(() => api.filters(), [])
  const games = useApi(
    () =>
      api.games({
        q: debounced, genre, platform, min_rating: minRating, sort,
        order: sort === 'name' ? 'asc' : 'desc', limit: PAGE, offset: page * PAGE,
      }),
    [debounced, genre, platform, minRating, sort, page],
  )
  const pages = games.data ? Math.max(1, Math.ceil(games.data.total / PAGE)) : 1

  return (
    <>
      <PageHeader title="Game explorer" subtitle="Search and filter games, ranked by community signals." />
      <div className="card mb-6 grid gap-3 md:grid-cols-5">
        <input className="input md:col-span-2" placeholder="Search by name…" aria-label="Search games" value={q} onChange={(e) => setQ(e.target.value)} />
        <select className="input" aria-label="Genre" value={genre} onChange={(e) => setGenre(e.target.value)}>
          <option value="">All genres</option>
          {filters.data?.genres.map((g) => <option key={g}>{g}</option>)}
        </select>
        <select className="input" aria-label="Platform" value={platform} onChange={(e) => setPlatform(e.target.value)}>
          <option value="">All platforms</option>
          {filters.data?.platforms.map((p) => <option key={p}>{p}</option>)}
        </select>
        <select className="input" aria-label="Minimum rating" value={minRating} onChange={(e) => setMinRating(e.target.value)}>
          <option value="">Any rating</option>
          {[3, 3.5, 4, 4.5].map((r) => <option key={r} value={r}>{r}+ ★</option>)}
        </select>
        <label className="flex items-center gap-2 text-xs text-slate-500 md:col-span-5">
          Sort by
          <select className="input py-1.5" value={sort} onChange={(e) => setSort(e.target.value)}>
            {SORTS.map(([v, l]) => <option key={v} value={v}>{l}</option>)}
          </select>
        </label>
      </div>
      <Async state={games}>
        {(d) =>
          d.items.length === 0 ? (
            <EmptyState title="No games match these filters" />
          ) : (
            <>
              <p className="mb-3 text-sm text-slate-500">{d.total} games</p>
              <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
                {d.items.map((g) => <GameCard key={g.id} game={g} />)}
              </div>
              <div className="mt-6 flex items-center justify-center gap-3">
                <button className="btn btn-ghost" disabled={page === 0} onClick={() => setPage((p) => p - 1)}>Previous</button>
                <span className="text-sm text-slate-500">Page {page + 1} of {pages}</span>
                <button className="btn btn-ghost" disabled={page + 1 >= pages} onClick={() => setPage((p) => p + 1)}>Next</button>
              </div>
            </>
          )
        }
      </Async>
    </>
  )
}
