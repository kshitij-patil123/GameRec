import { useState } from 'react'
import { Link, useParams } from 'react-router-dom'
import Chart from '../components/Chart'
import { Async, Chips, EmptyState, GameCard, PageHeader, ReasonList, Section, StarRating, StatCard, StatusBadge, ContributionBar } from '../components/ui'
import { useUser } from '../context/UserContext'
import { ASPECT_LABEL_STYLE, num, pct } from '../lib/format'
import { api } from '../services/api'
import { useApi } from '../services/useApi'

export default function GameDetail() {
  const { id } = useParams()
  const { userId, refreshUsers } = useUser()
  const [tick, setTick] = useState(0)
  const [msg, setMsg] = useState(null)

  const game = useApi(() => api.game(id), [id])
  const community = useApi(() => api.community(id), [id])
  const similar = useApi(() => api.similar(id), [id])
  const explain = useApi(
    () => (userId ? api.explain(userId, id).catch((e) => (e.status === 409 ? { alreadyRated: true } : Promise.reject(e))) : null),
    [userId, id, tick],
  )

  async function rate(rating) {
    setMsg(null)
    try {
      await api.rate(userId, { game_id: Number(id), rating })
      setMsg(`Saved your ${rating}★ rating. Your recommendations will use it.`)
      setTick((t) => t + 1)
      refreshUsers()
    } catch (e) {
      setMsg(e.message)
    }
  }

  return (
    <Async state={game}>
      {(g) => (
        <>
          <Link to="/games" className="text-sm text-slate-500 hover:text-brand-600">← All games</Link>
          <PageHeader title={g.name} subtitle={g.description}>
            <StatusBadge status={g.status} />
          </PageHeader>
          <div className="mb-6 flex flex-wrap items-center gap-x-6 gap-y-2 text-sm text-slate-600">
            <Chips items={g.genres} max={5} />
            <Chips items={g.tags} max={6} />
            <span>{g.platforms.join(' · ')}</span>
            <span>{g.developer} / {g.publisher}</span>
            <span>Released {g.release_date}</span>
          </div>

          <div className="mb-6 grid grid-cols-2 gap-4 md:grid-cols-4">
            <StatCard label="Community score" value={g.community_score == null ? '–' : Math.round(g.community_score * 100)} hint="project-defined metric" />
            <StatCard label="Positive messages" value={g.positive_pct == null ? '–' : `${Math.round(g.positive_pct)}%`} hint={`${g.n_messages ?? 0} messages`} />
            <StatCard label="Trend score" value={num(g.trend_score, 2)} hint={g.status} />
            <StatCard label="Data confidence" value={pct(g.confidence)} hint="how much data backs the scores" />
          </div>

          <div className="grid gap-6 lg:grid-cols-5">
            <Section title="Why this game for you" className="lg:col-span-2" hint="Personal explanation from the hybrid engine">
              {!userId ? (
                <EmptyState title="Select a profile to see a personal explanation">
                  <Link className="btn btn-primary" to="/profile">Choose profile</Link>
                </EmptyState>
              ) : (
                <Async state={explain}>
                  {(e) =>
                    e.alreadyRated ? (
                      <p className="text-sm text-slate-600">You have already rated this game, so it is not a candidate.</p>
                    ) : (
                      <div className="space-y-3">
                        <p className="text-sm">
                          <b className="text-2xl text-brand-600">{e.match_percent}%</b> match · rank {e.rank} for you
                        </p>
                        <ContributionBar contributions={e.contributions} />
                        <ReasonList reasons={e.reasons} />
                      </div>
                    )
                  }
                </Async>
              )}
              {userId && (
                <div className="mt-4 border-t border-slate-100 pt-3 text-sm text-slate-500">
                  <p className="mb-1">Rate this game</p>
                  <StarRating onRate={rate} />
                  {msg && <p className="mt-2 text-xs text-emerald-700" role="status">{msg}</p>}
                </div>
              )}
            </Section>

            <Async state={community}>
              {(c) => (
                <>
                  <Section title="Aspect sentiment" hint="What the community thinks about each part of the game" className="lg:col-span-3">
                    {c.aspects.length === 0 ? (
                      <EmptyState title="No aspect mentions yet" />
                    ) : (
                      <>
                        <Chart
                          height={Math.max(220, c.aspects.length * 30)}
                          data={[{
                            type: 'bar', orientation: 'h',
                            y: [...c.aspects].reverse().map((a) => a.aspect),
                            x: [...c.aspects].reverse().map((a) => a.mean_score),
                            marker: { color: [...c.aspects].reverse().map((a) => (a.mean_score >= 0.2 ? '#22c55e' : a.mean_score <= -0.2 ? '#f43f5e' : '#94a3b8')) },
                            customdata: [...c.aspects].reverse().map((a) => [a.n_mentions, a.label]),
                            hovertemplate: '%{y}: %{x:.2f}<br>%{customdata[0]} mentions · %{customdata[1]}<extra></extra>',
                          }]}
                          layout={{ xaxis: { range: [-1, 1], title: 'Mean sentiment (−1 negative … +1 positive)' }, margin: { l: 90, r: 8, t: 8, b: 48 } }}
                        />
                        <div className="mt-2 flex flex-wrap gap-1.5">
                          {c.aspects.map((a) => (
                            <span key={a.aspect} className={`chip ${ASPECT_LABEL_STYLE[a.label]}`}>{a.aspect}: {a.label}</span>
                          ))}
                        </div>
                      </>
                    )}
                  </Section>

                  <Section title="Discussion trend" hint="Weekly messages (bars) and average sentiment (line)" className="lg:col-span-3">
                    <Chart
                      height={260}
                      data={[
                        { type: 'bar', x: c.timeline.map((t) => t.period), y: c.timeline.map((t) => t.n_messages), name: 'Messages', marker: { color: '#c7d2fe' } },
                        { type: 'scatter', mode: 'lines+markers', x: c.timeline.map((t) => t.period), y: c.timeline.map((t) => t.mean_sentiment), name: 'Avg sentiment', yaxis: 'y2', line: { color: '#4f46e5' } },
                      ]}
                      layout={{
                        yaxis: { title: 'Messages' },
                        yaxis2: { overlaying: 'y', side: 'right', range: [-1, 1], showgrid: false, title: 'Sentiment' },
                        margin: { l: 48, r: 48, t: 8, b: 60 },
                      }}
                    />
                  </Section>

                  <Section title="Keywords & topics" className="lg:col-span-2">
                    <p className="mb-1 text-xs font-medium text-slate-500">Distinctive keywords</p>
                    <Chips items={c.keywords} max={10} />
                    <p className="mb-1 mt-4 text-xs font-medium text-slate-500">Topics discussed</p>
                    <ul className="space-y-1.5 text-sm">
                      {c.topics.map((t) => (
                        <li key={t.id}>
                          <span className="font-medium text-slate-800">{t.label}</span>{' '}
                          <span className="text-xs text-slate-500">{(t.weight * 100).toFixed(0)}% · {t.keywords.slice(0, 3).join(', ')}</span>
                        </li>
                      ))}
                    </ul>
                  </Section>
                </>
              )}
            </Async>
          </div>

          <Section title="Similar games" hint="By content: genres, tags, description and community keywords" className="mt-6">
            <Async state={similar}>
              {(items) => (
                <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
                  {items.map((s) => (
                    <GameCard key={s.game.id} game={s.game}>
                      <p className="text-xs text-slate-500">
                        {(s.similarity * 100).toFixed(0)}% similar{s.shared.genres.length ? ` · shares ${s.shared.genres.join(', ')}` : ''}
                      </p>
                    </GameCard>
                  ))}
                </div>
              )}
            </Async>
          </Section>
        </>
      )}
    </Async>
  )
}
