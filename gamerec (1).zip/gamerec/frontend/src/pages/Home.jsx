import { Link } from 'react-router-dom'
import Chart from '../components/Chart'
import RecommendationCard from '../components/RecommendationCard'
import { Async, EmptyState, GameCard, PageHeader, Section, StatCard, StatusBadge } from '../components/ui'
import { useUser } from '../context/UserContext'
import { cap } from '../lib/format'
import { api } from '../services/api'
import { useApi } from '../services/useApi'

const STATUS_COLOR = { rising: '#10b981', stable: '#94a3b8', declining: '#f43f5e', 'insufficient data': '#f59e0b' }
const SENT_COLOR = { positive: '#22c55e', neutral: '#94a3b8', negative: '#f43f5e' }

export default function Home() {
  const { userId } = useUser()
  const overview = useApi(() => api.overview(), [])
  const recs = useApi(() => (userId ? api.recommendations(userId, { n: 3 }) : null), [userId])

  return (
    <>
      <PageHeader
        title="What the community is playing, and what fits you"
        subtitle="Recommendations combine your taste with what gaming communities are discussing and how they feel about it."
      />
      <Async state={overview}>
        {(o) => (
          <div className="space-y-6">
            <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
              <StatCard label="Games" value={o.meta.counts.games} />
              <StatCard label="Community messages" value={o.meta.counts.messages.toLocaleString()} hint={o.meta.is_demo ? 'synthetic demo data' : 'real community data'} />
              <StatCard label="Ratings" value={o.meta.counts.ratings.toLocaleString()} />
              <StatCard label="Trending topics" value={o.trending_topics.length} />
            </div>

            <Section title="Recommended for you" hint="Personalized, with the reasons behind each pick">
              {!userId ? (
                <EmptyState title="Choose a profile to see personal picks">
                  <Link className="btn btn-primary" to="/profile">Create or select a profile</Link>
                </EmptyState>
              ) : (
                <Async state={recs}>
                  {(r) => (
                    <div className="grid gap-4 md:grid-cols-3">
                      {r.items.map((item) => (
                        <RecommendationCard key={item.game.id} item={item} compact />
                      ))}
                    </div>
                  )}
                </Async>
              )}
              {userId && <Link to="/for-you" className="mt-3 inline-block text-sm font-medium text-brand-600">See all recommendations →</Link>}
            </Section>

            <div className="grid gap-6 lg:grid-cols-5">
              <Section title="Trending games" hint="Trend score: recent volume, growth vs. its own history, engagement" className="lg:col-span-3">
                <Chart
                  height={260}
                  data={[{
                    type: 'bar',
                    x: o.trending_games.map((g) => g.name),
                    y: o.trending_games.map((g) => g.trend_score),
                    marker: { color: o.trending_games.map((g) => STATUS_COLOR[g.status]) },
                    hovertemplate: '%{x}<br>trend %{y:.2f}<extra></extra>',
                  }]}
                  layout={{ yaxis: { range: [0, 1], title: 'Trend score' }, xaxis: { tickangle: -25 }, margin: { l: 48, r: 8, t: 8, b: 80 } }}
                />
                <div className="mt-2 flex flex-wrap gap-2">
                  {o.trending_games.map((g) => (
                    <Link key={g.id} to={`/games/${g.id}`} className="inline-flex items-center gap-1.5 text-xs text-slate-600 hover:text-brand-600">
                      {g.name} <StatusBadge status={g.status} />
                    </Link>
                  ))}
                </div>
              </Section>
              <Section title="Community sentiment" hint="Share of messages by sentiment" className="lg:col-span-2">
                <Chart
                  height={260}
                  data={[{
                    type: 'pie', hole: 0.55, sort: false,
                    labels: Object.keys(o.sentiment_distribution_pct).map(cap),
                    values: Object.values(o.sentiment_distribution_pct),
                    marker: { colors: Object.keys(o.sentiment_distribution_pct).map((k) => SENT_COLOR[k]) },
                  }]}
                  layout={{ margin: { l: 8, r: 8, t: 8, b: 8 }, showlegend: true }}
                />
              </Section>
            </div>

            <div className="grid gap-6 lg:grid-cols-2">
              <Section title="Trending topics" hint="Change in share of discussion, last 4 weeks vs. the 8 before">
                <ul className="divide-y divide-slate-100">
                  {o.trending_topics.map((t) => (
                    <li key={t.label} className="flex items-center justify-between gap-3 py-2 text-sm">
                      <div>
                        <p className="font-medium text-slate-800">{t.label}</p>
                        <p className="text-xs text-slate-500">{t.keywords.slice(0, 4).join(' · ')}</p>
                      </div>
                      <span className={`text-xs font-semibold ${t.change >= 0 ? 'text-emerald-600' : 'text-rose-600'}`}>
                        {t.change >= 0 ? '▲' : '▼'} {(Math.abs(t.change) * 100).toFixed(1)} pts
                      </span>
                    </li>
                  ))}
                </ul>
              </Section>
              <Section title="Popular genres" hint="Community messages about games in each genre">
                <Chart
                  height={260}
                  data={[{
                    type: 'bar', orientation: 'h',
                    y: [...o.genres].reverse().map((g) => g.genre),
                    x: [...o.genres].reverse().map((g) => g.n_messages),
                    marker: { color: '#6366f1' },
                  }]}
                  layout={{ margin: { l: 90, r: 8, t: 8, b: 32 }, xaxis: { title: 'Messages' } }}
                />
              </Section>
            </div>

            <Section title="Top community picks">
              <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
                {o.trending_games.slice(0, 3).map((g) => <GameCard key={g.id} game={g} />)}
              </div>
            </Section>
          </div>
        )}
      </Async>
    </>
  )
}
