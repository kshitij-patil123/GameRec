import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import Chart from '../components/Chart'
import { Async, EmptyState, PageHeader, Section, StarRating } from '../components/ui'
import { useUser } from '../context/UserContext'
import { api } from '../services/api'
import { useApi } from '../services/useApi'

const LEVELS = [['none', 'Off', null], ['low', 'Low', 0.2], ['medium', 'Medium', 0.5], ['high', 'High', 0.9]]
const levelOf = (v) => (v == null ? 'none' : v <= 0.3 ? 'low' : v <= 0.6 ? 'medium' : 'high')

function Create({ onCreated }) {
  const [name, setName] = useState('')
  const [err, setErr] = useState(null)
  async function submit(e) {
    e.preventDefault()
    setErr(null)
    try {
      onCreated(await api.createUser(name))
      setName('')
    } catch (x) {
      setErr(x.message)
    }
  }
  return (
    <form onSubmit={submit} className="flex flex-wrap items-center gap-2">
      <input className="input" placeholder="New profile name" aria-label="New profile name" value={name} maxLength={100} onChange={(e) => setName(e.target.value)} />
      <button className="btn btn-primary" disabled={!name.trim()}>Create profile</button>
      {err && <span role="alert" className="text-sm text-rose-600">{err}</span>}
    </form>
  )
}

function Preferences({ userId, profile, filters, onSaved }) {
  const [genres, setGenres] = useState([])
  const [tags, setTags] = useState([])
  const [aspects, setAspects] = useState({})
  const [status, setStatus] = useState(null)

  useEffect(() => {
    setGenres(profile.stated.genres)
    setTags(profile.stated.tags)
    setAspects(profile.stated.aspects || {})
  }, [profile])

  const toggle = (list, setList, v) => setList(list.includes(v) ? list.filter((x) => x !== v) : [...list, v])
  async function save() {
    setStatus(null)
    try {
      await api.setPreferences(userId, { genres, tags, aspects })
      setStatus('Preferences saved.')
      onSaved()
    } catch (e) {
      setStatus(e.message)
    }
  }
  const chip = (on) => `chip cursor-pointer ${on ? 'bg-brand-600 text-white' : 'hover:bg-slate-200'}`
  return (
    <Section title="Your preferences" hint="Used for new-user recommendations and blended with your ratings later">
      <p className="mb-1 text-xs font-medium text-slate-500">Favorite genres</p>
      <div className="mb-4 flex flex-wrap gap-1.5">
        {filters.genres.map((g) => <button key={g} type="button" aria-pressed={genres.includes(g)} className={chip(genres.includes(g))} onClick={() => toggle(genres, setGenres, g)}>{g}</button>)}
      </div>
      <p className="mb-1 text-xs font-medium text-slate-500">Preferred tags</p>
      <div className="mb-4 flex max-h-28 flex-wrap gap-1.5 overflow-auto">
        {filters.tags.map((t) => <button key={t} type="button" aria-pressed={tags.includes(t)} className={chip(tags.includes(t))} onClick={() => toggle(tags, setTags, t)}>{t}</button>)}
      </div>
      <p className="mb-1 text-xs font-medium text-slate-500">How much do you care about each aspect? (leave all Off to infer from your ratings)</p>
      <div className="grid gap-x-6 gap-y-2 sm:grid-cols-2">
        {filters.aspects.map((a) => (
          <div key={a} className="flex items-center justify-between gap-2 text-sm">
            <span className="capitalize">{a}</span>
            <div className="inline-flex overflow-hidden rounded-lg border border-slate-200 text-xs" role="group" aria-label={`${a} importance`}>
              {LEVELS.map(([k, label, v]) => (
                <button key={k} type="button" aria-pressed={levelOf(aspects[a]) === k}
                  className={`px-2 py-1 ${levelOf(aspects[a]) === k ? 'bg-brand-600 text-white' : 'bg-white hover:bg-slate-50'}`}
                  onClick={() => setAspects((cur) => { const n = { ...cur }; v == null ? delete n[a] : (n[a] = v); return n })}>
                  {label}
                </button>
              ))}
            </div>
          </div>
        ))}
      </div>
      <div className="mt-4 flex items-center gap-3">
        <button className="btn btn-primary" onClick={save}>Save preferences</button>
        {status && <span role="status" className="text-sm text-slate-600">{status}</span>}
      </div>
    </Section>
  )
}

function QuickRate({ userId, onRated }) {
  const [q, setQ] = useState('')
  const [results, setResults] = useState([])
  const [msg, setMsg] = useState(null)
  useEffect(() => {
    if (q.trim().length < 1) return setResults([])
    const t = setTimeout(() => api.search(q.trim()).then(setResults).catch(() => setResults([])), 250)
    return () => clearTimeout(t)
  }, [q])
  async function rate(game, rating) {
    try {
      await api.rate(userId, { game_id: game.id, rating })
      setMsg(`Rated ${game.name} ${rating}★`)
      onRated()
    } catch (e) {
      setMsg(e.message)
    }
  }
  return (
    <Section title="Rate games" hint="Rate a few games you know; three ratings switch on full personalization">
      <input className="input w-full" placeholder="Search a game to rate…" aria-label="Search a game to rate" value={q} onChange={(e) => setQ(e.target.value)} />
      <ul className="mt-2 divide-y divide-slate-100">
        {results.map((g) => (
          <li key={g.id} className="flex items-center justify-between py-2 text-sm">
            <span>{g.name} <span className="text-xs text-slate-400">{g.genres.join(', ')}</span></span>
            <StarRating onRate={(n) => rate(g, n)} />
          </li>
        ))}
      </ul>
      {msg && <p role="status" className="mt-2 text-sm text-emerald-700">{msg}</p>}
    </Section>
  )
}

export default function Profile() {
  const { userId, setUserId, refreshUsers } = useUser()
  const filters = useApi(() => api.filters(), [])
  const profile = useApi(() => (userId ? api.profile(userId) : null), [userId])
  const refresh = () => { profile.reload(); refreshUsers() }

  return (
    <>
      <PageHeader title="Profile" subtitle="Create a profile, tell GameRec what you like, rate a few games, then see recommendations.">
        <Create onCreated={(u) => { setUserId(u.id); refreshUsers() }} />
      </PageHeader>
      {!userId ? (
        <EmptyState title="Select a profile from the menu, or create one above" />
      ) : (
        <Async state={profile}>
          {(p) => (
            <div className="space-y-6">
              <div className="card flex flex-wrap items-center justify-between gap-3">
                <div>
                  <p className="text-lg font-semibold">{p.user.display_name}</p>
                  <p className="text-sm text-slate-500">{p.n_ratings} ratings · {p.cold_start ? 'cold start: recommendations lean on your stated preferences' : 'personalized from your ratings'}</p>
                </div>
                <Link to="/for-you" className="btn btn-primary">See my recommendations</Link>
              </div>

              <div className="grid gap-6 lg:grid-cols-2">
                <Async state={filters}>{(f) => <Preferences userId={userId} profile={p} filters={f} onSaved={refresh} />}</Async>
                <QuickRate userId={userId} onRated={refresh} />
              </div>

              <div className="grid gap-6 lg:grid-cols-2">
                <Section title="Preference profile" hint="Genre weights come from your ratings and picks; aspect priorities from your sliders or inferred from games you liked">
                  {p.genre_weights.length === 0 && p.aspect_preferences.length === 0 ? (
                    <EmptyState title="Nothing to show yet: pick genres or rate games" />
                  ) : (
                    <Chart height={280}
                      data={[
                        { type: 'bar', orientation: 'h', name: 'Genre', y: p.genre_weights.map((g) => `${g.name}`), x: p.genre_weights.map((g) => g.weight), marker: { color: '#6366f1' } },
                        { type: 'bar', orientation: 'h', name: 'Aspect priority', y: p.aspect_preferences.map((a) => `${a.name}`), x: p.aspect_preferences.map((a) => a.weight), marker: { color: '#ec4899' } },
                      ]}
                      layout={{ barmode: 'group', xaxis: { range: [0, 1], title: 'Strength (0–1)' }, yaxis: { autorange: 'reversed' }, margin: { l: 100, r: 8, t: 8, b: 70 } }} />
                  )}
                </Section>
                <Section title="Liked games">
                  {p.liked_games.length === 0 ? <EmptyState title="No liked games yet" /> : (
                    <ul className="divide-y divide-slate-100 text-sm">
                      {p.liked_games.map((g) => (
                        <li key={g.game_id} className="flex justify-between py-2">
                          <Link to={`/games/${g.game_id}`} className="font-medium hover:text-brand-600">{g.name}</Link>
                          <span className="text-amber-500">{g.rating ? '★'.repeat(Math.round(g.rating)) : 'liked'}</span>
                        </li>
                      ))}
                    </ul>
                  )}
                </Section>
              </div>

              <div className="grid gap-6 lg:grid-cols-2">
                <Section title="All ratings">
                  {p.ratings.length === 0 ? <EmptyState title="No ratings yet" /> : (
                    <table className="w-full text-sm">
                      <tbody>
                        {p.ratings.map((r) => (
                          <tr key={r.game_id} className="border-t border-slate-100 first:border-0">
                            <td className="py-1.5"><Link to={`/games/${r.game_id}`} className="hover:text-brand-600">{r.name}</Link></td>
                            <td className="text-right text-slate-500">{r.rating ?? r.interaction}{r.rating ? '★' : ''}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  )}
                </Section>
                <Section title="Recommendation history" hint="Your most recent recommendation lists (saved when you open the For you page)">
                  {p.recommendation_history.length === 0 ? <EmptyState title="Nothing yet: open the For you page" /> : (
                    <div className="space-y-3 text-sm">
                      {p.recommendation_history.map((h) => (
                        <div key={h.created_at}>
                          <p className="text-xs text-slate-400">{new Date(h.created_at + 'Z').toLocaleString()}</p>
                          <p>{h.items.map((i) => i.name).join(' · ')}</p>
                        </div>
                      ))}
                    </div>
                  )}
                </Section>
              </div>
            </div>
          )}
        </Async>
      )}
    </>
  )
}
