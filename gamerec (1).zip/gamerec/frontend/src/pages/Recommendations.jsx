import { useState } from 'react'
import { Link } from 'react-router-dom'
import Chart from '../components/Chart'
import RecommendationCard from '../components/RecommendationCard'
import { Async, EmptyState, PageHeader, Section } from '../components/ui'
import { useUser } from '../context/UserContext'
import { COMPONENT_META } from '../lib/format'
import { api } from '../services/api'
import { useApi } from '../services/useApi'

const KEYS = Object.keys(COMPONENT_META)

function WeightPanel({ applied, onApply, effective }) {
  const [draft, setDraft] = useState(applied || {})
  const value = (k) => draft[k] ?? effective?.[k] ?? 0
  return (
    <Section title="Model weights" hint="Weights are configurable starting values, not tuned truths. Set one to 0 to switch a signal off.">
      <div className="grid gap-x-6 gap-y-2 sm:grid-cols-2 lg:grid-cols-3">
        {KEYS.map((k) => (
          <label key={k} className="text-xs text-slate-600">
            <span className="flex justify-between">
              <span>{COMPONENT_META[k].label}</span>
              <b>{Number(value(k)).toFixed(2)}</b>
            </span>
            <input type="range" min="0" max="1" step="0.05" className="w-full accent-indigo-600" value={value(k)}
              aria-label={`${COMPONENT_META[k].label} weight`}
              onChange={(e) => setDraft({ ...Object.fromEntries(KEYS.map((x) => [x, value(x)])), [k]: Number(e.target.value) })} />
          </label>
        ))}
      </div>
      <div className="mt-3 flex gap-2">
        <button className="btn btn-primary" onClick={() => onApply(Object.keys(draft).length ? draft : null)}>Apply weights</button>
        <button className="btn btn-ghost" onClick={() => { setDraft({}); onApply(null) }}>Reset to defaults</button>
      </div>
    </Section>
  )
}

export default function Recommendations() {
  const { userId, refreshUsers } = useUser()
  const [weights, setWeights] = useState(null)
  const [busy, setBusy] = useState(false)
  const [note, setNote] = useState(null)
  const recs = useApi(
    () => (userId ? api.recommendations(userId, { n: 10, weights, save: true }) : null),
    [userId, JSON.stringify(weights)],
  )

  async function rate(gameId, body) {
    setBusy(true)
    setNote(null)
    try {
      await api.rate(userId, { game_id: gameId, ...body })
      setNote('Thanks! Your profile was updated and the list was refreshed.')
      refreshUsers()
      recs.reload()
    } catch (e) {
      setNote(e.message)
    } finally {
      setBusy(false)
    }
  }

  if (!userId) {
    return (
      <>
        <PageHeader title="Recommended for you" />
        <EmptyState title="Choose or create a profile first">
          <Link className="btn btn-primary" to="/profile">Go to profile</Link>
        </EmptyState>
      </>
    )
  }

  return (
    <>
      <PageHeader title="Recommended for you" subtitle="Content, similar players, your preferences, community sentiment, trends and aspects, combined and explained." />
      {note && <p role="status" className="mb-4 rounded-lg bg-emerald-50 px-3 py-2 text-sm text-emerald-700">{note}</p>}
      <Async state={recs}>
        {(r) => (
          <div className="space-y-6">
            {r.strategy !== 'hybrid' && (
              <p className="rounded-lg bg-brand-50 px-3 py-2 text-sm text-brand-700">
                {r.strategy === 'popular_trending'
                  ? 'You have no ratings or preferences yet, so these are popular and trending games. '
                  : r.strategy === 'catalog_fallback'
                    ? 'No personal or community signals are available yet, so games are listed by catalog rating. '
                    : 'You have fewer than 3 ratings, so recommendations lean on your stated preferences. '}
                <Link to="/profile" className="font-medium underline">Add preferences or rate games</Link> to personalize them.
              </p>
            )}
            <WeightPanel applied={weights} onApply={setWeights} effective={r.weights} />
            <Section title="Recommendation comparison" hint="How much each signal contributed to each game's score">
              <Chart
                height={Math.max(240, r.items.length * 34)}
                data={KEYS.filter((k) => r.items.some((i) => (i.contributions[k] || 0) > 0)).map((k) => ({
                  type: 'bar', orientation: 'h', name: COMPONENT_META[k].label, marker: { color: COMPONENT_META[k].color },
                  y: [...r.items].reverse().map((i) => i.game.name),
                  x: [...r.items].reverse().map((i) => (i.contributions[k] || 0) * 100),
                  hovertemplate: `${COMPONENT_META[k].label}: %{x:.1f} pts<extra></extra>`,
                }))}
                layout={{ barmode: 'stack', xaxis: { title: 'Score points' }, margin: { l: 130, r: 8, t: 8, b: 70 } }}
              />
            </Section>
            <div className="grid gap-4 lg:grid-cols-2">
              {r.items.map((item) => <RecommendationCard key={item.game.id} item={item} onRate={rate} busy={busy} />)}
            </div>
            <p className="text-xs text-slate-400">{r.note}</p>
          </div>
        )}
      </Async>
    </>
  )
}
