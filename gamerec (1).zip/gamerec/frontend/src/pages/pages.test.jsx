import { fireEvent, render, screen, waitFor, within } from '@testing-library/react'
import { MemoryRouter } from 'react-router-dom'
import { beforeEach, describe, expect, it, vi } from 'vitest'
import { UserProvider } from '../context/UserContext'

vi.mock('../components/Chart', () => ({ default: () => <div data-testid="chart" /> }))
vi.mock('../services/api', () => ({
  api: {
    users: vi.fn(), filters: vi.fn(), games: vi.fn(), recommendations: vi.fn(), rate: vi.fn(),
    createUser: vi.fn(), profile: vi.fn(), search: vi.fn(), setPreferences: vi.fn(),
  },
  ApiError: class extends Error {},
}))

import { api } from '../services/api'
import Explorer from './Explorer'
import Profile from './Profile'
import Recommendations from './Recommendations'

const game = (id, name) => ({ id, name, genres: ['RPG'], tags: [], platforms: ['PC'], community_score: 0.6, positive_pct: 70, rating: 4.2, status: 'rising' })
const rec = (id, name) => ({
  rank: id, game: game(id, name), score: 0.8, match_percent: 80, strategy: 'hybrid',
  components: { content: 1 }, contributions: { content: 0.5, trend: 0.3 },
  reasons: [{ type: 'content', text: `Similar to something (${name})`, positive: true }],
})
const renderPage = (ui) => render(<MemoryRouter><UserProvider>{ui}</UserProvider></MemoryRouter>)

beforeEach(() => {
  vi.clearAllMocks()
  localStorage.clear()
  api.users.mockResolvedValue([{ id: 1, display_name: 'Ana', n_ratings: 2 }])
  api.filters.mockResolvedValue({ genres: ['RPG', 'Racing'], platforms: ['PC'], tags: ['open world'], aspects: ['story', 'combat'] })
})

describe('Explorer', () => {
  it('lists games and sends the chosen genre filter to the API', async () => {
    api.games.mockResolvedValue({ items: [game(1, 'Ashen Crown')], total: 1, limit: 12, offset: 0 })
    renderPage(<Explorer />)
    expect(await screen.findByText('Ashen Crown')).toBeInTheDocument()
    fireEvent.change(screen.getByLabelText('Genre'), { target: { value: 'Racing' } })
    await waitFor(() => expect(api.games).toHaveBeenLastCalledWith(expect.objectContaining({ genre: 'Racing', offset: 0 })))
  })

  it('shows an empty state when nothing matches', async () => {
    api.games.mockResolvedValue({ items: [], total: 0, limit: 12, offset: 0 })
    renderPage(<Explorer />)
    expect(await screen.findByText('No games match these filters')).toBeInTheDocument()
  })
})

describe('Recommendations', () => {
  it('asks for a profile when none is selected', () => {
    renderPage(<Recommendations />)
    expect(screen.getByText('Choose or create a profile first')).toBeInTheDocument()
    expect(api.recommendations).not.toHaveBeenCalled()
  })

  it('shows explained recommendations, and rating one refreshes the list', async () => {
    localStorage.setItem('gamerec.userId', '1')
    api.recommendations.mockResolvedValue({ strategy: 'hybrid', weights: { content: 1 }, note: 'relative score', items: [rec(1, 'Blade'), rec(2, 'Tidebound')] })
    api.rate.mockResolvedValue({})
    renderPage(<Recommendations />)
    expect(await screen.findByText(/Similar to something \(Blade\)/)).toBeInTheDocument()
    expect(api.recommendations).toHaveBeenCalledWith(1, expect.objectContaining({ save: true }))
    fireEvent.click(screen.getAllByLabelText('5 stars')[0])
    await waitFor(() => expect(api.rate).toHaveBeenCalledWith(1, { game_id: 1, rating: 5 }))
    await waitFor(() => expect(api.recommendations).toHaveBeenCalledTimes(2))
    expect(await screen.findByText(/profile was updated/)).toBeInTheDocument()
  })

  it('explains the cold-start strategy', async () => {
    localStorage.setItem('gamerec.userId', '1')
    api.recommendations.mockResolvedValue({ strategy: 'popular_trending', weights: {}, note: '', items: [rec(1, 'Blade')] })
    renderPage(<Recommendations />)
    expect(await screen.findByText(/popular and trending games/)).toBeInTheDocument()
  })

  it('surfaces API errors with the server message', async () => {
    localStorage.setItem('gamerec.userId', '1')
    api.recommendations.mockRejectedValue(Object.assign(new Error('No games loaded yet.'), { status: 503 }))
    renderPage(<Recommendations />)
    expect(await screen.findByRole('alert')).toHaveTextContent('No games loaded yet.')
  })
})

describe('Profile', () => {
  it('creates and selects a new profile', async () => {
    api.createUser.mockResolvedValue({ id: 9, display_name: 'Kay', n_ratings: 0 })
    api.profile.mockResolvedValue({
      user: { id: 9, display_name: 'Kay' }, n_ratings: 0, cold_start: true, ratings: [], liked_games: [],
      favorite_games: [], stated: { genres: [], tags: [], aspects: {} }, favorite_genres: [], preferred_tags: [],
      aspect_preferences: [], genre_weights: [], recommendation_history: [],
    })
    renderPage(<Profile />)
    fireEvent.change(screen.getByLabelText('New profile name'), { target: { value: 'Kay' } })
    fireEvent.click(screen.getByText('Create profile'))
    await waitFor(() => expect(api.createUser).toHaveBeenCalledWith('Kay'))
    expect(await screen.findByText(/cold start/)).toBeInTheDocument()
    expect(localStorage.getItem('gamerec.userId')).toBe('9')
  })

  it('saves selected genres and aspect levels', async () => {
    localStorage.setItem('gamerec.userId', '1')
    api.setPreferences.mockResolvedValue({ status: 'saved' })
    api.profile.mockResolvedValue({
      user: { id: 1, display_name: 'Ana' }, n_ratings: 5, cold_start: false, ratings: [], liked_games: [],
      favorite_games: [], stated: { genres: [], tags: [], aspects: {} }, favorite_genres: [], preferred_tags: [],
      aspect_preferences: [], genre_weights: [], recommendation_history: [],
    })
    renderPage(<Profile />)
    fireEvent.click(await screen.findByRole('button', { name: 'RPG' }))
    fireEvent.click(within(screen.getByRole('group', { name: 'story importance' })).getByText('High'))
    fireEvent.click(screen.getByText('Save preferences'))
    await waitFor(() => expect(api.setPreferences).toHaveBeenCalledWith(1, { genres: ['RPG'], tags: [], aspects: { story: 0.9 } }))
  })
})
