const BASE = (import.meta.env.VITE_API_URL || 'http://localhost:8000').replace(/\/$/, '')

export class ApiError extends Error {
  constructor(status, message) {
    super(message)
    this.status = status
  }
}

function describe(body, status) {
  if (body?.errors?.length) return body.errors.map((e) => `${e.field}: ${e.message}`).join('; ')
  if (typeof body?.detail === 'string') return body.detail
  return `Request failed (${status})`
}

export async function request(path, { method = 'GET', body, params } = {}) {
  const url = new URL(BASE + path)
  Object.entries(params || {}).forEach(([k, v]) => {
    if (v !== undefined && v !== null && v !== '') url.searchParams.set(k, v)
  })
  let res
  try {
    res = await fetch(url, {
      method,
      headers: body ? { 'Content-Type': 'application/json' } : undefined,
      body: body ? JSON.stringify(body) : undefined,
    })
  } catch {
    throw new ApiError(0, `Cannot reach the API at ${BASE}. Is the backend running?`)
  }
  const data = await res.json().catch(() => null)
  if (!res.ok) throw new ApiError(res.status, describe(data, res.status))
  return data
}

export const api = {
  meta: () => request('/meta'),
  overview: () => request('/analytics/overview'),
  games: (params) => request('/games', { params }),
  search: (q) => request('/games/search', { params: { q } }),
  filters: () => request('/games/filters'),
  game: (id) => request(`/games/${id}`),
  similar: (id) => request(`/games/${id}/similar`),
  community: (id) => request(`/games/${id}/community-analysis`),
  trendingGames: (limit = 10) => request('/trending/games', { params: { limit } }),
  trendingTopics: (limit = 8) => request('/trending/topics', { params: { limit } }),
  sentiment: () => request('/analytics/sentiment'),
  topics: () => request('/analytics/topics'),
  aspects: () => request('/analytics/aspects'),
  keywords: () => request('/analytics/keywords'),
  activity: () => request('/analytics/activity'),
  users: () => request('/users'),
  createUser: (display_name) => request('/users', { method: 'POST', body: { display_name } }),
  rate: (userId, body) => request(`/users/${userId}/ratings`, { method: 'POST', body }),
  setPreferences: (userId, body) => request(`/users/${userId}/preferences`, { method: 'POST', body }),
  profile: (userId) => request(`/users/${userId}/profile`),
  recommendations: (userId, { n = 10, weights, save } = {}) =>
    request(`/recommendations/${userId}`, {
      params: { n, weights: weights ? JSON.stringify(weights) : undefined, save: save ? 'true' : undefined },
    }),
  explain: (userId, gameId) => request(`/recommendations/${userId}/explain/${gameId}`),
}
