import { afterEach, describe, expect, it, vi } from 'vitest'
import { api, ApiError, request } from './api'

const respond = (status, body) => Promise.resolve({ ok: status < 400, status, json: () => Promise.resolve(body) })
afterEach(() => vi.restoreAllMocks())

describe('request', () => {
  it('sends params, skipping empty ones', async () => {
    const f = vi.spyOn(globalThis, 'fetch').mockImplementation(() => respond(200, []))
    await api.games({ q: '', genre: 'RPG', min_rating: undefined, limit: 12 })
    const url = new URL(f.mock.calls[0][0])
    expect(url.pathname).toBe('/games')
    expect(Object.fromEntries(url.searchParams)).toEqual({ genre: 'RPG', limit: '12' })
  })

  it('posts JSON bodies', async () => {
    const f = vi.spyOn(globalThis, 'fetch').mockImplementation(() => respond(201, { id: 1 }))
    await api.rate(7, { game_id: 3, rating: 5 })
    const [url, init] = f.mock.calls[0]
    expect(new URL(url).pathname).toBe('/users/7/ratings')
    expect(init.method).toBe('POST')
    expect(JSON.parse(init.body)).toEqual({ game_id: 3, rating: 5 })
  })

  it('turns validation errors into readable messages', async () => {
    vi.spyOn(globalThis, 'fetch').mockImplementation(() =>
      respond(422, { detail: 'Validation failed', errors: [{ field: 'rating', message: 'must be <= 5' }] }))
    await expect(request('/x')).rejects.toMatchObject({ status: 422, message: 'rating: must be <= 5' })
  })

  it('surfaces string details and 503s', async () => {
    vi.spyOn(globalThis, 'fetch').mockImplementation(() => respond(503, { detail: 'No games loaded yet.' }))
    await expect(request('/x')).rejects.toMatchObject({ status: 503, message: 'No games loaded yet.' })
  })

  it('explains an unreachable API', async () => {
    vi.spyOn(globalThis, 'fetch').mockRejectedValue(new TypeError('failed'))
    const err = await request('/x').catch((e) => e)
    expect(err).toBeInstanceOf(ApiError)
    expect(err.status).toBe(0)
    expect(err.message).toMatch(/Is the backend running/)
  })

  it('serializes recommendation weights and save flag', async () => {
    const f = vi.spyOn(globalThis, 'fetch').mockImplementation(() => respond(200, {}))
    await api.recommendations(4, { n: 5, weights: { content: 1 }, save: true })
    const url = new URL(f.mock.calls[0][0])
    expect(url.searchParams.get('weights')).toBe('{"content":1}')
    expect(url.searchParams.get('save')).toBe('true')
  })
})
