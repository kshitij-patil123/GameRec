import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import tailwindcss from '@tailwindcss/vite'

export default defineConfig({
  plugins: [react(), tailwindcss()],
  server: { port: 5173 },
  // Plotly is lazy-loaded in its own chunk (~1.1 MB); the app shell stays small.
  build: { chunkSizeWarningLimit: 1300 },
  test: { environment: 'jsdom', globals: true, setupFiles: './src/setupTests.js' },
})
