"""Evaluate sentiment models on a LABELED dataset (columns: text + label).

Usage:
  python ml/evaluation/eval_sentiment.py --labels data/raw/labeled_sentiment.csv
  python ml/evaluation/eval_sentiment.py --labels ... --with-transformer

Method: stratified 80/20 split (seed 42). TF-IDF+LogReg trains on the 80% train split;
VADER and the transformer need no training but are scored on the SAME test split.
Metrics: accuracy, macro precision/recall/F1, per-class report, confusion matrix.
Results are written to data/processed/sentiment_eval.json.

Labels must come from human annotation (or a public labeled dataset). The synthetic demo
file's `demo_label` column is template-generated, so running on it is only a code smoke test.
"""
import argparse
import json
import sys
from pathlib import Path

import pandas as pd
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix, precision_recall_fscore_support
from sklearn.model_selection import train_test_split

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "backend"))
from app.nlp.preprocessing import preprocess_frame  # noqa: E402
from app.nlp.sentiment import LABELS, TfidfLogRegModel, TransformerModel, VaderModel  # noqa: E402


def evaluate(y_true: list[str], y_pred: list[str]) -> dict:
    p, r, f1, _ = precision_recall_fscore_support(y_true, y_pred, labels=LABELS, average="macro", zero_division=0)
    return {
        "accuracy": accuracy_score(y_true, y_pred),
        "macro_precision": p, "macro_recall": r, "macro_f1": f1,
        "per_class": classification_report(y_true, y_pred, labels=LABELS, output_dict=True, zero_division=0),
        "confusion_matrix": {"labels": LABELS, "matrix": confusion_matrix(y_true, y_pred, labels=LABELS).tolist()},
    }


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--labels", default=str(ROOT / "data" / "sample" / "messages.csv"))
    ap.add_argument("--text-col", default="text")
    ap.add_argument("--label-col", default="demo_label")
    ap.add_argument("--with-transformer", action="store_true")
    ap.add_argument("--out", default=str(ROOT / "data" / "processed" / "sentiment_eval.json"))
    args = ap.parse_args()

    synthetic = "sample" in Path(args.labels).parts
    df = pd.read_csv(args.labels).dropna(subset=[args.text_col, args.label_col])
    df = preprocess_frame(df, text_col=args.text_col)
    df = df[df["is_valid"] & ~df["is_duplicate"]]
    df = df[df[args.label_col].isin(LABELS)]
    train, test = train_test_split(df, test_size=0.2, stratify=df[args.label_col], random_state=42)

    models = {"vader": VaderModel(),
              "tfidf_logreg": TfidfLogRegModel().fit(train["text_clean"].tolist(), train[args.label_col].tolist())}
    if args.with_transformer:
        models["transformer"] = TransformerModel()

    results = {"dataset": args.labels, "n_train": len(train), "n_test": len(test),
               "synthetic_labels": synthetic, "models": {}}
    for name, model in models.items():
        preds = [lab for lab, _ in model.predict(test["text_original"].tolist(), test["text_clean"].tolist())]
        results["models"][name] = evaluate(test[args.label_col].tolist(), preds)
        m = results["models"][name]
        print(f"{name:14s} acc={m['accuracy']:.3f} macroF1={m['macro_f1']:.3f}")
        print("  confusion (rows=true, cols=pred):", LABELS, m["confusion_matrix"]["matrix"])
    if synthetic:
        print("\nWARNING: labels are template-generated synthetic data. This run only smoke-tests the "
              "code; do NOT report these numbers as results.")
    Path(args.out).parent.mkdir(parents=True, exist_ok=True)
    Path(args.out).write_text(json.dumps(results, indent=2))
    print("saved ->", args.out)


if __name__ == "__main__":
    main()
