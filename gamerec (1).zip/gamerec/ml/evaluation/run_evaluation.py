"""Run the recommendation evaluation against the configured database.

Usage:
  python ml/evaluation/run_evaluation.py [--k 5 10] [--tune-trials 60] [--seed 42] [--threshold 4]

Needs the pipeline to have run (scripts/run_pipeline.py). Writes:
  data/processed/evaluation/eval_results.json
  data/processed/evaluation/evaluation_report.md   (synthetic data gets a warning banner)
Results are only meaningful on real ratings; see docs/evaluation.md.
"""
import argparse
import json
import sys
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "backend"))
from sqlalchemy import select  # noqa: E402

from app.core.db import SessionLocal  # noqa: E402
from app.evaluation.experiments import context_from_bundle, run_evaluation  # noqa: E402
from app.evaluation.report import render_markdown  # noqa: E402
from app.models import Rating  # noqa: E402
from app.recommender.collaborative import implicit_rating  # noqa: E402
from app.services.query_service import data_meta  # noqa: E402
from app.services.recommendation_service import build_bundle  # noqa: E402


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--k", type=int, nargs="+", default=[5, 10])
    ap.add_argument("--tune-trials", type=int, default=60)
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--threshold", type=float, default=4.0)
    ap.add_argument("--bootstrap", type=int, default=2000)
    args = ap.parse_args()

    with SessionLocal() as db:
        bundle = build_bundle(db)
        rows = db.execute(select(Rating.user_id, Rating.game_id, Rating.rating, Rating.interaction,
                                 Rating.created_at)).all()
        synthetic = data_meta(db)["is_demo"]
    df = pd.DataFrame(rows, columns=["user_id", "game_id", "rating", "interaction", "created_at"])
    df["rating"] = [implicit_rating(r, i) for r, i in zip(df["rating"], df["interaction"])]

    results = run_evaluation(context_from_bundle(bundle), df, ks=args.k, threshold=args.threshold,
                             tune_trials=args.tune_trials, seed=args.seed, n_boot=args.bootstrap)
    results["synthetic_data"] = synthetic
    out = ROOT / "data" / "processed" / "evaluation"
    out.mkdir(parents=True, exist_ok=True)
    (out / "eval_results.json").write_text(json.dumps(results, indent=2))
    (out / "evaluation_report.md").write_text(render_markdown(results, synthetic))
    print(render_markdown(results, synthetic))
    print("saved ->", out)


if __name__ == "__main__":
    main()
