"""Container start-up: create tables and, ONLY if the database has no games yet, load + analyze data.
Safe to run on every start. With DATA_SOURCE=demo it generates the synthetic sample files if they are missing."""
import logging
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "backend"))
sys.path.insert(0, str(ROOT / "scripts"))
from sqlalchemy import func, select  # noqa: E402

from app.core.config import get_settings  # noqa: E402
from app.core.db import Base, SessionLocal, engine  # noqa: E402
import app.models  # noqa: E402,F401
from app.models import Game  # noqa: E402

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    Base.metadata.create_all(engine)
    with SessionLocal() as db:
        has_games = db.scalar(select(func.count()).select_from(Game)) > 0
    if has_games:
        print("Database already populated; skipping pipeline.")
    else:
        source = get_settings().data_source
        if source == "demo" and not (ROOT / "data" / "sample" / "games.csv").exists():
            import generate_demo_data
            generate_demo_data.main()
        import run_pipeline
        run_pipeline.run(source)
