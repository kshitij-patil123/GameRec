"""Try the content recommender. Usage: python scripts/demo_content.py "Ashen Crown" """
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "backend"))
from sqlalchemy import select  # noqa: E402

from app.core.db import SessionLocal  # noqa: E402
from app.models import Game  # noqa: E402
from app.services.content_service import build_content_recommender  # noqa: E402

if __name__ == "__main__":
    name = sys.argv[1] if len(sys.argv) > 1 else "Ashen Crown"
    with SessionLocal() as db:
        rec = build_content_recommender(db)
        names = {g.id: g for g in db.scalars(select(Game))}
        gid = next(g.id for g in names.values() if g.name == name)
        print(f"Games similar to {name} ({', '.join(x.name for x in names[gid].genres)}):")
        for other, score in rec.similar_games(gid, 5):
            print(f"  {score:.2f}  {names[other].name}  [{', '.join(x.name for x in names[other].genres)}]")
        print("\nCold start, prefers RPG + open world + story rich:")
        for other, score in rec.recommend_for_preferences(["RPG"], ["open world", "story rich"], n=5):
            print(f"  {score:.2f}  {names[other].name}")
