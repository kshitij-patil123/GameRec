"""Show hybrid recommendations with explanations.
Needs: load_data, run_sentiment vader, run_analysis aspects, run_trends.
Usage: python scripts/demo_recommend.py"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "backend"))
from app.core.db import SessionLocal  # noqa: E402
from app.models import User, UserPreference  # noqa: E402
from app.services.recommendation_service import build_bundle, recommend_for_user  # noqa: E402


def show(title, recs):
    print(f"\n=== {title} ===")
    for r in recs:
        print(f"{r.match_percent:3d}%  {r.name}  [{r.strategy}]")
        for x in r.reasons:
            print("      " + ("✓ " if x["positive"] else "! ") + x["text"])


if __name__ == "__main__":
    with SessionLocal() as db:
        bundle = build_bundle(db)
        # brand-new user who only stated preferences (cold start)
        new = User(external_id="demo-new", display_name="New user")
        db.add(new); db.flush()
        db.add_all([UserPreference(user_id=new.id, kind="genre", key="RPG"),
                    UserPreference(user_id=new.id, kind="tag", key="story rich"),
                    UserPreference(user_id=new.id, kind="aspect", key="story", value=0.9),
                    UserPreference(user_id=new.id, kind="aspect", key="exploration", value=0.9)])
        blank = User(external_id="demo-blank", display_name="Blank user")
        db.add(blank); db.commit()
        show("Existing user 1 (rating history)", recommend_for_user(db, bundle, 1, n=3))
        show("New user: stated RPG / story rich / story+exploration", recommend_for_user(db, bundle, new.id, n=3))
        show("Blank user: no signal at all", recommend_for_user(db, bundle, blank.id, n=3))
