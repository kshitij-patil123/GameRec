"""Generate SYNTHETIC demo data (games are fictional, messages are template-based).

Nothing here is real Discord or Steam data. The `demo_label` column is the template's
intended sentiment; it exists only to smoke-test the pipeline and must NOT be used to
report model accuracy.
"""
import math
import random
from datetime import datetime, timedelta
from pathlib import Path

import pandas as pd

SEED = 42
OUT = Path(__file__).resolve().parents[1] / "data" / "sample"
ASPECTS = ["story", "graphics", "combat", "difficulty", "performance",
           "multiplayer", "music", "price", "bugs", "exploration"]

# name, genres, tags, platform, year, blurb, {aspect: P(positive)}, trend(-1..1)
GAMES = [
 ("Ashen Crown", "RPG|Action", "open world|story rich|dark fantasy", "PC|PS5", 2024, "A grim open-world RPG about a fallen kingdom.", dict(story=.9, graphics=.85, combat=.7, exploration=.9, performance=.4), .6),
 ("Star Drifters", "Sci-Fi|Adventure", "space|exploration|story rich", "PC|Xbox", 2023, "Explore a procedurally shaped galaxy with a crew.", dict(story=.7, exploration=.9, graphics=.8, bugs=.3), .2),
 ("Neon Circuit", "Racing|Arcade", "cyberpunk|fast paced|multiplayer", "PC|Switch", 2022, "Arcade street racing through neon cities.", dict(graphics=.9, multiplayer=.8, music=.9, difficulty=.5), -.3),
 ("Hollow Depths", "Action|Platformer", "metroidvania|difficult|atmospheric", "PC|Switch", 2021, "A hand-drawn descent into a ruined underground world.", dict(difficulty=.4, music=.95, graphics=.9, combat=.8), -.1),
 ("Tactica Wars", "Strategy", "turn based|multiplayer|competitive", "PC", 2023, "Deep turn-based tactics with ranked play.", dict(multiplayer=.7, difficulty=.6, price=.5, bugs=.5), .1),
 ("Verdant Valley", "Simulation|Casual", "farming|relaxing|co-op", "PC|Switch|Mobile", 2024, "A cozy farming life sim with friends.", dict(music=.9, multiplayer=.8, price=.85, performance=.8), .5),
 ("Iron Bastion", "Shooter|Action", "fps|multiplayer|competitive", "PC|PS5|Xbox", 2022, "Team-based tactical shooter.", dict(multiplayer=.6, combat=.8, performance=.5, bugs=.3, price=.4), -.5),
 ("Lantern Keeper", "Puzzle|Adventure", "atmospheric|story rich|relaxing", "PC|Switch|Mobile", 2020, "A gentle puzzle adventure about a lighthouse keeper.", dict(story=.9, music=.9, graphics=.8, difficulty=.7), -.2),
 ("Blade of Aeons", "RPG|Action", "hack and slash|difficult|story rich", "PC|PS5", 2024, "Fast, demanding melee combat across time.", dict(combat=.95, difficulty=.45, story=.75, performance=.5, bugs=.4), .7),
 ("Kingdom Forge", "Strategy|Simulation", "city builder|management|relaxing", "PC", 2021, "Build and manage a medieval kingdom.", dict(graphics=.6, difficulty=.7, price=.7, bugs=.6), -.1),
 ("Skyward Isles", "Adventure|Open World", "exploration|open world|relaxing", "PC|Switch", 2023, "Glide between floating islands.", dict(exploration=.95, graphics=.9, story=.6, performance=.7), .3),
 ("Dead Signal", "Horror|Survival", "atmospheric|co-op|difficult", "PC|PS5", 2022, "Survive an abandoned research station.", dict(graphics=.8, multiplayer=.6, difficulty=.5, bugs=.4, story=.7), .0),
 ("Pixel Brawlers", "Fighting|Arcade", "competitive|multiplayer|retro", "PC|Switch", 2020, "Retro fighting game with rollback netcode.", dict(multiplayer=.85, combat=.85, price=.8, music=.8), -.4),
 ("Mythic Legends", "RPG|Strategy", "card game|competitive|multiplayer", "PC|Mobile", 2023, "Collectible card battler with seasonal updates.", dict(multiplayer=.6, price=.3, difficulty=.6, bugs=.5), .2),
 ("Tidebound", "Survival|Open World", "crafting|co-op|exploration", "PC|Xbox", 2024, "Build and survive on an endless ocean.", dict(exploration=.85, multiplayer=.85, performance=.35, bugs=.3, price=.7), .8),
 ("Echoes of Elyra", "RPG|Adventure", "story rich|jrpg|turn based", "PC|PS5|Switch", 2021, "A character-driven JRPG.", dict(story=.95, music=.95, combat=.6, graphics=.75), -.2),
 ("Turbo Kart Rally", "Racing|Casual", "multiplayer|fast paced|co-op", "PC|Switch", 2019, "Party kart racing.", dict(multiplayer=.85, graphics=.65, price=.75, difficulty=.7), -.6),
 ("Shadow Protocol", "Action|Stealth", "stealth|story rich|cyberpunk", "PC|PS5|Xbox", 2023, "Infiltrate megacorp towers.", dict(story=.8, combat=.7, graphics=.85, performance=.55, bugs=.45), .1),
 ("Frostpeak", "Survival|Strategy", "difficult|city builder|management", "PC", 2022, "Lead a city through an endless winter.", dict(difficulty=.5, story=.8, graphics=.8, price=.7), .0),
 ("Wild Frontier Online", "MMORPG|Open World", "multiplayer|open world|co-op", "PC", 2020, "Persistent western MMO.", dict(multiplayer=.6, exploration=.75, bugs=.35, performance=.4, price=.4), -.7),
 ("Cobalt Skies", "Simulation|Adventure", "flight|exploration|relaxing", "PC|Xbox", 2022, "Relaxed flight simulation.", dict(graphics=.9, exploration=.8, difficulty=.65, performance=.5), .1),
 ("Rune Tactics", "Strategy|RPG", "turn based|story rich|difficult", "PC|Switch", 2024, "Tactical RPG with permanent consequences.", dict(story=.8, combat=.8, difficulty=.55, music=.7), .5),
 ("Bounce Galaxy", "Platformer|Casual", "colorful|co-op|family friendly", "Switch|Mobile", 2021, "Bright co-op platformer.", dict(music=.85, multiplayer=.8, graphics=.8, difficulty=.7), -.1),
 ("Grave Hunters", "Action|Horror", "hack and slash|co-op|dark fantasy", "PC|PS5", 2023, "Hunt monsters with friends.", dict(combat=.85, multiplayer=.75, bugs=.4, performance=.5, story=.5), .3),
]
PHRASES = {"story": "story", "graphics": "graphics", "combat": "combat", "difficulty": "difficulty curve",
           "performance": "performance", "multiplayer": "multiplayer", "music": "soundtrack",
           "price": "price", "bugs": "bugs", "exploration": "exploration"}
POS = ["the {a} in {g} is honestly amazing", "loving the {a} in {g}, well done devs",
       "{g} {a} blew me away", "{a} in {g} is so good right now :)", "100% recommend {g} just for the {a}"]
NEG = ["the {a} in {g} is really disappointing", "{g} {a} is a mess right now",
       "cannot stand the {a} in {g}", "{a} in {g} needs serious fixing", "{g} {a} ruined it for me :("]
NEU = ["anyone tried {g}? curious how the {a} is", "{g} {a} is okay i guess, nothing special",
       "playing {g} tonight, thoughts on the {a}?", "{a} in {g} is fine, not great not bad"]
EXTRA = ["", "", "", " lol", " 🔥", " https://example.com/clip", " tbh"]


def main() -> None:
    rng = random.Random(SEED)
    OUT.mkdir(parents=True, exist_ok=True)
    end = datetime(2026, 9, 1)
    days = 180

    games = pd.DataFrame([{
        "game_id": i + 1, "game_name": g[0], "description": g[5], "genre": g[1], "tags": g[2],
        "platform": g[3], "developer": f"Demo Studio {i % 7 + 1}", "publisher": f"Demo Pub {i % 4 + 1}",
        "release_date": f"{g[4]}-06-01", "rating": round(rng.uniform(3.4, 4.8), 2),
    } for i, g in enumerate(GAMES)])

    msgs, mid = [], 1
    for gid, g in enumerate(GAMES, 1):
        prof, trend = g[6], g[7]
        n = rng.randint(50, 110)
        for _ in range(n):
            # rejection-sample a day so message rate ramps up (trend > 0) or down (trend < 0) over time;
            # x = 0 is the oldest day, x = 1 the newest
            while True:
                x = rng.random()
                if rng.random() < math.exp(4 * trend * (x - (1 if trend > 0 else 0))):
                    break
            ts = end - timedelta(days=days * (1 - x), minutes=rng.randint(0, 1439))
            a = rng.choice(list(prof))
            r = rng.random()
            p = prof[a]
            if r < p * 0.8:
                tpl, lab = rng.choice(POS), "positive"
            elif r > 1 - (1 - p) * 0.6:
                tpl, lab = rng.choice(NEG), "negative"
            else:
                tpl, lab = rng.choice(NEU), "neutral"
            text = tpl.format(g=g[0], a=PHRASES[a]) + rng.choice(EXTRA)
            msgs.append(dict(message_id=f"demo-{mid}", game_id=gid, user_id=f"u{rng.randint(1, 80)}",
                             text=text, timestamp=ts.isoformat(timespec="seconds"),
                             engagement=rng.randint(0, 25), demo_label=lab, demo_aspect=a))
            mid += 1
    # deliberate messy rows to exercise preprocessing / edge cases
    for text in ["", "   ", "!!!", "👍"]:
        msgs.append(dict(message_id=f"demo-{mid}", game_id=1, user_id="u1", text=text,
                         timestamp=end.isoformat(timespec="seconds"), engagement=0,
                         demo_label="neutral", demo_aspect=""))
        mid += 1
    dup = dict(msgs[0]); dup["message_id"] = f"demo-{mid}"; msgs.append(dup)
    messages = pd.DataFrame(msgs)

    # users with genre affinities -> ratings
    genres = sorted({x for g in GAMES for x in g[1].split("|")})
    rows = []
    for uid in range(1, 81):
        liked = set(rng.sample(genres, 3))
        for gid in rng.sample(range(1, len(GAMES) + 1), rng.randint(5, 12)):
            match = len(liked & set(GAMES[gid - 1][1].split("|")))
            rating = max(1, min(5, round(2.6 + 1.0 * match + rng.gauss(0, .7))))
            inter = "liked" if rating >= 4 else "disliked" if rating <= 2 else "played"
            ts = end - timedelta(days=rng.randint(0, days))
            rows.append(dict(user_id=f"u{uid}", game_id=gid, rating=rating, interaction=inter,
                             timestamp=ts.isoformat(timespec="seconds")))
    ratings = pd.DataFrame(rows)

    games.to_csv(OUT / "games.csv", index=False)
    messages.to_csv(OUT / "messages.csv", index=False)
    ratings.to_csv(OUT / "ratings.csv", index=False)
    print(f"games={len(games)} messages={len(messages)} ratings={len(ratings)} -> {OUT}")


if __name__ == "__main__":
    main()
