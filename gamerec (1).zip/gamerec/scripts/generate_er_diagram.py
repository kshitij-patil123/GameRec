"""Generate the ER diagram (Mermaid) straight from the SQLAlchemy models, so it can never drift from the schema.
Usage: python scripts/generate_er_diagram.py  -> docs/diagrams/er_diagram.mmd (full), er_core.mmd, er_text.mmd"""
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "backend"))
from app.core.db import Base  # noqa: E402
import app.models  # noqa: E402,F401


def mermaid_type(col) -> str:
    return str(col.type).split("(")[0].replace(" ", "_").lower()


def generate(only: set[str] | None = None) -> str:
    """Mermaid ER text for all tables, or only the named ones (relationships between them)."""
    tables = [t for t in Base.metadata.sorted_tables if only is None or t.name in only]
    names = {t.name for t in tables}
    lines = ["erDiagram"]
    for table in tables:
        for fk in table.foreign_keys:
            parent = fk.column.table.name
            if parent not in names:
                continue
            # a PK that is also the FK (e.g. game_scores.game_id) is a 1:1 extension of the parent
            one_to_one = fk.parent.primary_key and len(table.primary_key.columns) == 1
            rel = "||--o|" if one_to_one else "||--o{"
            lines.append(f'    {parent} {rel} {table.name} : "{fk.parent.name}"')
    for table in tables:
        lines.append(f"    {table.name} {{")
        fks = {c.name for c in table.columns if c.foreign_keys}
        for col in table.columns:
            tag = "PK" if col.primary_key else ("FK" if col.name in fks else "")
            lines.append(f"        {mermaid_type(col)} {col.name} {tag}".rstrip())
        lines.append("    }")
    return "\n".join(lines) + "\n"


GROUPS = {
    "er_diagram": None,  # everything
    "er_core": {"games", "genres", "tags", "game_genres", "game_tags", "users", "ratings", "user_preferences",
                "recommendations", "game_scores"},
    "er_text": {"games", "messages", "sentiment_results", "aspect_sentiments", "topics", "game_topics",
                "message_topics"},
}

if __name__ == "__main__":
    for name, tables in GROUPS.items():
        out = ROOT / "docs" / "diagrams" / f"{name}.mmd"
        out.write_text(generate(tables))
        print(f"wrote {out}")
