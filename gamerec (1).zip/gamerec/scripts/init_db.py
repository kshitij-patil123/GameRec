import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "backend"))
from app.core.db import Base, engine  # noqa: E402
import app.models  # noqa: E402,F401

if __name__ == "__main__":
    Base.metadata.create_all(engine)
    print("Tables created:", ", ".join(Base.metadata.tables))
