"""Usage: python scripts/load_data.py [demo|public|discord_export]  (default: DATA_SOURCE)"""
import logging
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "backend"))
from app.core.db import SessionLocal  # noqa: E402
from app.ingestion.loader import load_source  # noqa: E402
from app.ingestion.sources import get_source  # noqa: E402

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    source = get_source(sys.argv[1] if len(sys.argv) > 1 else None)
    with SessionLocal() as db:
        print(load_source(db, source))
