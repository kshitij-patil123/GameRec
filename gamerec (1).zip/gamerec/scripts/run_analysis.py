"""Usage: python scripts/run_analysis.py [keywords|topics|aspects|all]  (default all)
Requires data loaded (load_data.py). Writes data/processed/keywords.json."""
import json
import logging
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "backend"))
from sqlalchemy import select  # noqa: E402

from app.analytics.keywords import distinctive_keywords, emerging_keywords, name_stopwords, top_keywords  # noqa: E402
from app.core.db import SessionLocal  # noqa: E402
from app.models import Game  # noqa: E402
from app.nlp.sentiment import VaderModel  # noqa: E402
from app.services.aspect_service import analyze_aspects, game_aspect_stats  # noqa: E402
from app.services.corpus import load_corpus  # noqa: E402
from app.services.topic_service import run_topic_analysis, topic_frequency  # noqa: E402


def keywords(db) -> None:
    df = load_corpus(db)
    games = {g.id: g for g in db.scalars(select(Game))}
    extra = name_stopwords([g.name for g in games.values()])
    out = {
        "top": top_keywords(df["text_clean"].tolist(), 20, extra),
        "by_game": {games[int(g)].name: kws for g, kws in distinctive_keywords(
            df["text_clean"].tolist(), df["game_id"].tolist(), 8, extra).items() if int(g) in games},
        "emerging": emerging_keywords(df, extra_stop=extra),
    }
    genres = {}
    for gid, game in games.items():
        for genre in game.genres:
            genres.setdefault(genre.name, set()).add(gid)
    rows = df[df["game_id"].notna()]
    labels = [next((n for n, ids in genres.items() if int(g) in ids), None) for g in rows["game_id"]]
    out["by_genre_first_genre"] = {k: v for k, v in distinctive_keywords(
        rows["text_clean"].tolist(), labels, 8, extra).items()}
    p = ROOT / "data" / "processed" / "keywords.json"
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(out, indent=2))
    print("top keywords:", [t for t, _ in out["top"][:10]])
    print("emerging:", [e["term"] for e in out["emerging"][:8]], "->", p)


def topics(db) -> None:
    res = run_topic_analysis(db)
    print(f"k={res['k']} coherence={res['coherence']:.2f} by_k={res['coherence_by_k']}")
    for t in res["topics"]:
        print(f"  [{t['id']}] {t['label']}: {', '.join(t['keywords'][:6])}")
    print(topic_frequency(db).to_string(index=False))


def aspects(db) -> None:
    n = analyze_aspects(db, VaderModel())
    stats = game_aspect_stats(db)
    print(f"{n} aspect mentions; example game 1:")
    for s in [s for s in stats if s["game_id"] == 1]:
        print("  ", s)


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    what = sys.argv[1] if len(sys.argv) > 1 else "all"
    with SessionLocal() as db:
        for name, fn in (("keywords", keywords), ("topics", topics), ("aspects", aspects)):
            if what in (name, "all"):
                fn(db)
