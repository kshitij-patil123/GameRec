"""Run the whole analysis pipeline in order: load data -> sentiment -> aspects -> topics -> trend/community scores.
Usage: python scripts/run_pipeline.py [demo|public|discord_export]   (default: DATA_SOURCE from .env)
Afterwards start the API (it builds the recommender lazily), or POST /system/refresh if it is already running."""
import logging
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "backend"))
from app.core.db import Base, SessionLocal, engine  # noqa: E402
import app.models  # noqa: E402,F401
from app.ingestion.loader import load_source  # noqa: E402
from app.ingestion.sources import get_source  # noqa: E402
from app.nlp.sentiment import VaderModel  # noqa: E402
from app.services.aspect_service import analyze_aspects  # noqa: E402
from app.services.sentiment_service import analyze_messages  # noqa: E402
from app.services.topic_service import run_topic_analysis  # noqa: E402
from app.services.trend_service import compute_and_store_scores  # noqa: E402

def run(source_name: str | None = None) -> None:
    Base.metadata.create_all(engine)
    source = get_source(source_name)
    with SessionLocal() as db:
        print("loaded:", load_source(db, source))
        model = VaderModel()
        print("sentiment rows:", analyze_messages(db, model))
        print("aspect rows:", analyze_aspects(db, model))
        print("topics:", run_topic_analysis(db, k=8)["k"])
        print("scored games:", len(compute_and_store_scores(db)))


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    run(sys.argv[1] if len(sys.argv) > 1 else None)
    print("Pipeline complete. Start the API:  cd backend && uvicorn app.main:app --reload")
