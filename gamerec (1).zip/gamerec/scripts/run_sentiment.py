"""Usage: python scripts/run_sentiment.py [vader|transformer]   (default vader)
Writes results to sentiment_results and prints per-game stats."""
import logging
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "backend"))
from app.core.db import SessionLocal  # noqa: E402
from app.nlp.sentiment import get_model  # noqa: E402
from app.services.sentiment_service import analyze_messages, game_sentiment_stats  # noqa: E402

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    model = get_model(sys.argv[1] if len(sys.argv) > 1 else "vader")
    with SessionLocal() as db:
        analyze_messages(db, model)
        for row in game_sentiment_stats(db, model.name):
            print(row)
