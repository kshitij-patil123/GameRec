"""Compute trend + community scores (needs: load_data, run_sentiment, run_analysis aspects).
Usage: python scripts/run_trends.py"""
import logging
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "backend"))
from app.core.db import SessionLocal  # noqa: E402
from app.services.trend_service import compute_and_store_scores, genre_popularity  # noqa: E402

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    with SessionLocal() as db:
        df = compute_and_store_scores(db)
        cols = ["game", "n_messages", "growth_ratio", "status", "trend_score", "community_score", "confidence"]
        print("\nRising:\n", df[df.status == "rising"].sort_values("trend_score", ascending=False)[cols].head(5).round(3).to_string(index=False))
        print("\nDeclining:\n", df[df.status == "declining"].sort_values("growth_ratio")[cols].head(5).round(3).to_string(index=False))
        print("\nTop community score:\n", df.sort_values("community_score", ascending=False)[cols].head(5).round(3).to_string(index=False))
        print("\nGenre popularity:\n", genre_popularity(db).head(6).to_string(index=False))
